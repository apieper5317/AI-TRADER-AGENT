/*
 * market-scanner.js
 * Market opportunity scanner: profile, liquidity filters, learning state, and ranked candidate display.
 * Keep configuration secrets in environment variables, not in this source file.
 */

(function () {
    "use strict";

    const STORAGE_KEY = "traderAgentMarketScanner";
    const PROFILE_KEY = "traderAgentTradingProfile";
    const LEARNING_KEY = "traderAgentScannerLearningV1";
    const FILTER_KEY = "traderAgentLiquidityFiltersV1";
    let refreshTimer = null;

    // ---- escapeHTML() ----

    function escapeHTML(value) {
        return String(value == null ? "" : value)
            .replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;")
            .replace(/"/g, "&quot;").replace(/'/g, "&#039;");
    }

    // ---- formatPrice() ----

    function formatPrice(value) {
        const number = Number(value);
        return Number.isFinite(number) ? `$${number.toFixed(2)}` : "--";
    }

    // ---- formatVolume() ----

    function formatVolume(value) {
        const number = Number(value);
        if (!Number.isFinite(number)) return "--";
        if (number >= 1000000000) return `${(number / 1000000000).toFixed(2)}B`;
        if (number >= 1000000) return `${(number / 1000000).toFixed(2)}M`;
        if (number >= 1000) return `${(number / 1000).toFixed(1)}K`;
        return number.toLocaleString();
    }

    // ---- liquidityClass() ----

    function liquidityClass(passed) {
        return passed ? "scanner-liquidity-pass" : "scanner-liquidity-fail";
    }

    // ---- getProfile() ----

    function getProfile() {
        const defaults = { risk: 6, style: "day", maxRiskPercent: 2 };
        try {
            return Object.assign(defaults, JSON.parse(localStorage.getItem(PROFILE_KEY) || "{}"));
        } catch (error) {
            return defaults;
        }
    }

    // ---- saveProfile() ----

    function saveProfile(profile) {
        localStorage.setItem(PROFILE_KEY, JSON.stringify(profile));
    }

    // ---- getLiquidityFilters() ----

    function getLiquidityFilters() {
        const defaults = {
            enabledCaps: ["Nano", "Micro", "Small", "Mid", "Large", "Mega"],
            relativeVolume: { Nano: 2, Micro: 2, Small: 1, Mid: 1, Large: 0.75, Mega: 0.75 },
            minimumCurrentVolume: 100000
        };
        try {
            const saved = JSON.parse(localStorage.getItem(FILTER_KEY) || "{}");
            return {
                enabledCaps: Array.isArray(saved.enabledCaps) ? saved.enabledCaps : defaults.enabledCaps,
                relativeVolume: Object.assign({}, defaults.relativeVolume, saved.relativeVolume || {}),
                minimumCurrentVolume: Number.isFinite(Number(saved.minimumCurrentVolume))
                    ? Number(saved.minimumCurrentVolume)
                    : defaults.minimumCurrentVolume
            };
        } catch (error) {
            return defaults;
        }
    }

    // ---- saveLiquidityFilters() ----

    function saveLiquidityFilters(filters) {
        localStorage.setItem(FILTER_KEY, JSON.stringify(filters));
    }

    // ---- syncLiquidityControls() ----

    function syncLiquidityControls() {
        const filters = getLiquidityFilters();
        ["Nano", "Micro", "Small", "Mid", "Large", "Mega"].forEach(function(category) {
            const enabled = document.getElementById(`scannerCap${category}`);
            const rvol = document.getElementById(`scannerRvol${category}`);
            if (enabled) enabled.checked = filters.enabledCaps.includes(category);
            if (rvol) rvol.value = filters.relativeVolume[category];
        });
        const volume = document.getElementById("scannerMinimumVolume");
        if (volume) volume.value = filters.minimumCurrentVolume;
    }

    // ---- readLiquidityControls() ----

    function readLiquidityControls() {
        const categories = ["Nano", "Micro", "Small", "Mid", "Large", "Mega"];
        const enabledCaps = categories.filter(function(category) {
            const input = document.getElementById(`scannerCap${category}`);
            return !input || input.checked;
        });
        const relativeVolume = {};
        categories.forEach(function(category) {
            const input = document.getElementById(`scannerRvol${category}`);
            relativeVolume[category] = Math.max(0, Number(input && input.value) || 0);
        });
        const minimumVolume = document.getElementById("scannerMinimumVolume");
        return {
            enabledCaps: enabledCaps,
            relativeVolume: relativeVolume,
            minimumCurrentVolume: Math.max(0, Math.round(Number(minimumVolume && minimumVolume.value) || 0))
        };
    }

    // ---- getLearning() ----

    function getLearning() {
        try {
            return Object.assign({ wins: 0, losses: 0, longWins: 0, longLosses: 0, shortWins: 0, shortLosses: 0, records: [] },
                JSON.parse(localStorage.getItem(LEARNING_KEY) || "{}"));
        } catch (error) {
            return { wins: 0, losses: 0, longWins: 0, longLosses: 0, shortWins: 0, shortLosses: 0, records: [] };
        }
    }

    // ---- learningBias() ----

    function learningBias() {
        const learning = getLearning();
        // ---- bias() ----
        function bias(wins, losses) {
            const total = wins + losses;
            if (total < 3) return 0;
            return Math.max(-5, Math.min(5, ((wins / total) - 0.5) * 10));
        }
        return {
            long: bias(learning.longWins, learning.longLosses),
            short: bias(learning.shortWins, learning.shortLosses)
        };
    }

    // ---- updateLearningSummary() ----

    function updateLearningSummary() {
        const learning = getLearning();
        const total = learning.wins + learning.losses;
        const element = document.getElementById("scannerLearningSummary");
        if (!element) return;
        element.textContent = total ? `${learning.wins}/${total} worked (${Math.round(learning.wins / total * 100)}%)` : "No feedback yet";
    }

    // ---- profileDescription() ----

    function profileDescription(profile) {
        const text = {
            conservative: "Conservative Investor emphasizes 1D and 1W trend agreement, liquidity, and lower volatility.",
            swing: "Swing Trader emphasizes 4H, 1D, and 1W continuation over several trading days.",
            day: "Day Trader balances 5m–1H momentum with 4H and daily confirmation.",
            momentum: "Momentum Trader rewards fast price acceleration, volume, and 3m–15m agreement.",
            aggressive: "Aggressive mode favors larger expected moves and volatility, with wider stops and targets.",
            short: "Short Seller prioritizes bearish alignment, breakdown momentum, and negative catalysts."
        };
        return `${text[profile.style] || text.day} Risk ${profile.risk}/10.`;
    }

    // ---- syncProfileControls() ----

    function syncProfileControls() {
        const profile = getProfile();
        const risk = document.getElementById("scannerRisk");
        const style = document.getElementById("scannerStyle");
        const value = document.getElementById("scannerRiskValue");
        const description = document.getElementById("scannerProfileDescription");
        if (risk) risk.value = profile.risk;
        if (style) style.value = profile.style;
        if (value) value.textContent = profile.risk;
        if (description) description.textContent = profileDescription(profile);
    }

    // ---- scoreClass() ----

    function scoreClass(score) {
        if (score >= 80) return "scanner-score-strong";
        if (score >= 65) return "scanner-score-watch";
        return "scanner-score-weak";
    }

    // ---- directionClass() ----

    function directionClass(direction) {
        if (direction === "Long") return "scanner-direction-bullish";
        if (direction === "Short") return "scanner-direction-bearish";
        return "scanner-direction-neutral";
    }


    // ---- marketModeCopy() ----


    function marketModeCopy(result) {
        const mode = result.mode || "next_session";
        const copies = {
            live: {
                status: "Live rankings are active.",
                description: "Uses current intraday candles, volume, momentum, company news, and current macro/political headlines."
            },
            premarket: {
                status: "Premarket forecast is active.",
                description: "Uses premarket price action, overnight news, gaps, company catalysts, and macro/political headlines before the opening bell."
            },
            after_hours: {
                status: "After-hours review is active.",
                description: "Uses the completed regular session plus after-hours price action, earnings releases, and news announced after the close."
            },
            sunday_outlook: {
                status: "Monday outlook is active.",
                description: "Uses Friday technicals plus weekend company, Federal Reserve, economic, presidential, policy, and geopolitical news."
            },
            overnight_forecast: {
                status: "Overnight forecast is active.",
                description: "Uses the last completed session and overnight company, economic, government, and global-market headlines."
            },
            next_session: {
                status: "Next-session forecast is active.",
                description: "The U.S. regular session is closed. Rankings use the last completed session plus newer company and macro/political news."
            }
        };
        return copies[mode] || copies.next_session;
    }

    // ---- renderLoading() ----

    function renderLoading() {
        const body = document.getElementById("marketScannerBody");
        const status = document.getElementById("marketScannerStatus");
        if (status) status.textContent = "Scanning eight timeframes and adapting scores to your risk profile…";
        if (body) body.innerHTML = `<tr><td colspan="14" class="scanner-empty">Loading Top 10 AI opportunities…</td></tr>`;
    }

    // ---- renderError() ----

    function renderError(message) {
        const body = document.getElementById("marketScannerBody");
        const status = document.getElementById("marketScannerStatus");
        if (status) status.textContent = message;
        if (body) body.innerHTML = `<tr><td colspan="11" class="scanner-empty scanner-error">${escapeHTML(message)}</td></tr>`;
    }

    // ---- recordOutcome() ----

    function recordOutcome(stock, worked) {
        const learning = getLearning();
        const directionKey = stock.direction === "Short" ? "short" : "long";
        if (worked) {
            learning.wins += 1;
            learning[directionKey + "Wins"] += 1;
        } else {
            learning.losses += 1;
            learning[directionKey + "Losses"] += 1;
        }
        learning.records.unshift({ ticker: stock.ticker, direction: stock.direction, worked: worked, score: stock.score, at: new Date().toISOString() });
        learning.records = learning.records.slice(0, 250);
        localStorage.setItem(LEARNING_KEY, JSON.stringify(learning));
        updateLearningSummary();
        loadMarketRankings(true);
    }

    // ---- renderResult() ----

    function renderResult(result) {
        const modeBadge = document.getElementById("marketModeBadge");
        const modeDescription = document.getElementById("marketModeDescription");
        const updated = document.getElementById("marketScannerUpdated");
        const status = document.getElementById("marketScannerStatus");
        const body = document.getElementById("marketScannerBody");
        const coverage = document.getElementById("scannerCoverage");
        const candidates = document.getElementById("scannerCandidateCount");

        const modeCopy = marketModeCopy(result);
        if (modeBadge) modeBadge.textContent = `${result.modeLabel || "Market Scan"} • ${result.tradingStyleLabel || "AI Scan"} • Risk ${result.riskLevel || 6}/10`;
        if (modeDescription) modeDescription.textContent = modeCopy.description;
        if (updated) updated.textContent = result.generatedAtLabel || "Just updated";
        if (coverage) coverage.textContent = `${Math.round(result.averageCoverage || 0)}%`;
        if (candidates) candidates.textContent = String(result.candidateCount || 0);
        if (status) status.textContent = modeCopy.status;

        const macroSentiment = document.getElementById("macroMarketSentiment");
        const macroHeadlines = document.getElementById("macroMarketHeadlines");
        const macro = result.macroContext || {};
        if (macroSentiment) {
            macroSentiment.textContent = macro.available
                ? `${String(macro.sentiment || "mixed").toUpperCase()} • ${(macro.sources || []).join(" + ") || "official sources"}`
                : "Official macro feeds unavailable";
        }
        if (macroHeadlines) {
            const titles = (macro.headlines || []).slice(0, 4).map(function(item) { return item.title; });
            macroHeadlines.textContent = titles.length
                ? titles.join(" • ")
                : "No recent Federal Reserve, BLS, or White House headlines were available for this scan.";
        }

        const rows = Array.isArray(result.rankings) ? result.rankings : [];
        if (!body) return;
        if (!rows.length) {
            body.innerHTML = `<tr><td colspan="14" class="scanner-empty">No ranked opportunities were returned.</td></tr>`;
            return;
        }

        body.innerHTML = rows.map(function (stock) {
            const reasons = (stock.reasons || []).slice(0, 3).join(" • ");
            const agreement = stock.timeframeAgreement || {};
            return `<tr>
                <td class="scanner-rank">#${stock.rank}</td>
                <td><button type="button" class="scanner-ticker-button" data-action="analyze" data-ticker="${escapeHTML(stock.ticker)}">${escapeHTML(stock.ticker)}</button><small>${escapeHTML(stock.setup || "")}</small></td>
                <td><span class="scanner-score ${scoreClass(stock.score)}">${Math.round(stock.score)}/100</span></td>
                <td><span class="scanner-direction ${directionClass(stock.direction)}">${escapeHTML(stock.direction)}</span></td>
                <td>${formatPrice(stock.price)}</td>
                <td>${Number.isFinite(Number(stock.changePercent)) ? `${Number(stock.changePercent).toFixed(2)}%` : "--"}</td>
                <td><div class="scanner-cap"><b>${escapeHTML(stock.marketCapCategory || "Unknown")}</b><small>${escapeHTML(stock.marketCapFormatted || "--")}</small></div></td>
                <td><div class="scanner-liquidity ${liquidityClass(stock.volumePass)}"><b>${formatVolume(stock.currentVolume)}</b><small>Min ${formatVolume(stock.minimumCurrentVolume)} • ${stock.volumePass ? "PASS" : "FAIL"}</small></div></td>
                <td><div class="scanner-liquidity ${liquidityClass(stock.relativeVolumePass)}"><b>${Number.isFinite(Number(stock.relativeVolume)) ? `${Number(stock.relativeVolume).toFixed(2)}x` : "--"}</b><small>Needs ${Number(stock.requiredRelativeVolume || 0).toFixed(2)}x • ${stock.relativeVolumePass ? "PASS" : "FAIL"}</small></div></td>
                <td class="scanner-agreement"><strong>${agreement.directionalAgreement || 0}/${agreement.available || 0}</strong><small>${agreement.agreementPercent || 0}% aligned</small></td>
                <td><div class="scanner-plan"><b>Entry:</b> ${formatPrice(stock.entry)}<br><b>Stop:</b> ${formatPrice(stock.stop)}<br><b>Target:</b> ${formatPrice(stock.target)}<br><b>R:R:</b> ${stock.riskReward || "--"}:1</div></td>
                <td><div class="scanner-time-alert"><span class="scanner-time-status">${escapeHTML(stock.timeAlert && stock.timeAlert.timeAlertStatus || "--")}</span><b>Entry:</b> ${escapeHTML(stock.timeAlert && stock.timeAlert.entryWindow || "--")}<br><b>Exit:</b> ${escapeHTML(stock.timeAlert && stock.timeAlert.exitWindow || "--")}<small>${escapeHTML(stock.timeAlert && stock.timeAlert.timeAlertDetail || "")}</small></div></td>
                <td><div class="scanner-reason">${escapeHTML(reasons || "Technical candidate")}</div><small>${escapeHTML(stock.confirmation || "Wait for confirmation.")}</small></td>
                <td><div class="scanner-feedback"><button type="button" class="secondary-button" data-action="win" data-ticker="${escapeHTML(stock.ticker)}">Worked</button><button type="button" class="secondary-button" data-action="loss" data-ticker="${escapeHTML(stock.ticker)}">Missed</button><button type="button" class="secondary-button scanner-analyze-button" data-action="analyze" data-ticker="${escapeHTML(stock.ticker)}">Analyze</button></div></td>
            </tr>`;
        }).join("");

        body.querySelectorAll("button[data-action]").forEach(function (button) {
            button.addEventListener("click", function () {
                const stock = rows.find(function (item) { return item.ticker === button.dataset.ticker; });
                if (!stock) return;
                if (button.dataset.action === "analyze") openCopilotForTicker(stock.ticker);
                if (button.dataset.action === "win") recordOutcome(stock, true);
                if (button.dataset.action === "loss") recordOutcome(stock, false);
            });
        });

        localStorage.setItem(STORAGE_KEY, JSON.stringify(result));
        if (refreshTimer) clearInterval(refreshTimer);
        if (result.marketOpen) refreshTimer = setInterval(function () { loadMarketRankings(false); }, 60000);
    }

    // ---- openCopilotForTicker() ----

    function openCopilotForTicker(ticker) {
        const prompt = document.getElementById("aiPrompt");
        const profile = getProfile();
        if (prompt) {
            prompt.value = `Analyze ${ticker} using my ${profile.style} profile at risk ${profile.risk}/10. Verify all eight timeframes, recent company news, and relevant Federal Reserve, economic, presidential, policy, and geopolitical news. Include market cap, current volume, required relative volume, entry-time alert, exit-time alert, entry, stop, target, expected hold, invalidation, and biggest risk.`;
            prompt.scrollIntoView({ behavior: "smooth", block: "center" });
        }
        localStorage.setItem("traderAgentAgentPrompt", prompt ? prompt.value : "");
        if (typeof window.generateAIAnalysis === "function") window.generateAIAnalysis();
    }

    // ---- loadMarketRankings() ----

    async function loadMarketRankings(showLoading) {
        if (showLoading !== false) renderLoading();
        const profile = getProfile();
        const bias = learningBias();
        const filters = getLiquidityFilters();
        const params = new URLSearchParams({
            limit: "10", risk: String(profile.risk), style: profile.style,
            learnLong: bias.long.toFixed(2), learnShort: bias.short.toFixed(2),
            enabledCaps: filters.enabledCaps.join(","),
            minimumCurrentVolume: String(filters.minimumCurrentVolume),
            rvolNano: String(filters.relativeVolume.Nano),
            rvolMicro: String(filters.relativeVolume.Micro),
            rvolSmall: String(filters.relativeVolume.Small),
            rvolMid: String(filters.relativeVolume.Mid),
            rvolLarge: String(filters.relativeVolume.Large),
            rvolMega: String(filters.relativeVolume.Mega)
        });
        try {
            const response = await fetch(`http://localhost:3000/market-scan?${params.toString()}`, { cache: "no-store" });
            const result = await response.json();
            if (!response.ok) throw new Error(result.error || "The market scanner request failed.");
            renderResult(result);
        } catch (error) {
            console.error("Market scanner error:", error);
            renderError(`Unable to load opportunities: ${error.message}. Make sure server.js is running.`);
        }
    }

    window.loadMarketRankings = loadMarketRankings;

    window.addEventListener("DOMContentLoaded", function () {
        syncProfileControls();
        syncLiquidityControls();
        updateLearningSummary();
        const risk = document.getElementById("scannerRisk");
        const style = document.getElementById("scannerStyle");
        const refresh = document.getElementById("refreshMarketScanner");
        const reset = document.getElementById("resetScannerLearning");
        const applyFilters = document.getElementById("applyScannerLiquidityFilters");
        const resetFilters = document.getElementById("resetScannerLiquidityFilters");

        // ---- updateProfile() ----

        function updateProfile() {
            const profile = getProfile();
            profile.risk = Number(risk ? risk.value : profile.risk);
            profile.style = style ? style.value : profile.style;
            saveProfile(profile);
            syncProfileControls();
        }
        if (risk) risk.addEventListener("input", function () { updateProfile(); });
        if (risk) risk.addEventListener("change", function () { loadMarketRankings(true); });
        if (style) style.addEventListener("change", function () { updateProfile(); loadMarketRankings(true); });
        if (refresh) refresh.addEventListener("click", function () { loadMarketRankings(true); });
        if (applyFilters) applyFilters.addEventListener("click", function () {
            const filters = readLiquidityControls();
            if (!filters.enabledCaps.length) {
                alert("Select at least one market-cap category.");
                return;
            }
            saveLiquidityFilters(filters);
            loadMarketRankings(true);
        });
        if (resetFilters) resetFilters.addEventListener("click", function () {
            localStorage.removeItem(FILTER_KEY);
            syncLiquidityControls();
            loadMarketRankings(true);
        });
        if (reset) reset.addEventListener("click", function () {
            localStorage.removeItem(LEARNING_KEY);
            updateLearningSummary();
            loadMarketRankings(true);
        });
        loadMarketRankings(true);
    });
})();
