/*
 * app-shell.js
 * Shared application shell: market-status strip, page chrome, and saved UI state helpers.
 * Keep configuration secrets in environment variables, not in this source file.
 */


(function () {
    "use strict";

    const MARKET_SYMBOLS = ["SPY", "QQQ", "NVDA", "AAPL"];
    const UI_STATE_KEY = "traderAgentPhase2UIState";

    // ---- safeParse() ----

    function safeParse(value, fallback) {
        try {
            return value ? JSON.parse(value) : fallback;
        } catch (error) {
            return fallback;
        }
    }

    // ---- getEasternParts() ----

    function getEasternParts(date) {
        const formatter = new Intl.DateTimeFormat("en-US", {
            timeZone: "America/New_York",
            weekday: "short",
            year: "numeric",
            month: "short",
            day: "numeric",
            hour: "numeric",
            minute: "2-digit",
            second: "2-digit",
            hour12: true
        });

        return formatter.format(date);
    }

    // ---- getEasternMarketStatus() ----

    function getEasternMarketStatus() {
        const now = new Date();
        const dateParts = new Intl.DateTimeFormat("en-US", {
            timeZone: "America/New_York",
            weekday: "short",
            hour: "2-digit",
            minute: "2-digit",
            hour12: false
        }).formatToParts(now);

        const values = {};
        dateParts.forEach(function (part) {
            values[part.type] = part.value;
        });

        const weekday = values.weekday;
        const hour = Number(values.hour);
        const minute = Number(values.minute);
        const totalMinutes = hour * 60 + minute;
        const weekdayOpen = ["Mon", "Tue", "Wed", "Thu", "Fri"].includes(weekday);
        const isOpen = weekdayOpen && totalMinutes >= 570 && totalMinutes < 960;

        return {
            isOpen: isOpen,
            label: isOpen ? "Market open" : "Market closed"
        };
    }

    // ---- buildMarketStrip() ----

    function buildMarketStrip() {
        if (document.querySelector(".market-strip")) {
            return;
        }

        const strip = document.createElement("div");
        strip.className = "market-strip";
        strip.innerHTML = `
            <div class="market-brand">
                <span id="phase2MarketDot" class="market-dot"></span>
                <span id="phase2MarketStatus">Checking market...</span>
            </div>
            <div id="phase2MarketItems" style="display:flex;gap:18px;"></div>
            <div id="phase2MarketClock" class="market-clock"></div>
        `;

        document.body.prepend(strip);
    }

    // ---- updateClock() ----

    function updateClock() {
        const clock = document.getElementById("phase2MarketClock");
        const status = document.getElementById("phase2MarketStatus");
        const dot = document.getElementById("phase2MarketDot");
        const market = getEasternMarketStatus();

        if (clock) {
            clock.textContent = getEasternParts(new Date()) + " ET";
        }

        if (status) {
            status.textContent = market.label;
        }

        if (dot) {
            dot.className = "market-dot " + (market.isOpen ? "open" : "closed");
        }
    }

    // ---- fetchMarketSnapshot() ----

    async function fetchMarketSnapshot(ticker) {
        try {
            const response = await fetch(
                `http://localhost:3000/finviz?ticker=${encodeURIComponent(ticker)}&timeframe=5m`,
                { cache: "no-store" }
            );

            if (!response.ok) {
                return null;
            }

            const result = await response.json();
            const data = Array.isArray(result)
                ? result
                : result && Array.isArray(result.data)
                    ? result.data
                    : [];

            if (data.length < 2) {
                return null;
            }

            const latest = data[data.length - 1];
            const previous = data[data.length - 2];
            const changePercent = previous.close
                ? ((latest.close - previous.close) / previous.close) * 100
                : 0;

            return {
                ticker: ticker,
                price: Number(latest.close),
                changePercent: changePercent
            };
        } catch (error) {
            return null;
        }
    }

    // ---- updateMarketItems() ----

    async function updateMarketItems() {
        const container = document.getElementById("phase2MarketItems");

        if (!container) {
            return;
        }

        const snapshots = await Promise.all(
            MARKET_SYMBOLS.map(fetchMarketSnapshot)
        );

        container.innerHTML = snapshots.map(function (snapshot, index) {
            const ticker = MARKET_SYMBOLS[index];

            if (!snapshot) {
                return `
                    <div class="market-item">
                        <b>${ticker}</b>
                        <span>--</span>
                    </div>
                `;
            }

            const directionClass =
                snapshot.changePercent >= 0 ? "positive" : "negative";
            const sign = snapshot.changePercent >= 0 ? "+" : "";

            return `
                <div class="market-item">
                    <b>${snapshot.ticker}</b>
                    <span>$${snapshot.price.toFixed(2)}</span>
                    <span class="${directionClass}">
                        ${sign}${snapshot.changePercent.toFixed(2)}%
                    </span>
                </div>
            `;
        }).join("");
    }

    // ---- enhanceSidebar() ----

    function enhanceSidebar() {
        const sidebar = document.querySelector(".sidebar");

        if (!sidebar) {
            return;
        }

        if (!document.getElementById("phase2SidebarToggle")) {
            const toggle = document.createElement("button");
            toggle.id = "phase2SidebarToggle";
            toggle.className = "sidebar-toggle";
            toggle.type = "button";
            toggle.setAttribute("aria-label", "Collapse sidebar");
            toggle.innerHTML = "☰";
            const logo = sidebar.querySelector(".logo");

            if (logo) {
                logo.insertAdjacentElement("afterend", toggle);
            } else {
                sidebar.prepend(toggle);
            }

            toggle.addEventListener("click", function () {
                document.body.classList.toggle("sidebar-collapsed");
                saveUIState();
            });
        }

        const currentFile =
            window.location.pathname.split("/").pop() || "index.html";

        sidebar.querySelectorAll(".nav a").forEach(function (link) {
            const href = link.getAttribute("href");

            link.classList.toggle("active", href === currentFile);

            link.addEventListener("click", function () {
                saveUIState();
                document.body.classList.remove("phase2-ready");
            });
        });
    }

    // ---- addContextPill() ----

    function addContextPill() {
        const header = document.querySelector(".header h1");

        if (!header || header.querySelector(".page-context-pill")) {
            return;
        }

        const pill = document.createElement("span");
        pill.className = "page-context-pill";
        pill.textContent = "LIVE";
        header.appendChild(pill);
    }

    // ---- saveUIState() ----

    function saveUIState() {
        localStorage.setItem(
            UI_STATE_KEY,
            JSON.stringify({
                sidebarCollapsed:
                    document.body.classList.contains("sidebar-collapsed"),
                savedAt: Date.now()
            })
        );
    }

    // ---- restoreUIState() ----

    function restoreUIState() {
        const state = safeParse(localStorage.getItem(UI_STATE_KEY), {});

        if (state.sidebarCollapsed) {
            document.body.classList.add("sidebar-collapsed");
        }
    }

    // ---- init() ----

    function init() {
        restoreUIState();
        buildMarketStrip();
        enhanceSidebar();
        addContextPill();
        updateClock();
        updateMarketItems();

        setInterval(updateClock, 1000);
        setInterval(updateMarketItems, 60000);

        window.addEventListener("beforeunload", saveUIState);

        requestAnimationFrame(function () {
            document.body.classList.add("phase2-ready");
        });
    }

    if (document.readyState === "loading") {
        document.addEventListener("DOMContentLoaded", init);
    } else {
        init();
    }
})();
