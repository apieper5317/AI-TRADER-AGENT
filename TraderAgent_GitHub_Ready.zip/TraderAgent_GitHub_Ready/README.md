# TraderAgent

TraderAgent is a browser-based trading research and paper-trading project. It includes a dashboard, stock analysis, an AI trading copilot/market scanner, historical backtesting, a watchlist, and settings pages.

## Repository contents

| File | Purpose |
| --- | --- |
| `index.html` | Main AI paper-trading dashboard |
| `analysis.html` | Stock analysis and technical-indicator page |
| `agent.html` | AI trading copilot and market opportunity scanner |
| `backtesting.html` | Historical backtesting and replay |
| `watchlist.html` | Watchlist and CSV import |
| `settings.html` | Trading profile and scanner settings |
| `style.css` | Shared styling |
| `dashboard.js` | Dashboard paper-trading logic |
| `script.js` | Shared analysis/backtesting/watchlist/settings logic |
| `charts.js` | Price and indicator chart utilities |
| `market-scanner.js` | Scanner UI, filtering, and ranking logic |
| `app-shell.js` | Shared market strip and page-state behavior |
| `server.js` | Node/Express backend and Finviz data/news routes |
| `.env.example` | Example environment configuration |

## Requirements

- Node.js 18 or newer
- npm
- A Finviz Elite token for Finviz-backed market-data and news routes
- Internet access while using live market/news features

## Run on a new machine

1. Clone or download this repository.
2. Open a terminal in the repository folder.
3. Install dependencies:

   ```bash
   npm install
   ```

4. Create your local environment file:

   **macOS/Linux**
   ```bash
   cp .env.example .env
   ```

   **Windows PowerShell**
   ```powershell
   Copy-Item .env.example .env
   ```

5. Open `.env` and replace `your_finviz_token_here` with your own Finviz Elite token. Do not commit `.env` to GitHub.
6. Start TraderAgent:

   ```bash
   npm start
   ```

7. Open `http://localhost:3000` in a browser.

The same Node process serves both the frontend pages and backend API, so a separate user does not need to configure a second web server.

## How to use

- **Dashboard:** select tickers and a timeframe, then start or refresh the simulated AI paper trader.
- **Stock Analysis:** enter a ticker and select a timeframe to retrieve market data and display indicators/charts.
- **AI Agent:** review scanner candidates and generate structured trading-copilot output.
- **Backtesting:** choose a ticker, timeframe, dates, strategy, position size, stop loss, and take profit, then run/replay a historical test.
- **Watchlist:** add tickers manually or import a CSV containing a `Ticker` or `Symbol` column.
- **Settings:** adjust the trading profile, risk meter, and scanner liquidity filters.

## Data and security notes

- The project stores UI and paper-trading state in browser `localStorage`.
- The repository does **not** contain a private Finviz token. Each machine should provide its token in a local `.env` file.
- `.env` is excluded through `.gitignore`.
- Trading actions are simulated. The project does not place real brokerage orders.

## Troubleshooting

**`Cannot find module 'express'`**  
Run `npm install` from the repository folder, then run `npm start` again.

**Finviz routes say the token is missing or return no data**  
Confirm that `.env` exists in the repository root and contains `FINVIZ_TOKEN=...`, then restart the server.

**Port 3000 is already in use**  
Change `PORT=3000` in `.env` to another open port such as `PORT=3001`, restart, and open that port in your browser.

**Charts do not render**  
The analysis page loads Lightweight Charts from a public CDN, so the machine needs internet access for that library as well as live data.

## GitHub submission steps

1. Create a new **public** GitHub repository, for example `TraderAgent`.
2. Add every file in this folder to the repository.
3. Do **not** upload your `.env` file.
4. Commit and push the files.
5. Open the repository in a private/incognito browser window to verify it is public.
6. On another machine, clone the repository and follow the **Run on a new machine** instructions above.
7. Submit the public GitHub repository URL for the assignment.

## Suggested verification before submission

```bash
npm install
npm start
```

Then open the app, visit each navigation page, and test at least one ticker. For the strongest submission, have another person clone the repository onto a different machine and follow this README exactly.
