/*
 * dashboard.js
 * Paper-trading dashboard logic: market/news retrieval, portfolio state, and simulated trade decisions.
 * Keep configuration secrets in environment variables, not in this source file.
 */

const DASHBOARD_REFRESH_MS = 30000;
const NEWS_MAX_AGE_HOURS = 48;

let liveUpdateInterval = null;
let clockInterval = null;
let isTrading = false;

let paperPortfolio = {
    startingCash: 10000,
    cash: 10000,
    holdings: {},
    trades: [],
    valueHistory: [{ time: new Date().toISOString(), value: 10000 }],
    sessionStartValue: 10000,
    lastProcessedCandle: {}
};

const savedPortfolio = localStorage.getItem("traderAgentPaperPortfolio") || localStorage.getItem("fakePortfolio");
if (savedPortfolio) {
    try {
        paperPortfolio = Object.assign(paperPortfolio, JSON.parse(savedPortfolio));
    } catch (error) {
        console.error("Unable to restore paper portfolio:", error);
    }
}


// ---- saveDashboardUIState() ----


function saveDashboardUIState() {
    const selectedTickers = Array.from(
        document.querySelectorAll(".tickerCheck:checked")
    ).map(function(box) {
        return box.value;
    });

    localStorage.setItem(
        "traderAgentDashboardUIState",
        JSON.stringify({
            selectedTickers: selectedTickers,
            timeframe: getDashboardTimeframe(),
            riskLevel: document.getElementById("riskLevel")
                ? document.getElementById("riskLevel").value
                : "auto",
            scrollY: window.scrollY,
            savedAt: Date.now()
        })
    );
}

// ---- restoreDashboardUIState() ----

function restoreDashboardUIState() {
    let state = null;

    try {
        state = JSON.parse(
            localStorage.getItem("traderAgentDashboardUIState") || "null"
        );
    } catch (error) {
        console.error("Unable to restore dashboard UI:", error);
    }

    if (!state) {
        return;
    }

    const selected = new Set(state.selectedTickers || []);
    document.querySelectorAll(".tickerCheck").forEach(function(box) {
        box.checked = selected.has(box.value);
    });

    const timeframe = document.getElementById("dashboardTimeframe");
    if (timeframe && state.timeframe) {
        timeframe.value = state.timeframe;
    }

    const riskLevel = document.getElementById("riskLevel");
    if (riskLevel && state.riskLevel) {
        riskLevel.value = state.riskLevel;
    }

    requestAnimationFrame(function() {
        window.scrollTo(0, Number(state.scrollY) || 0);
    });
}

// ---- savePortfolio() ----

function savePortfolio() {
    localStorage.setItem("traderAgentPaperPortfolio", JSON.stringify(paperPortfolio));
}

// ---- getDashboardTimeframe() ----

function getDashboardTimeframe() {
    const select = document.getElementById("dashboardTimeframe");
    return select ? select.value : "5m";
}

// ---- getSelectedTickers() ----

function getSelectedTickers() {
    return Array.from(document.querySelectorAll(".tickerCheck:checked")).map(function(box) {
        return box.value;
    });
}

// ---- getFinvizChartData() ----

async function getFinvizChartData(ticker, timeframe) {
    try {
        const response = await fetch(
            `http://localhost:3000/finviz?ticker=${encodeURIComponent(ticker)}&timeframe=${encodeURIComponent(timeframe)}`,
            { cache: "no-store" }
        );

        if (!response.ok) {
            throw new Error(`Price request failed: ${response.status}`);
        }

        const result = await response.json();
        if (Array.isArray(result)) return result;
        if (result && Array.isArray(result.data)) return result.data;
        return [];
    } catch (error) {
        console.error("Finviz price error for", ticker, error);
        return [];
    }
}

// ---- getFinvizNews() ----

async function getFinvizNews(ticker) {
    try {
        const response = await fetch(
            `http://localhost:3000/finviz-news?ticker=${encodeURIComponent(ticker)}&maxAgeHours=${NEWS_MAX_AGE_HOURS}`,
            { cache: "no-store" }
        );

        if (!response.ok) {
            throw new Error(`News request failed: ${response.status}`);
        }

        const result = await response.json();
        return result && Array.isArray(result.news) ? result.news : [];
    } catch (error) {
        console.error("Finviz news error for", ticker, error);
        return [];
    }
}

// ---- parseMarketDate() ----

function parseMarketDate(dateText) {
    if (!dateText) return null;

    const direct = new Date(dateText);
    if (!isNaN(direct.getTime())) return direct;

    const match = String(dateText).trim().match(
        /^(\d{1,2})\/(\d{1,2})\/(\d{2,4})(?:\s+(\d{1,2}):(\d{2})(?::(\d{2}))?\s*(AM|PM)?)?$/i
    );

    if (!match) return null;

    let year = Number(match[3]);
    let hour = Number(match[4] || 0);
    const minute = Number(match[5] || 0);
    const second = Number(match[6] || 0);
    const meridiem = String(match[7] || "").toUpperCase();

    if (year < 100) year += 2000;
    if (meridiem === "PM" && hour < 12) hour += 12;
    if (meridiem === "AM" && hour === 12) hour = 0;

    return new Date(year, Number(match[1]) - 1, Number(match[2]), hour, minute, second);
}

// ---- isFreshForTimeframe() ----

function isFreshForTimeframe(dateText, timeframe) {
    const marketDate = parseMarketDate(dateText);
    if (!marketDate) return false;

    const ageHours = (Date.now() - marketDate.getTime()) / 3600000;
    const maxHours = {
        "1m": 2,
        "3m": 4,
        "5m": 6,
        "15m": 12,
        "30m": 18,
        "1h": 30,
        "4h": 72,
        "1d": 120,
        "1w": 336,
        "1mo": 1488
    }[timeframe] || 120;

    return ageHours >= -1 && ageHours <= maxHours;
}

// ---- scoreNewsSentiment() ----

function scoreNewsSentiment(newsItems) {
    const positiveWords = [
        "beat", "beats", "raise", "raises", "raised", "upgrade", "upgraded",
        "growth", "record", "surge", "strong", "profit", "bullish",
        "partnership", "deal", "approval", "launch", "outperform", "contract"
    ];
    const negativeWords = [
        "miss", "misses", "cut", "cuts", "downgrade", "downgraded", "lawsuit",
        "probe", "investigation", "recall", "weak", "loss", "bearish",
        "delay", "warning", "fraud", "decline", "drop", "offering", "dilution"
    ];

    let score = 0;
    newsItems.slice(0, 5).forEach(function(item) {
        const title = String(item.title || "").toLowerCase();
        positiveWords.forEach(function(word) {
            if (title.includes(word)) score += 1;
        });
        negativeWords.forEach(function(word) {
            if (title.includes(word)) score -= 1;
        });
    });

    return {
        score: Math.max(-5, Math.min(score, 5)),
        headline: newsItems.length ? newsItems[0].title : "No verified company news in the last 48 hours.",
        count: newsItems.length
    };
}

// ---- calculateSMA() ----

function calculateSMA(prices, period) {
    const values = prices.slice(-Math.min(period, prices.length));
    if (!values.length) return 0;
    return values.reduce(function(sum, value) { return sum + value; }, 0) / values.length;
}

// ---- calculateEMA() ----

function calculateEMA(prices, period) {
    if (!prices.length) return 0;
    const multiplier = 2 / (period + 1);
    let ema = prices[0];
    for (let i = 1; i < prices.length; i++) {
        ema = (prices[i] - ema) * multiplier + ema;
    }
    return ema;
}

// ---- calculateRSI() ----

function calculateRSI(prices, period) {
    if (prices.length < 2) return 50;
    const values = prices.slice(-(period + 1));
    let gains = 0;
    let losses = 0;

    for (let i = 1; i < values.length; i++) {
        const difference = values[i] - values[i - 1];
        if (difference >= 0) gains += difference;
        else losses += Math.abs(difference);
    }

    const divisor = Math.max(1, values.length - 1);
    const averageGain = gains / divisor;
    const averageLoss = losses / divisor;
    if (averageLoss === 0) return 100;
    const rs = averageGain / averageLoss;
    return 100 - (100 / (1 + rs));
}

// ---- calculateATR() ----

function calculateATR(data, period) {
    if (data.length < 2) return 0;
    const values = data.slice(-(period + 1));
    const ranges = [];

    for (let i = 1; i < values.length; i++) {
        const current = values[i];
        const previous = values[i - 1];
        ranges.push(Math.max(
            current.high - current.low,
            Math.abs(current.high - previous.close),
            Math.abs(current.low - previous.close)
        ));
    }

    return ranges.reduce(function(sum, value) { return sum + value; }, 0) / Math.max(1, ranges.length);
}

// ---- calculateAverageVolume() ----

function calculateAverageVolume(data, period) {
    const values = data.slice(-period).map(function(bar) { return Number(bar.volume) || 0; }).filter(Boolean);
    if (!values.length) return 0;
    return values.reduce(function(sum, value) { return sum + value; }, 0) / values.length;
}

// ---- analyzeLiveSetup() ----

function analyzeLiveSetup(ticker, data, news, timeframe) {
    const latest = data[data.length - 1];
    const previous = data[data.length - 2];
    const recent = data.slice(-60);
    const prices = recent.map(function(bar) { return Number(bar.close); });

    const sma9 = calculateSMA(prices, 9);
    const sma20 = calculateSMA(prices, 20);
    const ema12 = calculateEMA(prices.slice(-26), 12);
    const ema26 = calculateEMA(prices.slice(-26), 26);
    const macd = ema12 - ema26;
    const rsi = calculateRSI(prices, 14);
    const atr = calculateATR(recent, 14) || latest.close * 0.01;
    const averageVolume = calculateAverageVolume(recent.slice(0, -1), 20);
    const volumeRatio = averageVolume > 0 ? latest.volume / averageVolume : 1;
    const momentumBase = data[Math.max(0, data.length - 6)].close;
    const momentumPercent = ((latest.close - momentumBase) / momentumBase) * 100;
    const newsData = scoreNewsSentiment(news);

    let score = 20;
    const reasons = [];

    if (latest.close > sma20) { score += 12; reasons.push("price above SMA20"); }
    else score -= 8;

    if (sma9 > sma20) { score += 10; reasons.push("SMA9 above SMA20"); }
    else score -= 5;

    if (macd > 0) { score += 10; reasons.push("positive MACD"); }
    else score -= 6;

    if (momentumPercent > 0) { score += Math.min(12, 5 + Math.abs(momentumPercent) * 2); reasons.push("positive momentum"); }
    else score -= Math.min(10, Math.abs(momentumPercent) * 2);

    if (rsi >= 45 && rsi <= 68) { score += 10; reasons.push("healthy RSI"); }
    else if (rsi > 75) { score -= 12; reasons.push("overbought RSI"); }
    else if (rsi < 30) { score -= 6; reasons.push("weak RSI"); }

    if (volumeRatio >= 1.5) { score += 15; reasons.push("strong relative volume"); }
    else if (volumeRatio >= 1.15) { score += 8; reasons.push("above-average volume"); }
    else if (volumeRatio < 0.65) score -= 8;

    score += newsData.score * 3;
    if (newsData.score > 0) reasons.push("positive 48-hour news");
    if (newsData.score < 0) reasons.push("negative 48-hour news");

    score = Math.max(0, Math.min(100, Math.round(score)));

    const longEntry = Math.max(latest.close, latest.high + atr * 0.05);
    const stop = Math.max(0.0001, longEntry - atr * 1.15);
    const target = longEntry + (longEntry - stop) * 2;

    let action = "WAIT";
    if (score >= 72 && latest.close >= previous.close) action = "BUY";
    else if (score < 42) action = "AVOID";

    return {
        ticker,
        timeframe,
        date: latest.date,
        price: latest.close,
        action,
        score,
        rsi,
        macd,
        sma20,
        volumeRatio,
        atr,
        momentumPercent,
        entry: longEntry,
        stop,
        target,
        newsCount: newsData.count,
        headline: newsData.headline,
        reason: reasons.slice(0, 5).join(", ") || "No strong confirmation yet."
    };
}

// ---- getCurrentMarketMode() ----

function getCurrentMarketMode() {
    const eastern = new Date(new Date().toLocaleString("en-US", { timeZone: "America/New_York" }));
    const day = eastern.getDay();
    const minutes = eastern.getHours() * 60 + eastern.getMinutes();

    if (day === 0 || day === 6 || minutes < 570 || minutes >= 960) return "closed";
    if (minutes <= 630 || minutes >= 900) return "aggressive";
    return "balanced";
}

// ---- getSelectedRiskLevel() ----

function getSelectedRiskLevel() {
    const select = document.getElementById("riskLevel");
    if (!select || select.value === "auto") return getCurrentMarketMode();
    return select.value;
}

// ---- calculatePositionSize() ----

function calculatePositionSize(setup) {
    const mode = getSelectedRiskLevel();
    const riskPercent = mode === "aggressive" ? 0.0125 : mode === "balanced" ? 0.0075 : 0.004;
    const riskBudget = paperPortfolio.cash * riskPercent;
    const riskPerShare = Math.max(setup.entry - setup.stop, 0.01);
    const riskBasedShares = Math.floor(riskBudget / riskPerShare);
    const cashBasedShares = Math.floor((paperPortfolio.cash * 0.25) / setup.entry);
    return Math.max(0, Math.min(riskBasedShares, cashBasedShares));
}

// ---- executePaperDecision() ----

function executePaperDecision(setup) {
    const holding = paperPortfolio.holdings[setup.ticker];
    const candleKey = `${setup.timeframe}|${setup.date}`;

    if (holding && holding.shares > 0) {
        holding.currentPrice = setup.price;

        let exitReason = "";
        if (setup.price <= holding.stop) exitReason = "STOP LOSS";
        else if (setup.price >= holding.target) exitReason = "TARGET HIT";
        else if (setup.score < 42) exitReason = "SETUP WEAKENED";

        if (exitReason && paperPortfolio.lastProcessedCandle[setup.ticker] !== candleKey) {
            const proceeds = holding.shares * setup.price;
            const pnl = (setup.price - holding.avgPrice) * holding.shares;
            paperPortfolio.cash += proceeds;
            paperPortfolio.trades.unshift({
                time: new Date().toLocaleString(),
                marketDate: setup.date,
                ticker: setup.ticker,
                action: "SELL",
                shares: holding.shares,
                price: setup.price,
                pnl,
                reason: exitReason
            });
            delete paperPortfolio.holdings[setup.ticker];
            paperPortfolio.lastProcessedCandle[setup.ticker] = candleKey;
        }
        return;
    }

    if (setup.action !== "BUY" || paperPortfolio.lastProcessedCandle[setup.ticker] === candleKey) return;

    const shares = calculatePositionSize(setup);
    const cost = shares * setup.price;
    if (shares < 1 || cost > paperPortfolio.cash) return;

    paperPortfolio.cash -= cost;
    paperPortfolio.holdings[setup.ticker] = {
        shares,
        avgPrice: setup.price,
        currentPrice: setup.price,
        stop: setup.stop,
        target: setup.target,
        entryDate: setup.date,
        timeframe: setup.timeframe
    };

    paperPortfolio.trades.unshift({
        time: new Date().toLocaleString(),
        marketDate: setup.date,
        ticker: setup.ticker,
        action: "BUY",
        shares,
        price: setup.price,
        pnl: 0,
        reason: `${setup.score}/100: ${setup.reason}`
    });
    paperPortfolio.lastProcessedCandle[setup.ticker] = candleKey;
}

// ---- runAIPaperTrader() ----

async function runAIPaperTrader() {
    if (isTrading) return;
    isTrading = true;

    const timeframe = getDashboardTimeframe();
    const selectedTickers = getSelectedTickers();
    const status = document.getElementById("sentimentText");

    if (!selectedTickers.length) {
        alert("Please select at least one ticker.");
        isTrading = false;
        return;
    }

    if (status) status.innerText = `Refreshing ${timeframe} charts and verified 48-hour news...`;

    try {
        const results = await Promise.all(selectedTickers.map(async function(ticker) {
            const [data, news] = await Promise.all([
                getFinvizChartData(ticker, timeframe),
                getFinvizNews(ticker)
            ]);
            return { ticker, data, news };
        }));

        const setups = [];

        results.forEach(function(result) {
            if (!result.data || result.data.length < 26) return;
            const latest = result.data[result.data.length - 1];
            if (!isFreshForTimeframe(latest.date, timeframe)) return;
            const setup = analyzeLiveSetup(result.ticker, result.data, result.news, timeframe);
            setups.push(setup);
            executePaperDecision(setup);
        });

        setups.sort(function(a, b) { return b.score - a.score; });
        updateDashboard(setups);
    } catch (error) {
        console.error("Dashboard refresh failed:", error);
        if (status) status.innerText = "Unable to refresh current market data.";
    } finally {
        isTrading = false;
        savePortfolio();
    }
}

// ---- getPortfolioValue() ----

function getPortfolioValue() {
    let holdingsValue = 0;
    Object.keys(paperPortfolio.holdings).forEach(function(ticker) {
        const holding = paperPortfolio.holdings[ticker];
        holdingsValue += holding.shares * holding.currentPrice;
    });
    return paperPortfolio.cash + holdingsValue;
}

// ---- updateDashboard() ----

function updateDashboard(setups) {
    const bestPick = setups.length ? setups[0] : null;
    const totalValue = getPortfolioValue();
    const sessionPL = totalValue - paperPortfolio.sessionStartValue;
    const totalPL = totalValue - paperPortfolio.startingCash;

    paperPortfolio.valueHistory.push({ time: new Date().toISOString(), value: totalValue });
    if (paperPortfolio.valueHistory.length > 120) paperPortfolio.valueHistory.shift();

    document.getElementById("portfolioValue").innerText = `$${totalValue.toFixed(2)}`;
    document.getElementById("portfolioChange").innerText = `Cash $${paperPortfolio.cash.toFixed(2)} | Total P/L ${totalPL >= 0 ? "+" : ""}$${totalPL.toFixed(2)}`;
    document.getElementById("dailyPL").innerText = `${sessionPL >= 0 ? "+" : ""}$${sessionPL.toFixed(2)}`;
    document.getElementById("dailyPLPercent").innerText = `${paperPortfolio.sessionStartValue ? (sessionPL / paperPortfolio.sessionStartValue * 100).toFixed(2) : "0.00"}%`;
    document.getElementById("dailyPL").className = sessionPL >= 0 ? "big positive" : "big negative";

    const watchlistRows = setups.map(function(setup) {
        return `<tr>
            <td><b>${setup.ticker}</b></td>
            <td>$${setup.price.toFixed(2)}</td>
            <td>${setup.timeframe}</td>
            <td>${setup.date}</td>
            <td><b>${setup.action}</b></td>
            <td>${setup.score}/100</td>
            <td>${setup.volumeRatio.toFixed(2)}x</td>
            <td>${setup.newsCount}</td>
        </tr>`;
    }).join("");

    document.getElementById("aiWatchlistTable").innerHTML = `<tr>
        <th>Symbol</th><th>Price</th><th>TF</th><th>Latest Candle</th><th>Action</th><th>Score</th><th>Rel Vol</th><th>News</th>
    </tr>${watchlistRows || '<tr><td colspan="8">No fresh supported market setups returned.</td></tr>'}`;

    if (bestPick) {
        document.getElementById("aiConfidence").innerText = `${bestPick.score}%`;
        document.getElementById("aiConfidenceBar").value = bestPick.score;
        document.getElementById("marketSentiment").innerText = bestPick.score >= 72 ? "Opportunity" : bestPick.score >= 50 ? "Mixed" : "Weak";
        document.getElementById("sentimentText").innerText = `${bestPick.ticker}: ${bestPick.reason}. Latest candle ${bestPick.date}.`;
        document.getElementById("topRecommendation").innerText = bestPick.ticker;
        document.getElementById("topAction").innerText = bestPick.action;
        document.getElementById("topConfidence").innerText = `${bestPick.score}/100`;
        document.getElementById("topReason").innerText = `${bestPick.reason}. Entry $${bestPick.entry.toFixed(2)}, stop $${bestPick.stop.toFixed(2)}, target $${bestPick.target.toFixed(2)}. News: ${bestPick.headline}`;
    } else {
        document.getElementById("aiConfidence").innerText = "--";
        document.getElementById("aiConfidenceBar").value = 0;
        document.getElementById("marketSentiment").innerText = "No Fresh Setup";
        document.getElementById("sentimentText").innerText = "No ticker returned enough fresh chart data for the selected timeframe.";
        document.getElementById("topRecommendation").innerText = "None";
        document.getElementById("topAction").innerText = "WAIT";
        document.getElementById("topConfidence").innerText = "--";
        document.getElementById("topReason").innerText = "Waiting for a confirmed setup.";
    }

    let holdingRows = "";
    Object.keys(paperPortfolio.holdings).forEach(function(ticker) {
        const holding = paperPortfolio.holdings[ticker];
        const value = holding.shares * holding.currentPrice;
        const unrealized = (holding.currentPrice - holding.avgPrice) * holding.shares;
        holdingRows += `<tr>
            <td>${ticker}</td><td>${holding.shares}</td><td>$${holding.avgPrice.toFixed(2)}</td>
            <td>$${holding.currentPrice.toFixed(2)}</td><td>$${value.toFixed(2)}</td>
            <td class="${unrealized >= 0 ? "positive" : "negative"}">${unrealized >= 0 ? "+" : ""}$${unrealized.toFixed(2)}</td>
        </tr>`;
    });

    document.getElementById("holdingsTable").innerHTML = `<tr>
        <th>Symbol</th><th>Shares</th><th>Avg Price</th><th>Current</th><th>Value</th><th>Unrealized</th>
    </tr>${holdingRows || '<tr><td colspan="6">No open paper positions.</td></tr>'}`;

    const tradeRows = paperPortfolio.trades.slice(0, 12).map(function(trade) {
        return `<tr>
            <td>${trade.time}</td><td>${trade.marketDate || "--"}</td><td>${trade.ticker}</td>
            <td>${trade.action}</td><td>${trade.shares}</td><td>$${trade.price.toFixed(2)}</td>
            <td class="${trade.pnl >= 0 ? "positive" : "negative"}">${trade.action === "SELL" ? `${trade.pnl >= 0 ? "+" : ""}$${trade.pnl.toFixed(2)}` : "--"}</td>
        </tr>`;
    }).join("");

    document.getElementById("recentTradesTable").innerHTML = `<tr>
        <th>System Time</th><th>Market Candle</th><th>Symbol</th><th>Action</th><th>Shares</th><th>Price</th><th>P/L</th>
    </tr>${tradeRows || '<tr><td colspan="7">No paper trades yet.</td></tr>'}`;

    drawLineChart("portfolioChart", paperPortfolio.valueHistory.map(function(point) { return Number(point.value || point); }));
    savePortfolio();
}

// ---- drawLineChart() ----

function drawLineChart(canvasId, data) {
    const canvas = document.getElementById(canvasId);
    if (!canvas) return;

    const values = (data || []).map(Number).filter(Number.isFinite);
    if (!values.length) values.push(10000);
    if (values.length === 1) values.push(values[0]);

    const rect = canvas.getBoundingClientRect();
    const cssWidth = Math.max(320, Math.floor(rect.width || canvas.parentElement.clientWidth || 600));
    const cssHeight = 220;
    const ratio = Math.max(1, window.devicePixelRatio || 1);

    canvas.style.width = cssWidth + "px";
    canvas.style.height = cssHeight + "px";
    canvas.width = Math.floor(cssWidth * ratio);
    canvas.height = Math.floor(cssHeight * ratio);

    const ctx = canvas.getContext("2d");
    ctx.setTransform(ratio, 0, 0, ratio, 0, 0);

    const width = cssWidth;
    const height = cssHeight;
    const padding = 28;
    const max = Math.max.apply(null, values);
    const min = Math.min.apply(null, values);
    const range = Math.max(max - min, Math.abs(max) * 0.002, 1);

    ctx.clearRect(0, 0, width, height);
    ctx.fillStyle = "#0d1119";
    ctx.fillRect(0, 0, width, height);
    ctx.strokeStyle = "rgba(61,70,92,.48)";
    ctx.lineWidth = 1;
    for (let i = 0; i <= 4; i++) {
        const y = padding + ((height - padding * 2) / 4) * i;
        ctx.beginPath();
        ctx.moveTo(padding, y);
        ctx.lineTo(width - padding, y);
        ctx.stroke();
    }

    ctx.beginPath();
    values.forEach(function(value, index) {
        const x = padding + (index / Math.max(1, values.length - 1)) * (width - padding * 2);
        const y = height - padding - ((value - min) / range) * (height - padding * 2);
        if (index === 0) ctx.moveTo(x, y); else ctx.lineTo(x, y);
    });
    ctx.strokeStyle = "#2962ff";
    ctx.lineWidth = 2.5;
    ctx.stroke();

    ctx.fillStyle = "#aeb6c8";
    ctx.font = "12px system-ui, sans-serif";
    ctx.fillText("$" + max.toFixed(2), 6, padding + 4);
    ctx.fillText("$" + min.toFixed(2), 6, height - padding + 4);
}
// ---- updateLiveClock() ----
function updateLiveClock() {
    const now = new Date();
    const easternText = new Intl.DateTimeFormat("en-US", {
        timeZone: "America/New_York",
        weekday: "short", year: "numeric", month: "short", day: "numeric",
        hour: "numeric", minute: "2-digit", second: "2-digit"
    }).format(now);

    const clock = document.getElementById("dashboardClock");
    if (clock) clock.innerText = `${easternText} ET`;

    const mode = getCurrentMarketMode();
    const modeLabel = document.getElementById("currentMode");
    if (modeLabel) modeLabel.innerText = mode === "closed" ? "Market: Closed" : `Market Mode: ${getSelectedRiskLevel()}`;
}

// ---- startDashboardLiveUpdates() ----

function startDashboardLiveUpdates() {
    clearInterval(liveUpdateInterval);
    liveUpdateInterval = setInterval(runAIPaperTrader, DASHBOARD_REFRESH_MS);
}

// ---- resetPaperPortfolio() ----

function resetPaperPortfolio() {
    if (!confirm("Reset the paper portfolio and delete all paper trades?")) return;
    paperPortfolio = {
        startingCash: 10000,
        cash: 10000,
        holdings: {},
        trades: [],
        valueHistory: [{ time: new Date().toISOString(), value: 10000 }],
        sessionStartValue: 10000,
        lastProcessedCandle: {}
    };
    savePortfolio();
    updateDashboard([]);
}

window.addEventListener("DOMContentLoaded", function() {
    restoreDashboardUIState();

    const savedTimeframe = localStorage.getItem("dashboardTimeframe");
    const timeframe = document.getElementById("dashboardTimeframe");
    if (timeframe && savedTimeframe) timeframe.value = savedTimeframe;
    if (timeframe) timeframe.addEventListener("change", function() {
        localStorage.setItem("dashboardTimeframe", timeframe.value);
        saveDashboardUIState();
        runAIPaperTrader();
    });

    const riskLevel = document.getElementById("riskLevel");
    if (riskLevel) riskLevel.addEventListener("change", function() {
        localStorage.setItem("dashboardRiskLevel", riskLevel.value);
        saveDashboardUIState();
    });
    const savedRisk = localStorage.getItem("dashboardRiskLevel");
    if (riskLevel && savedRisk) riskLevel.value = savedRisk;

    document.querySelectorAll(".tickerCheck").forEach(function(box) {
        box.addEventListener("change", saveDashboardUIState);
    });

    window.addEventListener("beforeunload", saveDashboardUIState);
    document.addEventListener("visibilitychange", function() {
        if (document.hidden) {
            saveDashboardUIState();
        }
    });

    if (!paperPortfolio.sessionStartValue) paperPortfolio.sessionStartValue = getPortfolioValue();

    updateLiveClock();
    clockInterval = setInterval(updateLiveClock, 1000);
    updateDashboard([]);
    runAIPaperTrader();
    startDashboardLiveUpdates();
});
