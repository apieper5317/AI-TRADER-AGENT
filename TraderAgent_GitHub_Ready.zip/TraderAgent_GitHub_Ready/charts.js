/*
 * charts.js
 * Chart utilities: sanitizes market bars and renders price/indicator charts for TraderAgent.
 * Keep configuration secrets in environment variables, not in this source file.
 */


(function () {
    "use strict";

    const charts = {};
    const CHART_STATE_PREFIX = "traderAgentChartState:";

    // ---- libraryReady() ----

    function libraryReady() {
        return Boolean(window.LightweightCharts && window.LightweightCharts.createChart);
    }

    // ---- parseMarketDate() ----

    function parseMarketDate(value) {
        if (!value) return null;

        const text = String(value).trim();
        const direct = new Date(text);
        if (!isNaN(direct.getTime())) return direct;

        const match = text.match(
            /^(\d{1,2})\/(\d{1,2})\/(\d{2,4})(?:\s+(\d{1,2}):(\d{2})(?::(\d{2}))?\s*(AM|PM)?)?$/i
        );

        if (!match) return null;

        let year = Number(match[3]);
        let hour = Number(match[4] || 0);
        const minute = Number(match[5] || 0);
        const second = Number(match[6] || 0);
        const meridiem = String(match[7] || "").toUpperCase();

        if (year < 100) year += 2000;
        if (meridiem === "PM" && hour < 12) hour += 12;
        if (meridiem === "AM" && hour === 12) hour = 0;

        return new Date(
            year,
            Number(match[1]) - 1,
            Number(match[2]),
            hour,
            minute,
            second
        );
    }

    // ---- toChartTime() ----

    function toChartTime(value) {
        const date = parseMarketDate(value);
        if (!date) return null;
        return Math.floor(date.getTime() / 1000);
    }

    // ---- sanitizeBars() ----

    function sanitizeBars(rawData) {
        const byTime = new Map();

        (rawData || []).forEach(function (bar) {
            const time = toChartTime(bar.date || bar.time);
            const open = Number(bar.open);
            const high = Number(bar.high);
            const low = Number(bar.low);
            const close = Number(bar.close);
            const volume = Number(bar.volume) || 0;

            if (
                !time ||
                !Number.isFinite(open) ||
                !Number.isFinite(high) ||
                !Number.isFinite(low) ||
                !Number.isFinite(close)
            ) {
                return;
            }

            byTime.set(time, {
                time: time,
                open: open,
                high: high,
                low: low,
                close: close,
                volume: volume,
                dateText: bar.date || ""
            });
        });

        return Array.from(byTime.values()).sort(function (a, b) {
            return a.time - b.time;
        });
    }

    // ---- calculateSMAData() ----

    function calculateSMAData(bars, period) {
        const output = [];
        let total = 0;
        const queue = [];

        bars.forEach(function (bar) {
            queue.push(bar.close);
            total += bar.close;

            if (queue.length > period) {
                total -= queue.shift();
            }

            if (queue.length === period) {
                output.push({
                    time: bar.time,
                    value: total / period
                });
            }
        });

        return output;
    }

    // ---- calculateEMAData() ----

    function calculateEMAData(bars, period) {
        if (!bars.length) return [];

        const multiplier = 2 / (period + 1);
        let ema = bars[0].close;

        return bars.map(function (bar, index) {
            if (index > 0) {
                ema = (bar.close - ema) * multiplier + ema;
            }

            return {
                time: bar.time,
                value: ema
            };
        });
    }

    // ---- calculateVWAPData() ----

    function calculateVWAPData(bars) {
        let cumulativePriceVolume = 0;
        let cumulativeVolume = 0;

        return bars.map(function (bar) {
            const typicalPrice = (bar.high + bar.low + bar.close) / 3;
            cumulativePriceVolume += typicalPrice * bar.volume;
            cumulativeVolume += bar.volume;

            return {
                time: bar.time,
                value: cumulativeVolume > 0
                    ? cumulativePriceVolume / cumulativeVolume
                    : typicalPrice
            };
        });
    }

    // ---- calculateBollingerData() ----

    function calculateBollingerData(bars, period, multiplier) {
        const middle = [];
        const upper = [];
        const lower = [];

        for (let i = period - 1; i < bars.length; i++) {
            const windowBars = bars.slice(i - period + 1, i + 1);
            const average = windowBars.reduce(function (sum, bar) {
                return sum + bar.close;
            }, 0) / period;

            const variance = windowBars.reduce(function (sum, bar) {
                const difference = bar.close - average;
                return sum + difference * difference;
            }, 0) / period;

            const deviation = Math.sqrt(variance);
            const time = bars[i].time;

            middle.push({ time: time, value: average });
            upper.push({ time: time, value: average + deviation * multiplier });
            lower.push({ time: time, value: average - deviation * multiplier });
        }

        return { middle: middle, upper: upper, lower: lower };
    }

    // ---- calculateRSIData() ----

    function calculateRSIData(bars, period) {
        const output = [];

        for (let i = period; i < bars.length; i++) {
            let gains = 0;
            let losses = 0;

            for (let j = i - period + 1; j <= i; j++) {
                const difference = bars[j].close - bars[j - 1].close;

                if (difference >= 0) gains += difference;
                else losses += Math.abs(difference);
            }

            const averageGain = gains / period;
            const averageLoss = losses / period;
            const rsi = averageLoss === 0
                ? 100
                : 100 - (100 / (1 + averageGain / averageLoss));

            output.push({
                time: bars[i].time,
                value: rsi
            });
        }

        return output;
    }

    // ---- calculateMACDData() ----

    function calculateMACDData(bars) {
        const ema12 = calculateEMAData(bars, 12);
        const ema26 = calculateEMAData(bars, 26);
        const macdMap = new Map();
        const macdValues = [];

        ema12.forEach(function (point) {
            macdMap.set(point.time, { fast: point.value });
        });

        ema26.forEach(function (point) {
            const current = macdMap.get(point.time) || {};
            current.slow = point.value;
            macdMap.set(point.time, current);
        });

        bars.forEach(function (bar) {
            const values = macdMap.get(bar.time);

            if (
                values &&
                Number.isFinite(values.fast) &&
                Number.isFinite(values.slow)
            ) {
                macdValues.push({
                    time: bar.time,
                    value: values.fast - values.slow
                });
            }
        });

        const signalValues = [];
        const multiplier = 2 / 10;
        let signal = macdValues.length ? macdValues[0].value : 0;

        macdValues.forEach(function (point, index) {
            if (index > 0) {
                signal = (point.value - signal) * multiplier + signal;
            }

            signalValues.push({
                time: point.time,
                value: signal
            });
        });

        const signalMap = new Map(signalValues.map(function (point) {
            return [point.time, point.value];
        }));

        const histogram = macdValues.map(function (point) {
            const signalValue = signalMap.get(point.time) || 0;
            const value = point.value - signalValue;

            return {
                time: point.time,
                value: value,
                color: value >= 0
                    ? "rgba(8,153,129,.72)"
                    : "rgba(242,54,69,.72)"
            };
        });

        return {
            macd: macdValues,
            signal: signalValues,
            histogram: histogram
        };
    }

    // ---- chartOptions() ----

    function chartOptions(container, height) {
        return {
            width: Math.max(320, container.clientWidth || 800),
            height: height,
            layout: {
                background: {
                    type: "solid",
                    color: "#0d1119"
                },
                textColor: "#8b93a7",
                attributionLogo: true
            },
            grid: {
                vertLines: { color: "rgba(38,45,61,.44)" },
                horzLines: { color: "rgba(38,45,61,.44)" }
            },
            crosshair: {
                mode: window.LightweightCharts.CrosshairMode.Normal,
                vertLine: {
                    color: "rgba(139,147,167,.55)",
                    labelBackgroundColor: "#2962ff"
                },
                horzLine: {
                    color: "rgba(139,147,167,.55)",
                    labelBackgroundColor: "#2962ff"
                }
            },
            rightPriceScale: {
                borderColor: "#262d3d",
                scaleMargins: {
                    top: 0.08,
                    bottom: 0.28
                }
            },
            timeScale: {
                borderColor: "#262d3d",
                timeVisible: true,
                secondsVisible: false,
                rightOffset: 4,
                barSpacing: 8,
                minBarSpacing: 2,
                fixLeftEdge: false,
                fixRightEdge: false
            },
            handleScroll: {
                mouseWheel: true,
                pressedMouseMove: true,
                horzTouchDrag: true,
                vertTouchDrag: false
            },
            handleScale: {
                axisPressedMouseMove: true,
                mouseWheel: true,
                pinch: true
            },
            localization: {
                priceFormatter: function (price) {
                    if (!Number.isFinite(price)) return "--";
                    return price < 1
                        ? price.toFixed(4)
                        : price.toFixed(2);
                }
            }
        };
    }

    // ---- destroyChart() ----

    function destroyChart(key) {
        const existing = charts[key];

        if (!existing) return;

        if (existing.resizeObserver) {
            existing.resizeObserver.disconnect();
        }

        if (existing.chart) {
            existing.chart.remove();
        }

        delete charts[key];
    }

    // ---- createResponsiveChart() ----

    function createResponsiveChart(key, container, height) {
        destroyChart(key);

        const chart = window.LightweightCharts.createChart(
            container,
            chartOptions(container, height)
        );

        const resizeObserver = new ResizeObserver(function (entries) {
            const entry = entries[0];

            if (entry && entry.contentRect.width > 0) {
                chart.applyOptions({
                    width: entry.contentRect.width
                });
            }
        });

        resizeObserver.observe(container);

        charts[key] = {
            chart: chart,
            resizeObserver: resizeObserver,
            container: container,
            series: {}
        };

        return charts[key];
    }

    // ---- createToolbarIfMissing() ----

    function createToolbarIfMissing(container, key) {
        const parent = container.parentElement;

        if (!parent || parent.querySelector(`[data-chart-toolbar="${key}"]`)) {
            return;
        }

        const toolbar = document.createElement("div");
        toolbar.className = "chart-toolbar";
        toolbar.dataset.chartToolbar = key;
        toolbar.innerHTML = `
            <div class="chart-toolbar-group">
                <button type="button" data-action="fit">Fit</button>
                <button type="button" data-action="reset">Reset zoom</button>
                <button type="button" data-action="fullscreen">Fullscreen</button>
            </div>
            <div class="chart-toolbar-group chart-indicator-toggles">
                <label><input type="checkbox" data-indicator="sma9" checked> SMA 9</label>
                <label><input type="checkbox" data-indicator="sma20" checked> SMA 20</label>
                <label><input type="checkbox" data-indicator="ema21"> EMA 21</label>
                <label><input type="checkbox" data-indicator="vwap" checked> VWAP</label>
                <label><input type="checkbox" data-indicator="bb"> Bollinger</label>
            </div>
        `;

        parent.insertBefore(toolbar, container);

        toolbar.addEventListener("click", function (event) {
            const button = event.target.closest("button");

            if (!button || !charts[key]) return;

            const action = button.dataset.action;

            if (action === "fit" || action === "reset") {
                charts[key].chart.timeScale().fitContent();
            }

            if (action === "fullscreen") {
                const chartPanel = container.closest(".panel") || parent;

                if (document.fullscreenElement) {
                    document.exitFullscreen();
                } else if (chartPanel.requestFullscreen) {
                    chartPanel.requestFullscreen();
                }
            }
        });

        toolbar.addEventListener("change", function (event) {
            const checkbox = event.target.closest("input[data-indicator]");

            if (!checkbox || !charts[key]) return;

            const series = charts[key].series[checkbox.dataset.indicator];

            if (series) {
                series.applyOptions({
                    visible: checkbox.checked
                });
            }

            saveChartState(key);
        });
    }

    // ---- saveChartState() ----

    function saveChartState(key) {
        const instance = charts[key];
        if (!instance) return;

        const toolbar = instance.container.parentElement
            ? instance.container.parentElement.querySelector(
                `[data-chart-toolbar="${key}"]`
            )
            : null;

        const indicators = {};

        if (toolbar) {
            toolbar.querySelectorAll("input[data-indicator]").forEach(function (input) {
                indicators[input.dataset.indicator] = input.checked;
            });
        }

        let visibleRange = null;

        try {
            visibleRange = instance.chart.timeScale().getVisibleLogicalRange();
        } catch (error) {
            visibleRange = null;
        }

        localStorage.setItem(
            CHART_STATE_PREFIX + key,
            JSON.stringify({
                visibleRange: visibleRange,
                indicators: indicators
            })
        );
    }

    // ---- restoreChartState() ----

    function restoreChartState(key) {
        const instance = charts[key];
        if (!instance) return;

        let state = null;

        try {
            state = JSON.parse(
                localStorage.getItem(CHART_STATE_PREFIX + key) || "null"
            );
        } catch (error) {
            state = null;
        }

        if (!state) {
            instance.chart.timeScale().fitContent();
            return;
        }

        const toolbar = instance.container.parentElement
            ? instance.container.parentElement.querySelector(
                `[data-chart-toolbar="${key}"]`
            )
            : null;

        if (toolbar && state.indicators) {
            Object.keys(state.indicators).forEach(function (name) {
                const input = toolbar.querySelector(
                    `input[data-indicator="${name}"]`
                );

                if (input) input.checked = Boolean(state.indicators[name]);

                if (instance.series[name]) {
                    instance.series[name].applyOptions({
                        visible: Boolean(state.indicators[name])
                    });
                }
            });
        }

        if (
            state.visibleRange &&
            Number.isFinite(state.visibleRange.from) &&
            Number.isFinite(state.visibleRange.to)
        ) {
            try {
                instance.chart.timeScale().setVisibleLogicalRange(
                    state.visibleRange
                );
            } catch (error) {
                instance.chart.timeScale().fitContent();
            }
        } else {
            instance.chart.timeScale().fitContent();
        }
    }

    // ---- addLineSeries() ----

    function addLineSeries(chart, color, width, title, visible) {
        return chart.addSeries(window.LightweightCharts.LineSeries, {
            color: color,
            lineWidth: width,
            title: title,
            priceLineVisible: false,
            lastValueVisible: false,
            crosshairMarkerVisible: false,
            visible: visible
        });
    }

    // ---- addPriceLine() ----

    function addPriceLine(series, price, color, title, lineStyle) {
        if (!Number.isFinite(price)) return null;

        return series.createPriceLine({
            price: price,
            color: color,
            lineWidth: 1,
            lineStyle: lineStyle,
            axisLabelVisible: true,
            title: title
        });
    }

    // ---- renderAnalysisChart() ----

    function renderAnalysisChart(rawData, options) {
        options = options || {};

        if (!libraryReady()) {
            console.error("Lightweight Charts library is not loaded.");
            return;
        }

        const container = document.getElementById(
            options.containerId || "stockChart"
        );

        if (!container) return;

        const bars = sanitizeBars(rawData);
        if (bars.length < 2) return;

        container.innerHTML = "";
        createToolbarIfMissing(container, "analysis");

        const instance = createResponsiveChart(
            "analysis",
            container,
            options.height || 500
        );

        const chart = instance.chart;
        const candleSeries = chart.addSeries(
            window.LightweightCharts.CandlestickSeries,
            {
                upColor: "#089981",
                downColor: "#f23645",
                borderUpColor: "#089981",
                borderDownColor: "#f23645",
                wickUpColor: "#089981",
                wickDownColor: "#f23645",
                priceLineVisible: true,
                lastValueVisible: true
            }
        );

        candleSeries.setData(bars.map(function (bar) {
            return {
                time: bar.time,
                open: bar.open,
                high: bar.high,
                low: bar.low,
                close: bar.close
            };
        }));

        const volumeSeries = chart.addSeries(
            window.LightweightCharts.HistogramSeries,
            {
                priceFormat: { type: "volume" },
                priceScaleId: "",
                lastValueVisible: false,
                priceLineVisible: false
            }
        );

        volumeSeries.priceScale().applyOptions({
            scaleMargins: {
                top: 0.74,
                bottom: 0
            }
        });

        volumeSeries.setData(bars.map(function (bar) {
            return {
                time: bar.time,
                value: bar.volume,
                color: bar.close >= bar.open
                    ? "rgba(8,153,129,.48)"
                    : "rgba(242,54,69,.48)"
            };
        }));

        const sma9 = addLineSeries(chart, "#64b5f6", 1, "SMA 9", true);
        const sma20 = addLineSeries(chart, "#f0b90b", 2, "SMA 20", true);
        const ema21 = addLineSeries(chart, "#ab7df6", 1, "EMA 21", false);
        const vwap = addLineSeries(chart, "#ff8c42", 2, "VWAP", true);
        const bbUpper = addLineSeries(chart, "rgba(140,160,255,.58)", 1, "BB Upper", false);
        const bbMiddle = addLineSeries(chart, "rgba(140,160,255,.38)", 1, "BB Middle", false);
        const bbLower = addLineSeries(chart, "rgba(140,160,255,.58)", 1, "BB Lower", false);

        sma9.setData(calculateSMAData(bars, 9));
        sma20.setData(calculateSMAData(bars, 20));
        ema21.setData(calculateEMAData(bars, 21));
        vwap.setData(calculateVWAPData(bars));

        const bollinger = calculateBollingerData(bars, 20, 2);
        bbUpper.setData(bollinger.upper);
        bbMiddle.setData(bollinger.middle);
        bbLower.setData(bollinger.lower);

        instance.series = {
            candles: candleSeries,
            volume: volumeSeries,
            sma9: sma9,
            sma20: sma20,
            ema21: ema21,
            vwap: vwap,
            bb: {
                applyOptions: function (settings) {
                    bbUpper.applyOptions(settings);
                    bbMiddle.applyOptions(settings);
                    bbLower.applyOptions(settings);
                }
            }
        };

        addPriceLine(
            candleSeries,
            bars[bars.length - 1].close,
            "#2962ff",
            "Current",
            window.LightweightCharts.LineStyle.Dashed
        );

        if (options.tradePlan) {
            addPriceLine(
                candleSeries,
                Number(options.tradePlan.entry),
                "#2962ff",
                "Entry",
                window.LightweightCharts.LineStyle.Dashed
            );
            addPriceLine(
                candleSeries,
                Number(options.tradePlan.stop),
                "#f23645",
                "Stop",
                window.LightweightCharts.LineStyle.Dashed
            );
            addPriceLine(
                candleSeries,
                Number(options.tradePlan.target),
                "#089981",
                "Target",
                window.LightweightCharts.LineStyle.Dashed
            );
        }

        const legend = document.getElementById("analysisChartLegend");

        chart.subscribeCrosshairMove(function (param) {
            if (!legend) return;

            if (!param || !param.time) {
                legend.innerHTML = "Move the crosshair over a candle for OHLCV values.";
                return;
            }

            const candle = param.seriesData.get(candleSeries);
            const volume = param.seriesData.get(volumeSeries);

            if (!candle) return;

            legend.innerHTML = `
                <b>O</b> ${Number(candle.open).toFixed(2)}
                <b>H</b> ${Number(candle.high).toFixed(2)}
                <b>L</b> ${Number(candle.low).toFixed(2)}
                <b>C</b> ${Number(candle.close).toFixed(2)}
                <b>V</b> ${volume && Number.isFinite(volume.value)
                    ? Number(volume.value).toLocaleString()
                    : "--"}
            `;
        });

        renderRSIChart(bars);
        renderMACDChart(bars);

        chart.timeScale().subscribeVisibleLogicalRangeChange(function () {
            saveChartState("analysis");
        });

        restoreChartState("analysis");
    }

    // ---- renderRSIChart() ----

    function renderRSIChart(bars) {
        const container = document.getElementById("rsiChartPanel");
        if (!container || !libraryReady()) return;

        container.innerHTML = "";

        const instance = createResponsiveChart("rsi", container, 150);
        const chart = instance.chart;
        chart.applyOptions({
            rightPriceScale: {
                scaleMargins: { top: 0.12, bottom: 0.12 },
                borderColor: "#262d3d"
            }
        });

        const rsiSeries = addLineSeries(chart, "#ab7df6", 2, "RSI 14", true);
        rsiSeries.setData(calculateRSIData(bars, 14));

        addPriceLine(
            rsiSeries,
            70,
            "#f23645",
            "70",
            window.LightweightCharts.LineStyle.Dashed
        );
        addPriceLine(
            rsiSeries,
            50,
            "#626b80",
            "50",
            window.LightweightCharts.LineStyle.Dotted
        );
        addPriceLine(
            rsiSeries,
            30,
            "#089981",
            "30",
            window.LightweightCharts.LineStyle.Dashed
        );

        chart.timeScale().fitContent();
    }

    // ---- renderMACDChart() ----

    function renderMACDChart(bars) {
        const container = document.getElementById("macdChartPanel");
        if (!container || !libraryReady()) return;

        container.innerHTML = "";

        const instance = createResponsiveChart("macd", container, 170);
        const chart = instance.chart;
        const values = calculateMACDData(bars);

        const histogram = chart.addSeries(
            window.LightweightCharts.HistogramSeries,
            {
                priceLineVisible: false,
                lastValueVisible: false
            }
        );
        histogram.setData(values.histogram);

        const macdLine = addLineSeries(chart, "#2962ff", 2, "MACD", true);
        const signalLine = addLineSeries(chart, "#f0b90b", 1, "Signal", true);

        macdLine.setData(values.macd);
        signalLine.setData(values.signal);

        addPriceLine(
            macdLine,
            0,
            "#626b80",
            "0",
            window.LightweightCharts.LineStyle.Dotted
        );

        chart.timeScale().fitContent();
    }

    // ---- convertMarkers() ----

    function convertMarkers(markers, bars) {
        return (markers || []).map(function (marker) {
            const bar = bars[marker.index];

            if (!bar) return null;

            const isBuy = String(marker.type).toUpperCase() === "BUY";

            return {
                time: bar.time,
                position: isBuy ? "belowBar" : "aboveBar",
                color: isBuy ? "#089981" : "#f23645",
                shape: isBuy ? "arrowUp" : "arrowDown",
                text: isBuy ? "BUY" : "SELL"
            };
        }).filter(Boolean);
    }

    // ---- renderBacktestChart() ----

    function renderBacktestChart(rawData, markers, options) {
        options = options || {};

        if (!libraryReady()) return;

        const container = document.getElementById(
            options.containerId || "backtestMarketChart"
        );

        if (!container) return;

        const bars = sanitizeBars(rawData);
        if (!bars.length) return;

        container.innerHTML = "";

        const instance = createResponsiveChart(
            "backtest",
            container,
            options.height || 500
        );
        const chart = instance.chart;

        const candleSeries = chart.addSeries(
            window.LightweightCharts.CandlestickSeries,
            {
                upColor: "#089981",
                downColor: "#f23645",
                borderUpColor: "#089981",
                borderDownColor: "#f23645",
                wickUpColor: "#089981",
                wickDownColor: "#f23645"
            }
        );

        candleSeries.setData(bars.map(function (bar) {
            return {
                time: bar.time,
                open: bar.open,
                high: bar.high,
                low: bar.low,
                close: bar.close
            };
        }));

        const volumeSeries = chart.addSeries(
            window.LightweightCharts.HistogramSeries,
            {
                priceFormat: { type: "volume" },
                priceScaleId: "",
                priceLineVisible: false,
                lastValueVisible: false
            }
        );

        volumeSeries.priceScale().applyOptions({
            scaleMargins: {
                top: 0.76,
                bottom: 0
            }
        });

        volumeSeries.setData(bars.map(function (bar) {
            return {
                time: bar.time,
                value: bar.volume,
                color: bar.close >= bar.open
                    ? "rgba(8,153,129,.46)"
                    : "rgba(242,54,69,.46)"
            };
        }));

        const sma9 = addLineSeries(chart, "#64b5f6", 1, "SMA 9", true);
        const sma20 = addLineSeries(chart, "#f0b90b", 2, "SMA 20", true);
        sma9.setData(calculateSMAData(bars, 9));
        sma20.setData(calculateSMAData(bars, 20));

        const markerData = convertMarkers(markers, bars);

        if (
            markerData.length &&
            typeof window.LightweightCharts.createSeriesMarkers === "function"
        ) {
            instance.markerApi = window.LightweightCharts.createSeriesMarkers(
                candleSeries,
                markerData
            );
        }

        instance.series = {
            candles: candleSeries,
            volume: volumeSeries,
            sma9: sma9,
            sma20: sma20
        };

        chart.timeScale().fitContent();
    }

    // ---- renderEquityChart() ----

    function renderEquityChart(points, options) {
        options = options || {};

        if (!libraryReady()) return;

        const container = document.getElementById(
            options.containerId || "backtestChart"
        );

        if (!container) return;

        const data = (points || []).map(function (point, index) {
            let value;
            let timeValue;

            if (typeof point === "number") {
                value = point;
                timeValue = Math.floor(Date.now() / 1000) + index;
            } else {
                value = Number(point.value || point.equity);
                timeValue = toChartTime(point.date || point.time) ||
                    Math.floor(Date.now() / 1000) + index;
            }

            return {
                time: timeValue,
                value: value
            };
        }).filter(function (point) {
            return Number.isFinite(point.value);
        });

        if (!data.length) return;

        container.innerHTML = "";

        const instance = createResponsiveChart(
            "equity",
            container,
            options.height || 280
        );

        const series = instance.chart.addSeries(
            window.LightweightCharts.AreaSeries,
            {
                lineColor: "#2962ff",
                topColor: "rgba(41,98,255,.42)",
                bottomColor: "rgba(41,98,255,.04)",
                lineWidth: 2,
                priceLineVisible: false
            }
        );

        series.setData(data);
        instance.chart.timeScale().fitContent();
    }

    window.TraderCharts = {
        renderAnalysisChart: renderAnalysisChart,
        renderBacktestChart: renderBacktestChart,
        renderEquityChart: renderEquityChart,
        saveChartState: saveChartState
    };

    // Override the legacy canvas drawing functions after script.js loads.
    window.drawBacktestMarketChart = function (canvasId, data, markers) {
        renderBacktestChart(data, markers, {
            containerId: canvasId,
            height: 500
        });
    };

    window.drawBacktestEquityChart = function (canvasId, points) {
        renderEquityChart(points, {
            containerId: canvasId,
            height: 280
        });
    };

    window.addEventListener("beforeunload", function () {
        saveChartState("analysis");
    });
})();

/* TraderAgent reliable SVG chart fallback.
   This block intentionally overrides only the shared chart rendering methods.
   It does not touch the AI Agent scanner, ranking logic, or market-scan route. */
(function () {
    "use strict";

    const SVG_NS = "http://www.w3.org/2000/svg";

    // ---- number() ----

    function number(value, fallback) {
        const parsed = Number(value);
        return Number.isFinite(parsed) ? parsed : (fallback || 0);
    }

    // ---- parseDate() ----

    function parseDate(value, fallbackIndex) {
        const direct = new Date(value);
        if (!isNaN(direct.getTime())) return direct.getTime();

        const text = String(value || "").trim();
        const match = text.match(/^(\d{1,2})\/(\d{1,2})\/(\d{2,4})(?:\s+(\d{1,2}):(\d{2})(?::(\d{2}))?\s*(AM|PM)?)?$/i);
        if (match) {
            let year = Number(match[3]);
            let hour = Number(match[4] || 0);
            const minute = Number(match[5] || 0);
            const second = Number(match[6] || 0);
            const meridiem = String(match[7] || "").toUpperCase();
            if (year < 100) year += 2000;
            if (meridiem === "PM" && hour < 12) hour += 12;
            if (meridiem === "AM" && hour === 12) hour = 0;
            return new Date(year, Number(match[1]) - 1, Number(match[2]), hour, minute, second).getTime();
        }
        return fallbackIndex;
    }

    // ---- cleanBars() ----

    function cleanBars(rawData) {
        return (rawData || []).map(function (bar, index) {
            return {
                time: parseDate(bar.date || bar.time, index),
                date: bar.date || bar.time || "",
                open: number(bar.open),
                high: number(bar.high),
                low: number(bar.low),
                close: number(bar.close),
                volume: Math.max(0, number(bar.volume))
            };
        }).filter(function (bar) {
            return Number.isFinite(bar.time) &&
                Number.isFinite(bar.open) && Number.isFinite(bar.high) &&
                Number.isFinite(bar.low) && Number.isFinite(bar.close) &&
                bar.high >= Math.max(bar.open, bar.close, bar.low) &&
                bar.low <= Math.min(bar.open, bar.close, bar.high);
        }).sort(function (a, b) { return a.time - b.time; });
    }

    // ---- svgElement() ----

    function svgElement(name, attrs) {
        const el = document.createElementNS(SVG_NS, name);
        Object.keys(attrs || {}).forEach(function (key) {
            el.setAttribute(key, String(attrs[key]));
        });
        return el;
    }

    // ---- getSize() ----

    function getSize(container, requestedHeight) {
        const width = Math.max(360, Math.floor(container.getBoundingClientRect().width || container.clientWidth || 900));
        const height = Math.max(220, Number(requestedHeight) || Math.floor(container.getBoundingClientRect().height) || 500);
        return { width: width, height: height };
    }

    // ---- createBase() ----

    function createBase(container, height) {
        container.innerHTML = "";
        container.style.position = "relative";
        container.style.minHeight = height + "px";
        const size = getSize(container, height);
        const svg = svgElement("svg", {
            viewBox: `0 0 ${size.width} ${size.height}`,
            width: "100%",
            height: size.height,
            preserveAspectRatio: "none",
            role: "img"
        });
        svg.style.display = "block";
        svg.style.background = "#0d1119";
        container.appendChild(svg);
        return { svg: svg, width: size.width, height: size.height };
    }

    // ---- drawGrid() ----

    function drawGrid(svg, width, height, margin) {
        for (let i = 0; i <= 5; i++) {
            const y = margin.top + ((height - margin.top - margin.bottom) / 5) * i;
            svg.appendChild(svgElement("line", {
                x1: margin.left, y1: y, x2: width - margin.right, y2: y,
                stroke: "rgba(61,70,92,.48)", "stroke-width": 1
            }));
        }
        for (let i = 0; i <= 6; i++) {
            const x = margin.left + ((width - margin.left - margin.right) / 6) * i;
            svg.appendChild(svgElement("line", {
                x1: x, y1: margin.top, x2: x, y2: height - margin.bottom,
                stroke: "rgba(43,51,69,.32)", "stroke-width": 1
            }));
        }
    }

    // ---- calculateSMA() ----

    function calculateSMA(bars, period) {
        const result = [];
        let sum = 0;
        const queue = [];
        bars.forEach(function (bar, index) {
            queue.push(bar.close); sum += bar.close;
            if (queue.length > period) sum -= queue.shift();
            result.push(queue.length === period ? { index: index, value: sum / period } : null);
        });
        return result.filter(Boolean);
    }

    // ---- drawPath() ----

    function drawPath(svg, points, stroke, width) {
        if (!points.length) return;
        const d = points.map(function (point, index) {
            return `${index === 0 ? "M" : "L"}${point.x.toFixed(2)},${point.y.toFixed(2)}`;
        }).join(" ");
        svg.appendChild(svgElement("path", {
            d: d, fill: "none", stroke: stroke, "stroke-width": width || 2,
            "vector-effect": "non-scaling-stroke"
        }));
    }

    // ---- renderCandles() ----

    function renderCandles(rawData, options) {
        options = options || {};
        const container = document.getElementById(options.containerId || "stockChart");
        if (!container) return false;
        const bars = cleanBars(rawData);
        if (bars.length < 2) {
            container.innerHTML = '<div class="chart-render-message">Not enough candle data to draw the chart.</div>';
            return false;
        }

        const height = options.height || 500;
        const base = createBase(container, height);
        const svg = base.svg;
        const margin = { top: 22, right: 70, bottom: 30, left: 18 };
        drawGrid(svg, base.width, base.height, margin);

        const visible = bars.slice(-Math.min(140, bars.length));
        const minPrice = Math.min.apply(null, visible.map(function (b) { return b.low; }));
        const maxPrice = Math.max.apply(null, visible.map(function (b) { return b.high; }));
        const priceRange = Math.max(maxPrice - minPrice, Math.abs(maxPrice) * 0.001, 0.0001);
        const chartWidth = base.width - margin.left - margin.right;
        const priceHeight = (base.height - margin.top - margin.bottom) * 0.78;
        const volumeTop = margin.top + priceHeight + 10;
        const volumeHeight = base.height - margin.bottom - volumeTop;
        const step = chartWidth / visible.length;
        const bodyWidth = Math.max(2, Math.min(12, step * 0.62));
        const maxVolume = Math.max.apply(null, visible.map(function (b) { return b.volume; }).concat([1]));
        const yPrice = function (price) {
            return margin.top + ((maxPrice - price) / priceRange) * priceHeight;
        };

        visible.forEach(function (bar, index) {
            const x = margin.left + step * index + step / 2;
            const rising = bar.close >= bar.open;
            const color = rising ? "#089981" : "#f23645";
            svg.appendChild(svgElement("line", {
                x1: x, y1: yPrice(bar.high), x2: x, y2: yPrice(bar.low),
                stroke: color, "stroke-width": 1.2
            }));
            const bodyTop = yPrice(Math.max(bar.open, bar.close));
            const bodyBottom = yPrice(Math.min(bar.open, bar.close));
            svg.appendChild(svgElement("rect", {
                x: x - bodyWidth / 2, y: bodyTop,
                width: bodyWidth, height: Math.max(1.5, bodyBottom - bodyTop),
                fill: color, rx: 0.6
            }));
            const volumeBarHeight = (bar.volume / maxVolume) * volumeHeight;
            svg.appendChild(svgElement("rect", {
                x: x - bodyWidth / 2, y: base.height - margin.bottom - volumeBarHeight,
                width: bodyWidth, height: volumeBarHeight,
                fill: rising ? "rgba(8,153,129,.38)" : "rgba(242,54,69,.38)"
            }));
        });

        [
            { period: 9, color: "#64b5f6" },
            { period: 20, color: "#f0b90b" }
        ].forEach(function (config) {
            const sma = calculateSMA(visible, config.period).map(function (point) {
                return {
                    x: margin.left + step * point.index + step / 2,
                    y: yPrice(point.value)
                };
            });
            drawPath(svg, sma, config.color, config.period === 20 ? 2 : 1.4);
        });

        for (let i = 0; i <= 4; i++) {
            const price = maxPrice - (priceRange / 4) * i;
            const text = svgElement("text", {
                x: base.width - margin.right + 8,
                y: yPrice(price) + 4,
                fill: "#aeb6c8", "font-size": 11
            });
            text.textContent = price.toFixed(price >= 100 ? 2 : 3);
            svg.appendChild(text);
        }

        const legend = document.getElementById("analysisChartLegend");
        if (legend) {
            legend.textContent = `Showing ${visible.length} candles • SMA 9 • SMA 20 • Volume`;
        }
        return true;
    }

    // ---- renderLine() ----

    function renderLine(points, options) {
        options = options || {};
        const container = document.getElementById(options.containerId || "backtestChart");
        if (!container) return false;
        const values = (points || []).map(function (point, index) {
            const value = typeof point === "number" ? point : number(point.value != null ? point.value : point.equity, NaN);
            return { index: index, value: value };
        }).filter(function (point) { return Number.isFinite(point.value); });
        if (!values.length) {
            container.innerHTML = '<div class="chart-render-message">No equity data available yet.</div>';
            return false;
        }
        if (values.length === 1) values.push({ index: 1, value: values[0].value });
        const base = createBase(container, options.height || 280);
        const margin = { top: 20, right: 24, bottom: 24, left: 54 };
        drawGrid(base.svg, base.width, base.height, margin);
        const min = Math.min.apply(null, values.map(function (p) { return p.value; }));
        const max = Math.max.apply(null, values.map(function (p) { return p.value; }));
        const range = Math.max(max - min, Math.abs(max) * 0.002, 1);
        const width = base.width - margin.left - margin.right;
        const height = base.height - margin.top - margin.bottom;
        const pathPoints = values.map(function (point, index) {
            return {
                x: margin.left + (index / Math.max(1, values.length - 1)) * width,
                y: margin.top + ((max - point.value) / range) * height
            };
        });
        drawPath(base.svg, pathPoints, "#2962ff", 2.5);
        return true;
    }

    // ---- safeRenderAnalysis() ----

    function safeRenderAnalysis(data, options) {
        try { return renderCandles(data, options); }
        catch (error) { console.error("Analysis chart fallback error:", error); return false; }
    }
    // ---- safeRenderBacktest() ----
    function safeRenderBacktest(data, markers, options) {
        try { return renderCandles(data, options); }
        catch (error) { console.error("Backtest chart fallback error:", error); return false; }
    }
    // ---- safeRenderEquity() ----
    function safeRenderEquity(points, options) {
        try { return renderLine(points, options); }
        catch (error) { console.error("Equity chart fallback error:", error); return false; }
    }

    window.TraderCharts = window.TraderCharts || {};
    window.TraderCharts.renderAnalysisChart = safeRenderAnalysis;
    window.TraderCharts.renderBacktestChart = safeRenderBacktest;
    window.TraderCharts.renderEquityChart = safeRenderEquity;

    window.drawBacktestMarketChart = function (containerId, data, markers) {
        return safeRenderBacktest(data, markers, { containerId: containerId, height: 500 });
    };
    window.drawBacktestEquityChart = function (containerId, points) {
        return safeRenderEquity(points, { containerId: containerId, height: 280 });
    };
})();
