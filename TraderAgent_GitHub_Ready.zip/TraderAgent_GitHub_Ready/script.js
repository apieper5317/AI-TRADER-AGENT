/*
 * script.js
 * Main client logic shared by analysis, backtesting, watchlist, settings, and AI-agent pages.
 * Keep configuration secrets in environment variables, not in this source file.
 */

let liveUpdateInterval;


const TRADER_AGENT_PAGE_STATE_PREFIX = "traderAgentPageState:";
const TRADER_AGENT_ANALYSIS_STATE_KEY = "traderAgentAnalysisStateV2";
const TRADER_AGENT_BACKTEST_STATE_KEY = "traderAgentBacktestStateV2";

let backtestState = {
    data: [],
    index: 0,
    timer: null,
    running: false,
    finished: false,
    ticker: "",
    timeframe: "5m",
    strategy: "momentum",
    startingCash: 10000,
    cash: 10000,
    position: null,
    trades: [],
    equityCurve: [],
    markers: [],
    settings: {
        positionSize: 0.5,
        stopLossPercent: 1,
        takeProfitPercent: 2
    },
    replayDelay: 200,
    lastSavedAt: 0
};

// ---- safeJSONParse() ----

function safeJSONParse(value, fallback) {
    try {
        return value ? JSON.parse(value) : fallback;
    } catch (error) {
        console.error("Unable to parse saved TraderAgent state:", error);
        return fallback;
    }
}

// ---- getCurrentPageStateKey() ----

function getCurrentPageStateKey() {
    const pageName = window.location.pathname.split("/").pop() || "index.html";
    return TRADER_AGENT_PAGE_STATE_PREFIX + pageName;
}

// ---- saveGenericPageState() ----

function saveGenericPageState() {
    const state = {
        scrollY: window.scrollY,
        fields: {}
    };

    document.querySelectorAll("input[id], select[id], textarea[id]").forEach(function(element) {
        if (element.type === "file" || element.type === "password") {
            return;
        }

        if (element.type === "checkbox" || element.type === "radio") {
            state.fields[element.id] = {
                type: element.type,
                checked: element.checked
            };
        } else {
            state.fields[element.id] = {
                type: element.type || element.tagName,
                value: element.value
            };
        }
    });

    localStorage.setItem(getCurrentPageStateKey(), JSON.stringify(state));
}

// ---- restoreGenericPageState() ----

function restoreGenericPageState() {
    const state = safeJSONParse(
        localStorage.getItem(getCurrentPageStateKey()),
        null
    );

    if (!state) {
        return;
    }

    Object.keys(state.fields || {}).forEach(function(id) {
        const element = document.getElementById(id);
        const saved = state.fields[id];

        if (!element || !saved) {
            return;
        }

        if (saved.type === "checkbox" || saved.type === "radio") {
            element.checked = Boolean(saved.checked);
        } else if (saved.value !== undefined) {
            element.value = saved.value;
        }
    });

    requestAnimationFrame(function() {
        window.scrollTo(0, Number(state.scrollY) || 0);
    });
}

// ---- attachGenericPageStateListeners() ----

function attachGenericPageStateListeners() {
    document.addEventListener("change", saveGenericPageState);
    document.addEventListener("input", function(event) {
        if (event.target && event.target.matches("input[id], select[id], textarea[id]")) {
            saveGenericPageState();
        }
    });

    window.addEventListener("beforeunload", function() {
        saveGenericPageState();
        saveAnalysisPageState();
        saveBacktestState();
    });

    document.addEventListener("visibilitychange", function() {
        if (document.hidden) {
            saveGenericPageState();
            saveAnalysisPageState();
            saveBacktestState();
        }
    });
}


// ---- getSelectedTimeframe() ----


function getSelectedTimeframe() {
    const timeframeSelect = document.getElementById("timeframe");

    if (!timeframeSelect) {
        return "1d";
    }

    return timeframeSelect.value;
}

// ---- getFinvizChartData() ----

async function getFinvizChartData(ticker, timeframe = "1d") {
    const response = await fetch(
        `http://localhost:3000/finviz?ticker=${encodeURIComponent(ticker)}&timeframe=${encodeURIComponent(timeframe)}`,
        { cache: "no-store" }
    );

    let result;
    try {
        result = await response.json();
    } catch (error) {
        throw new Error(`The market-data server returned an unreadable response (${response.status}).`);
    }

    if (!response.ok) {
        throw new Error((result && result.error) || `Market-data request failed with status ${response.status}.`);
    }

    if (Array.isArray(result)) return result;
    if (result && Array.isArray(result.data)) return result.data;

    throw new Error("The market-data server returned no candle array.");
}

// ---- getFinvizNews() ----

async function getFinvizNews(ticker, maximumAgeHours = 48) {
    try {
        const response = await fetch(
            `http://localhost:3000/finviz-news?ticker=${encodeURIComponent(ticker)}&maxAgeHours=${maximumAgeHours}`
        );

        if (!response.ok) {
            throw new Error(`News request failed: ${response.status}`);
        }

        const result = await response.json();

        if (!result || !Array.isArray(result.news)) {
            return [];
        }

        return filterRecentNews(result.news, maximumAgeHours);

    } catch (error) {
        console.error("News error for", ticker, error);
        return [];
    }
}

// ---- filterRecentNews() ----

function filterRecentNews(newsItems, maximumAgeHours) {
    const now = new Date();

    return newsItems.filter(function(item) {
        const newsDate = parseNewsDateTime(item.date);

        // Reject headlines when their date cannot be verified.
        if (!newsDate || isNaN(newsDate.getTime())) {
            return false;
        }

        const ageMilliseconds = now.getTime() - newsDate.getTime();
        const ageHours = ageMilliseconds / (1000 * 60 * 60);

        return ageHours >= 0 && ageHours <= maximumAgeHours;
    });
}

// ---- parseNewsDateTime() ----

function parseNewsDateTime(dateText) {
    if (!dateText) {
        return null;
    }

    const cleanedDate = String(dateText).trim();
    const now = new Date();

    // Handles values such as "Today 10:30 AM".
    if (/^today/i.test(cleanedDate)) {
        const timeText = cleanedDate.replace(/^today/i, "").trim();
        return applyTimeToDate(now, timeText);
    }

    // Handles values such as "Yesterday 3:15 PM".
    if (/^yesterday/i.test(cleanedDate)) {
        const yesterday = new Date(now);
        yesterday.setDate(yesterday.getDate() - 1);

        const timeText = cleanedDate.replace(/^yesterday/i, "").trim();
        return applyTimeToDate(yesterday, timeText);
    }

    // Handles standard ISO and browser-readable date formats.
    const standardDate = new Date(cleanedDate);

    if (!isNaN(standardDate.getTime())) {
        return standardDate;
    }

    // Handles MM/DD/YYYY HH:MM AM/PM.
    const match = cleanedDate.match(
        /^(\d{1,2})\/(\d{1,2})\/(\d{2,4})(?:\s+(\d{1,2}):(\d{2})(?:\s*(AM|PM))?)?$/i
    );

    if (!match) {
        return null;
    }

    let year = Number(match[3]);
    let hour = Number(match[4] || 0);
    const minute = Number(match[5] || 0);
    const meridiem = (match[6] || "").toUpperCase();

    if (year < 100) {
        year += 2000;
    }

    if (meridiem === "PM" && hour < 12) {
        hour += 12;
    }

    if (meridiem === "AM" && hour === 12) {
        hour = 0;
    }

    return new Date(
        year,
        Number(match[1]) - 1,
        Number(match[2]),
        hour,
        minute
    );
}

// ---- applyTimeToDate() ----

function applyTimeToDate(baseDate, timeText) {
    const result = new Date(baseDate);

    if (!timeText) {
        result.setHours(0, 0, 0, 0);
        return result;
    }

    const match = timeText.match(
        /^(\d{1,2}):(\d{2})(?:\s*(AM|PM))?$/i
    );

    if (!match) {
        return null;
    }

    let hour = Number(match[1]);
    const minute = Number(match[2]);
    const meridiem = (match[3] || "").toUpperCase();

    if (meridiem === "PM" && hour < 12) {
        hour += 12;
    }

    if (meridiem === "AM" && hour === 12) {
        hour = 0;
    }

    result.setHours(hour, minute, 0, 0);
    return result;
}

// ---- parseFinvizDate() ----

function parseFinvizDate(dateText) {
    if (!dateText) return null;

    const parts = dateText.split("/");

    if (parts.length !== 3) return null;

    const month = Number(parts[0]) - 1;
    const day = Number(parts[1]);
    let year = Number(parts[2]);

    if (year < 100) {
        year += 2000;
    }

    return new Date(year, month, day);
}

// ---- isRecentMarketData() ----

function isRecentMarketData(latestDateText) {
    const latestDate = parseFinvizDate(latestDateText);

    if (!latestDate) {
        return true;
    }

    const now = new Date();
    const ageDays = (now - latestDate) / (1000 * 60 * 60 * 24);

    return ageDays <= 4;
}

// ---- scoreNewsSentiment() ----

function scoreNewsSentiment(newsItems) {
    const positiveWords = [
        "beat", "beats", "raise", "raises", "raised", "upgrade", "upgraded",
        "growth", "record", "surge", "surges", "strong", "profit", "profits",
        "bullish", "partnership", "deal", "approval", "launch", "outperform"
    ];

    const negativeWords = [
        "miss", "misses", "cut", "cuts", "downgrade", "downgraded", "lawsuit",
        "probe", "investigation", "recall", "weak", "loss", "losses", "bearish",
        "delay", "delays", "warning", "fraud", "decline", "falls", "drop", "drops"
    ];

    let score = 0;
    let matched = [];

    newsItems.slice(0, 5).forEach(function(item) {
        const title = (item.title || "").toLowerCase();

        positiveWords.forEach(function(word) {
            if (title.includes(word)) {
                score += 1;
                matched.push(`positive: ${word}`);
            }
        });

        negativeWords.forEach(function(word) {
            if (title.includes(word)) {
                score -= 1;
                matched.push(`negative: ${word}`);
            }
        });
    });

    score = Math.max(-5, Math.min(score, 5));

    let summary = "No major news signal detected.";

    if (newsItems.length > 0) {
        summary = newsItems[0].title;
    }

    return {
        score: score,
        summary: summary,
        matched: matched.slice(0, 4)
    };
}


// ---- saveAnalysisPageState() ----


function saveAnalysisPageState(extraState) {
    const tickerInput = document.getElementById("tickerInput");

    if (!tickerInput) {
        return;
    }

    const existing = safeJSONParse(
        localStorage.getItem(TRADER_AGENT_ANALYSIS_STATE_KEY),
        {}
    );

    const state = Object.assign({}, existing, extraState || {}, {
        ticker: tickerInput.value,
        timeframe: document.getElementById("timeframe")
            ? document.getElementById("timeframe").value
            : "1d",
        recommendation: document.getElementById("recommendation")
            ? document.getElementById("recommendation").innerText
            : "",
        confidence: document.getElementById("confidence")
            ? document.getElementById("confidence").innerText
            : "",
        confidenceValue: document.getElementById("confidenceBar")
            ? document.getElementById("confidenceBar").value
            : 0,
        reasoningHTML: document.getElementById("reasoning")
            ? document.getElementById("reasoning").innerHTML
            : "",
        rsi: document.getElementById("rsiValue")
            ? document.getElementById("rsiValue").innerText
            : "",
        macd: document.getElementById("macdValue")
            ? document.getElementById("macdValue").innerText
            : "",
        sma: document.getElementById("smaValue")
            ? document.getElementById("smaValue").innerText
            : "",
        csvReportHTML: document.getElementById("csvReport")
            ? document.getElementById("csvReport").innerHTML
            : "",
        researchURL: document.getElementById("researchUrl")
            ? document.getElementById("researchUrl").value
            : "",
        researchText: document.getElementById("researchText")
            ? document.getElementById("researchText").value
            : "",
        researchOutputHTML: document.getElementById("researchOutput")
            ? document.getElementById("researchOutput").innerHTML
            : "",
        savedAt: Date.now()
    });

    localStorage.setItem(
        TRADER_AGENT_ANALYSIS_STATE_KEY,
        JSON.stringify(state)
    );
}

// ---- restoreAnalysisPageState() ----

function restoreAnalysisPageState() {
    const tickerInput = document.getElementById("tickerInput");

    if (!tickerInput) {
        return false;
    }

    const state = safeJSONParse(
        localStorage.getItem(TRADER_AGENT_ANALYSIS_STATE_KEY),
        null
    );

    if (!state) {
        return false;
    }

    tickerInput.value = state.ticker || tickerInput.value;

    const timeframe = document.getElementById("timeframe");
    if (timeframe && state.timeframe) {
        timeframe.value = state.timeframe;
    }

    if (document.getElementById("recommendation") && state.recommendation) {
        document.getElementById("recommendation").innerText = state.recommendation;
    }

    if (document.getElementById("confidence") && state.confidence) {
        document.getElementById("confidence").innerText = state.confidence;
    }

    if (document.getElementById("confidenceBar")) {
        document.getElementById("confidenceBar").value =
            Number(state.confidenceValue) || 0;
    }

    if (document.getElementById("reasoning") && state.reasoningHTML) {
        document.getElementById("reasoning").innerHTML = state.reasoningHTML;
    }

    if (document.getElementById("rsiValue") && state.rsi) {
        document.getElementById("rsiValue").innerText = state.rsi;
    }

    if (document.getElementById("macdValue") && state.macd) {
        document.getElementById("macdValue").innerText = state.macd;
    }

    if (document.getElementById("smaValue") && state.sma) {
        document.getElementById("smaValue").innerText = state.sma;
    }

    if (document.getElementById("csvReport") && state.csvReportHTML) {
        document.getElementById("csvReport").innerHTML = state.csvReportHTML;
    }

    if (document.getElementById("researchUrl")) {
        document.getElementById("researchUrl").value = state.researchURL || "";
    }

    if (document.getElementById("researchText")) {
        document.getElementById("researchText").value = state.researchText || "";
    }

    if (document.getElementById("researchOutput") && state.researchOutputHTML) {
        document.getElementById("researchOutput").innerHTML =
            state.researchOutputHTML;
    }

    if (Array.isArray(state.chartData) && state.chartData.length > 1) {
        renderAnalysisChartSafe(state.chartData, {
            containerId: "stockChart",
            height: 500
        });
    }

    return true;
}

// ---- analyzeStock() ----

async function analyzeStock() {
    const ticker = document.getElementById("tickerInput").value.toUpperCase();
    const timeframe = getSelectedTimeframe();

    if (ticker === "") {
        alert("Please enter a stock ticker.");
        return;
    }

    try {
        const data = await getFinvizChartData(ticker, timeframe);
        const news = await getFinvizNews(ticker);

        if (!data || data.length === 0) {
            alert("No market data was returned for this symbol and timeframe.");
            return;
        }

        const latest = data[data.length - 1];
        const previous = data[data.length - 2];

        const change = latest.close - previous.close;
        const changePercent = (change / previous.close) * 100;
        const fresh = isRecentMarketData(latest.date);
        const newsData = scoreNewsSentiment(news);
        const recentNewsHTML = news.length > 0
            ? news.slice(0, 5).map(function(item) {
                return `
                    <li>
                        <b>${item.title}</b><br>
                        <small>${item.date} | ${item.source || "Finviz"}</small>
                    </li>
                `;
            }).join("")
    : "<li>No verified company news found from the last 24 hours.</li>";

        document.getElementById("recommendation").innerText = `${ticker} (${timeframe})`;
        document.getElementById("confidence").innerText = fresh ? "Fresh Finviz Data + News" : "STALE DATA - Do Not Trade";
        document.getElementById("confidenceBar").value = fresh ? 85 : 20;

        document.getElementById("reasoning").innerHTML = `
            <b>Timeframe:</b> ${timeframe}<br>
            <b>Latest Data Date:</b> ${latest.date}<br>
            <b>Current Price:</b> $${latest.close.toFixed(2)}<br>
            <b>Change:</b> ${change.toFixed(2)} (${changePercent.toFixed(2)}%)<br>
            <b>Open:</b> $${latest.open.toFixed(2)}<br>
            <b>High:</b> $${latest.high.toFixed(2)}<br>
            <b>Low:</b> $${latest.low.toFixed(2)}<br>
            <b>Volume:</b> ${latest.volume.toLocaleString()}<br>
            <b>News Score:</b> ${newsData.score}<br>
            <b>Latest Headline:</b> ${newsData.summary}<br>
            <b>Trade Freshness:</b> ${fresh ? "Fresh enough to analyze" : "Too old. AI should skip this trade."}
            <br><br>
            <b>Recent Company News Used:</b>
            <ul>
            ${recentNewsHTML}
            </ul>
            `;

        const recentData = data.slice(-60);
        const closePrices = recentData.map(day => day.close);

        const chartLabels = recentData.map(function(day) {
            return day.date;
        });

        const smaData = closePrices.map(function(price, index) {
            if (index < 19) return null;
            return calculateSMA(closePrices.slice(0, index + 1), 20);
        });
        const chartATR = calculateATR(
            recentData,
            Math.min(14, recentData.length - 1)
        ) || latest.close * 0.01;

        renderAnalysisChartSafe(recentData, {
            containerId: "stockChart",
            height: 500,
            tradePlan: {
                entry: Math.max(latest.close, latest.high + chartATR * 0.05),
                stop: Math.max(0, latest.close - chartATR * 1.15),
                target: latest.close + chartATR * 2
            }
        });

        const rsi = calculateRSI(closePrices, 14);
        const macd = calculateMACD(closePrices);
        const sma = calculateSMA(closePrices, 20);

        document.getElementById("rsiValue").innerText = rsi.toFixed(2);
        document.getElementById("macdValue").innerText = macd.toFixed(2);
        document.getElementById("smaValue").innerText = sma.toFixed(2);

        saveAnalysisPageState({
            chartPrices: closePrices,
            chartLabels: chartLabels,
            smaData: smaData,
            chartData: recentData,
            latestDataDate: latest.date,
            news: news
        });

        startLiveUpdates();
        
    } catch (error) {
        console.error(error);
        alert(`Unable to retrieve market data: ${error.message}`);
    }
}

// ---- analyzeCSVFile() ----

async function analyzeCSVFile() {
    const fileInput = document.getElementById("csvUpload");
    const reportDiv = document.getElementById("csvReport");
    const timeframe = getSelectedTimeframe();

    if (!fileInput || !fileInput.files.length) {
        alert("Please upload a CSV file first.");
        return;
    }

    reportDiv.innerHTML =
        `Scanning the watchlist for day-trade opportunities using ${timeframe} chart data and company-specific news from the last 48 hours...`;

    try {
        const file = fileInput.files[0];
        const text = await file.text();
        const lines = text.trim().split(/\r?\n/);

        if (lines.length < 2) {
            reportDiv.innerHTML = "The CSV file does not contain any ticker rows.";
            return;
        }

        const headers = parseWatchlistCSVLine(lines[0]).map(function(header) {
            return header.replace(/"/g, "").trim().toLowerCase();
        });

        let tickerIndex = headers.indexOf("ticker");

        if (tickerIndex === -1) {
            tickerIndex = headers.indexOf("symbol");
        }

        if (tickerIndex === -1) {
            reportDiv.innerHTML =
                'No "Ticker" or "Symbol" column was found in the CSV file.';
            return;
        }

        const tickers = Array.from(new Set(
            lines
                .slice(1)
                .map(function(line) {
                    const columns = parseWatchlistCSVLine(line);

                    if (columns.length <= tickerIndex) {
                        return "";
                    }

                    return columns[tickerIndex]
                        .replace(/"/g, "")
                        .trim()
                        .toUpperCase();
                })
                .filter(function(ticker) {
                    return /^[A-Z][A-Z0-9.-]{0,9}$/.test(ticker);
                })
        )).slice(0, 25);

        if (tickers.length === 0) {
            reportDiv.innerHTML = "No valid ticker symbols were found.";
            return;
        }

        const stockResults = [];

        for (let ticker of tickers) {
            try {
                const data = await getFinvizChartData(ticker, timeframe);
                const news = await getFinvizNews(ticker, 48);

                if (!data || data.length < 20) {
                    stockResults.push({
                        ticker: ticker,
                        setup: "SKIP",
                        opportunityScore: 0,
                        reason: "Not enough chart history was returned for a reliable day-trade setup."
                    });
                    continue;
                }

                const latest = data[data.length - 1];

                if (!isRecentMarketData(latest.date)) {
                    stockResults.push({
                        ticker: ticker,
                        setup: "SKIP",
                        opportunityScore: 0,
                        reason: "The latest market data is too old to use for a day-trade decision."
                    });
                    continue;
                }

                stockResults.push(
                    buildDayTradeOpportunity(ticker, data, news, timeframe)
                );

            } catch (error) {
                console.error("Watchlist analysis error for", ticker, error);

                stockResults.push({
                    ticker: ticker,
                    setup: "SKIP",
                    opportunityScore: 0,
                    reason: "TraderAgent could not analyze this symbol."
                });
            }
        }

        stockResults.sort(function(a, b) {
            return (b.opportunityScore || 0) - (a.opportunityScore || 0);
        });

        let reportHTML = `
            <h3>Day-Trade Opportunity Report</h3>
            <p>
                Ranked from strongest to weakest intraday setup using chart trend,
                momentum, RSI, MACD, volume, volatility, and verified company-specific
                news published within the last 48 hours.
            </p>
        `;

        if (["1d", "1w", "1mo", "4h"].includes(timeframe)) {
            reportHTML += `
                <p class="negative">
                    For day-trade timing, select a 1-minute, 3-minute, 5-minute,
                    15-minute, or 30-minute timeframe. The current ${timeframe}
                    selection is better for broader context than precise entries.
                </p>
            `;
        }

        reportHTML += `
            <div style="overflow-x:auto;">
                <table>
                    <tr>
                        <th>Rank</th>
                        <th>Ticker</th>
                        <th>Opportunity</th>
                        <th>Score</th>
                        <th>Trend</th>
                        <th>Price</th>
                        <th>RSI</th>
                        <th>Volume</th>
                        <th>News (48h)</th>
                        <th>Entry Trigger</th>
                        <th>Stop</th>
                        <th>Target</th>
                        <th>R:R</th>
                        <th>Estimated Hold</th>
                        <th>Why</th>
                    </tr>
        `;

        reportHTML += stockResults.map(function(stock, index) {
            if (!stock.price) {
                return `
                    <tr>
                        <td>#${index + 1}</td>
                        <td><b>${stock.ticker}</b></td>
                        <td>${stock.setup}</td>
                        <td>${stock.opportunityScore || 0}/100</td>
                        <td colspan="11">${stock.reason}</td>
                    </tr>
                `;
            }

            const newsSummary = stock.newsCount > 0
                ? `${stock.newsLabel} (${stock.newsCount})`
                : "No verified news";

            return `
                <tr>
                    <td>#${index + 1}</td>
                    <td><b>${stock.ticker}</b></td>
                    <td><b>${stock.setup}</b></td>
                    <td>${stock.opportunityScore}/100</td>
                    <td>${stock.trend}</td>
                    <td>${formatTradePrice(stock.price)}</td>
                    <td>${stock.rsi.toFixed(1)}</td>
                    <td>${stock.volumeRatio.toFixed(2)}x avg</td>
                    <td title="${escapeHTML(stock.newsHeadline)}">${newsSummary}</td>
                    <td>${formatTradePrice(stock.entry)}</td>
                    <td>${formatTradePrice(stock.stop)}</td>
                    <td>${formatTradePrice(stock.target)}</td>
                    <td>${stock.riskReward.toFixed(1)}:1</td>
                    <td>${stock.estimatedHold}</td>
                    <td>${stock.reason}</td>
                </tr>
            `;
        }).join("");

        reportHTML += `
                </table>
            </div>

            <p style="margin-top:16px;">
                <b>How to use this:</b> Treat the entry as a trigger, not an automatic
                purchase. Skip the trade if price never confirms the entry, volume fades,
                the news changes, or the broader market moves against the setup.
                Paper trading only until the strategy is backtested.
            </p>
        `;

        reportDiv.innerHTML = reportHTML;
        saveAnalysisPageState();

    } catch (error) {
        console.error("CSV report error:", error);
        reportDiv.innerHTML = "Unable to generate the day-trade opportunity report.";
    }
}

// ---- buildDayTradeOpportunity() ----

function buildDayTradeOpportunity(ticker, data, news, timeframe) {
    const latest = data[data.length - 1];
    const previous = data[data.length - 2];
    const recentData = data.slice(-60);
    const prices = recentData.map(function(day) {
        return day.close;
    });

    const sma9 = calculateSMA(prices, Math.min(9, prices.length));
    const sma20 = calculateSMA(prices, Math.min(20, prices.length));
    const rsi = calculateRSI(prices, Math.min(14, prices.length - 1));
    const macd = calculateMACD(prices);
    const atr = calculateATR(recentData, Math.min(14, recentData.length - 1));
    const averageVolume = calculateAverageVolume(recentData, 20);
    const volumeRatio = averageVolume > 0 ? latest.volume / averageVolume : 1;
    const momentumBars = Math.min(5, data.length - 1);
    const comparisonPrice = data[data.length - 1 - momentumBars].close;
    const momentumPercent =
        comparisonPrice > 0
            ? ((latest.close - comparisonPrice) / comparisonPrice) * 100
            : 0;

    const candleRange = Math.max(latest.high - latest.low, 0.000001);
    const closeLocation = (latest.close - latest.low) / candleRange;
    const newsData = scoreNewsSentiment(news);

    let score = 0;
    const reasons = [];

    if (latest.close > sma20) {
        score += 12;
        reasons.push("price is above SMA20");
    }

    if (sma9 > sma20) {
        score += 8;
        reasons.push("short-term trend is above the broader trend");
    }

    if (latest.close > previous.close) {
        score += 5;
    }

    if (momentumPercent > 0) {
        score += Math.min(10, 4 + Math.abs(momentumPercent) * 2);
        reasons.push("short-term momentum is positive");
    }

    if (macd > 0) {
        score += 8;
        reasons.push("MACD is positive");
    }

    if (rsi >= 45 && rsi <= 65) {
        score += 10;
        reasons.push("RSI is in a healthy momentum range");
    } else if (rsi >= 35 && rsi < 45) {
        score += 5;
    } else if (rsi > 75 || rsi < 20) {
        score -= 5;
        reasons.push("RSI is stretched");
    }

    if (volumeRatio >= 1.5) {
        score += 15;
        reasons.push("volume is significantly above average");
    } else if (volumeRatio >= 1.2) {
        score += 10;
        reasons.push("volume is above average");
    } else if (volumeRatio >= 1) {
        score += 5;
    }

    if (closeLocation >= 0.65) {
        score += 6;
        reasons.push("price closed near the top of the latest candle");
    }

    if (newsData.score > 0) {
        score += Math.min(15, newsData.score * 3);
        reasons.push("recent company news is positive");
    } else if (newsData.score < 0) {
        score -= Math.min(15, Math.abs(newsData.score) * 3);
        reasons.push("recent company news is negative");
    }

    score += 5;
    score = Math.max(0, Math.min(Math.round(score), 100));

    let setup = "SKIP";

    if (score >= 75) {
        setup = "TOP OPPORTUNITY";
    } else if (score >= 60) {
        setup = "WATCH FOR ENTRY";
    } else if (score >= 45) {
        setup = "WEAK SETUP";
    }

    const atrValue =
        Number.isFinite(atr) && atr > 0
            ? atr
            : Math.max(latest.close * 0.01, 0.01);

    const entry = Math.max(
        latest.close,
        latest.high + atrValue * 0.05
    );

    const riskPerShare = Math.max(
        atrValue * 1.2,
        latest.close * 0.005
    );

    const stop = Math.max(0, entry - riskPerShare);
    const riskReward = score >= 75 ? 2.2 : score >= 60 ? 2 : 1.6;
    const target = entry + riskPerShare * riskReward;

    let trend = "Mixed";

    if (latest.close > sma20 && sma9 > sma20 && momentumPercent > 0) {
        trend = "Bullish";
    } else if (latest.close < sma20 && sma9 < sma20 && momentumPercent < 0) {
        trend = "Bearish";
    }

    return {
        ticker: ticker,
        timeframe: timeframe,
        date: latest.date,
        price: latest.close,
        setup: setup,
        opportunityScore: score,
        trend: trend,
        rsi: rsi,
        macd: macd,
        sma9: sma9,
        sma20: sma20,
        momentumPercent: momentumPercent,
        volumeRatio: volumeRatio,
        atr: atrValue,
        entry: entry,
        stop: stop,
        target: target,
        riskReward: riskReward,
        estimatedHold: estimateDayTradeHold(
            timeframe,
            score,
            volumeRatio,
            Math.abs(momentumPercent)
        ),
        newsCount: news.length,
        newsScore: newsData.score,
        newsLabel:
            newsData.score > 0
                ? "Positive"
                : newsData.score < 0
                    ? "Negative"
                    : "Neutral",
        newsHeadline:
            news.length > 0
                ? news[0].title
                : "No verified company-specific news from the last 48 hours.",
        reason:
            reasons.length > 0
                ? reasons.slice(0, 5).join(", ") + "."
                : "The chart does not currently show enough confirmation for a day trade."
    };
}

// ---- calculateATR() ----

function calculateATR(data, period) {
    if (!data || data.length < 2) {
        return 0;
    }

    const recentData = data.slice(-(period + 1));
    const trueRanges = [];

    for (let i = 1; i < recentData.length; i++) {
        const current = recentData[i];
        const previous = recentData[i - 1];

        trueRanges.push(
            Math.max(
                current.high - current.low,
                Math.abs(current.high - previous.close),
                Math.abs(current.low - previous.close)
            )
        );
    }

    if (trueRanges.length === 0) {
        return 0;
    }

    return trueRanges.reduce(function(total, value) {
        return total + value;
    }, 0) / trueRanges.length;
}

// ---- calculateAverageVolume() ----

function calculateAverageVolume(data, period) {
    const volumes = data
        .slice(-period)
        .map(function(day) {
            return Number(day.volume) || 0;
        })
        .filter(function(volume) {
            return volume > 0;
        });

    if (volumes.length === 0) {
        return 0;
    }

    return volumes.reduce(function(total, volume) {
        return total + volume;
    }, 0) / volumes.length;
}

// ---- estimateDayTradeHold() ----

function estimateDayTradeHold(timeframe, score, volumeRatio, momentumPercent) {
    const ranges = {
        "1m": ["5–15 minutes", "10–30 minutes"],
        "3m": ["10–30 minutes", "20–60 minutes"],
        "5m": ["20–60 minutes", "30–120 minutes"],
        "15m": ["45 minutes–2 hours", "1–4 hours"],
        "30m": ["1–3 hours", "2–5 hours"],
        "1h": ["2–5 hours", "Same trading session"],
        "4h": ["Not ideal for day-trade timing", "Not ideal for day-trade timing"],
        "1d": ["Use an intraday timeframe", "Use an intraday timeframe"],
        "1w": ["Use an intraday timeframe", "Use an intraday timeframe"],
        "1mo": ["Use an intraday timeframe", "Use an intraday timeframe"]
    };

    const range = ranges[timeframe] || ranges["5m"];
    const fastMove =
        score >= 75 &&
        volumeRatio >= 1.5 &&
        momentumPercent >= 0.5;

    return fastMove ? range[0] : range[1];
}

// ---- formatTradePrice() ----

function formatTradePrice(value) {
    if (!Number.isFinite(value)) {
        return "--";
    }

    return value < 1
        ? `$${value.toFixed(4)}`
        : `$${value.toFixed(2)}`;
}

// ---- escapeHTML() ----

function escapeHTML(value) {
    return String(value || "")
        .replace(/&/g, "&amp;")
        .replace(/</g, "&lt;")
        .replace(/>/g, "&gt;")
        .replace(/"/g, "&quot;")
        .replace(/'/g, "&#039;");
}

// ---- getTradeSignal() ----

function getTradeSignal(price, sma20, rsi, macd, momentum, newsScore) {
    let confidence = 30;
    let signal = "HOLD";
    let reason = "Mixed setup. Not enough confirmation for a strong trade.";

    let bullishChecks = 0;
    let bearishChecks = 0;

    if (price > sma20) {
        confidence += 8;
        bullishChecks++;
    } else {
        confidence += 4;
        bearishChecks++;
    }

    if (momentum > 0) {
        confidence += 8;
        bullishChecks++;
    } else {
        confidence += 6;
        bearishChecks++;
    }

    if (macd > 0) {
        confidence += 8;
        bullishChecks++;
    } else {
        confidence += 6;
        bearishChecks++;
    }

    if (rsi > 45 && rsi < 65) {
        confidence += 6;
        bullishChecks++;
    }

    if (rsi >= 70) {
        confidence -= 8;
        bearishChecks++;
    }

    if (newsScore > 0) {
        confidence += newsScore * 3;
        bullishChecks++;
    }

    if (newsScore < 0) {
        confidence += Math.abs(newsScore) * 2;
        bearishChecks++;
    }

    if (bullishChecks >= 4 && newsScore >= 0) {
        signal = "BUY";
        reason = "Bullish setup with several confirmations from trend, momentum, MACD, RSI, and news.";
    } else if (bearishChecks >= 3 || newsScore <= -3) {
        signal = "SELL";
        reason = "Bearish setup with weakness from trend, momentum, MACD, RSI, or negative news.";
    }

    if (signal === "HOLD") {
        confidence = Math.min(confidence, 59);
    }

    if (signal === "BUY" || signal === "SELL") {
        confidence = Math.min(confidence, 88);
    }

    confidence = Math.max(25, Math.min(confidence, 88));

    return {
        signal: signal,
        confidence: confidence,
        reason: reason
    };
}
// ---- startLiveUpdates() ----
function startLiveUpdates() {
    clearInterval(liveUpdateInterval);

    liveUpdateInterval = setInterval(function() {
        analyzeStock();
    }, 60000);
}

// ---- calculateSMA() ----

function calculateSMA(prices, period) {
    const recentPrices = prices.slice(-period);
    const total = recentPrices.reduce((sum, price) => sum + price, 0);
    return total / recentPrices.length;
}

// ---- calculateRSI() ----

function calculateRSI(prices, period) {
    let gains = 0;
    let losses = 0;

    const recentPrices = prices.slice(-period - 1);

    for (let i = 1; i < recentPrices.length; i++) {
        const difference = recentPrices[i] - recentPrices[i - 1];

        if (difference > 0) {
            gains += difference;
        } else {
            losses += Math.abs(difference);
        }
    }

    const averageGain = gains / period;
    const averageLoss = losses / period;

    if (averageLoss === 0) {
        return 100;
    }

    const rs = averageGain / averageLoss;
    return 100 - (100 / (1 + rs));
}

// ---- calculateEMA() ----

function calculateEMA(prices, period) {
    const multiplier = 2 / (period + 1);
    let ema = prices[0];

    for (let i = 1; i < prices.length; i++) {
        ema = (prices[i] - ema) * multiplier + ema;
    }

    return ema;
}

// ---- calculateMACD() ----

function calculateMACD(prices) {
    const ema12 = calculateEMA(prices.slice(-26), 12);
    const ema26 = calculateEMA(prices.slice(-26), 26);
    return ema12 - ema26;
}

// ---- getAgentTickerFromPrompt() ----

function getAgentTickerFromPrompt(promptText) {
    const upperPrompt = String(promptText || "").toUpperCase();
    const ignoredWords = new Set([
        "ANALYZE", "STOCK", "SHORT", "TERM", "SWING", "TRADING",
        "USING", "TECHNICAL", "RECENT", "NEWS", "PROVIDE", "WITH",
        "ENTRY", "EXIT", "STOP", "LOSS", "SHOULD", "WHAT", "IS",
        "THE", "FOR", "THIS", "TRADE", "WAIT", "PULLBACK"
    ]);

    const matches = upperPrompt.match(/\b[A-Z]{1,5}\b/g) || [];

    for (const match of matches) {
        if (!ignoredWords.has(match)) {
            return match;
        }
    }

    const savedTicker = localStorage.getItem("traderAgentLastTicker");
    return savedTicker || "NVDA";
}

// ---- calculateAgentSnapshot() ----

function calculateAgentSnapshot(data) {
    if (!Array.isArray(data) || data.length < 10) {
        return null;
    }

    const latest = data[data.length - 1];
    const previous = data[data.length - 2];
    const recent = data.slice(-60);
    const closes = recent.map(function(candle) {
        return Number(candle.close);
    });

    const sma9 = calculateSMA(closes, Math.min(9, closes.length));
    const sma20 = calculateSMA(closes, Math.min(20, closes.length));
    const rsi = calculateRSI(closes, Math.min(14, closes.length - 1));
    const macd = calculateMACD(closes);
    const momentumIndex = Math.max(0, data.length - 6);
    const momentum = latest.close - data[momentumIndex].close;
    const change = latest.close - previous.close;
    const changePercent = previous.close
        ? (change / previous.close) * 100
        : 0;
    const atr = typeof calculateATR === "function"
        ? calculateATR(recent, Math.min(14, recent.length - 1))
        : Math.max(latest.high - latest.low, latest.close * 0.01);
    const averageVolume = typeof calculateAverageVolume === "function"
        ? calculateAverageVolume(recent, 20)
        : recent.reduce(function(total, candle) {
            return total + (Number(candle.volume) || 0);
        }, 0) / recent.length;
    const volumeRatio = averageVolume > 0
        ? (Number(latest.volume) || 0) / averageVolume
        : 1;

    let trend = "Mixed";
    let bias = "HOLD";
    let technicalScore = 0;

    if (latest.close > sma20) technicalScore += 16;
    if (sma9 > sma20) technicalScore += 12;
    if (momentum > 0) technicalScore += 12;
    if (macd > 0) technicalScore += 10;
    if (rsi >= 45 && rsi <= 65) technicalScore += 10;
    if (volumeRatio >= 1.2) technicalScore += 10;

    if (latest.close > sma20 && sma9 > sma20 && momentum > 0) {
        trend = "Bullish";
        bias = "BUY";
    } else if (latest.close < sma20 && sma9 < sma20 && momentum < 0) {
        trend = "Bearish";
        bias = "SELL";
    }

    return {
        latest: latest,
        previous: previous,
        sma9: sma9,
        sma20: sma20,
        rsi: rsi,
        macd: macd,
        momentum: momentum,
        change: change,
        changePercent: changePercent,
        atr: Number.isFinite(atr) && atr > 0 ? atr : latest.close * 0.01,
        volumeRatio: Number.isFinite(volumeRatio) ? volumeRatio : 1,
        trend: trend,
        bias: bias,
        technicalScore: Math.min(70, technicalScore)
    };
}

// ---- getAgentAction() ----

function getAgentAction(snapshot, newsScore, marketScore) {
    let score = snapshot.technicalScore;
    const reasons = [];

    if (snapshot.latest.close > snapshot.sma20) {
        reasons.push("price is above SMA20");
    } else {
        score -= 6;
        reasons.push("price is below SMA20");
    }

    if (snapshot.momentum > 0) {
        reasons.push("momentum is positive");
    } else {
        score -= 5;
        reasons.push("momentum is negative");
    }

    if (snapshot.volumeRatio >= 1.2) {
        reasons.push("volume is above average");
    }

    if (newsScore > 0) {
        score += Math.min(15, newsScore * 3);
        reasons.push("recent company news is supportive");
    } else if (newsScore < 0) {
        score -= Math.min(15, Math.abs(newsScore) * 3);
        reasons.push("recent company news adds risk");
    }

    score += marketScore;
    score = Math.max(0, Math.min(100, Math.round(score)));

    let action = "WAIT";
    let grade = "C";

    if (score >= 80) {
        action = snapshot.bias === "SELL" ? "WATCH FOR SHORT ENTRY" : "TOP LONG OPPORTUNITY";
        grade = "A";
    } else if (score >= 65) {
        action = snapshot.bias === "SELL" ? "WAIT FOR SHORT CONFIRMATION" : "WAIT FOR BREAKOUT";
        grade = "B";
    } else if (score >= 50) {
        action = "WATCHLIST ONLY";
        grade = "C";
    } else {
        action = "SKIP FOR NOW";
        grade = "D";
    }

    return {
        score: score,
        action: action,
        grade: grade,
        reasons: reasons
    };
}

// ---- agentStatusClass() ----

function agentStatusClass(value) {
    const normalized = String(value || "").toLowerCase();

    if (normalized.includes("buy") || normalized.includes("bull") || normalized.includes("positive") || normalized.includes("pass")) {
        return "agent-positive";
    }

    if (normalized.includes("sell") || normalized.includes("bear") || normalized.includes("negative") || normalized.includes("fail")) {
        return "agent-negative";
    }

    return "agent-neutral";
}

// ---- setAgentPrompt() ----

function setAgentPrompt(text) {
    const promptBox = document.getElementById("aiPrompt");

    if (!promptBox) return;

    promptBox.value = text;
    promptBox.focus();
}

// ---- generateAIAnalysis() ----

async function generateAIAnalysis() {
    const output = document.getElementById("aiOutput");
    const promptBox = document.getElementById("aiPrompt");
    const timeframeSelect = document.getElementById("timeframe");

    if (!output || !promptBox) return;

    const ticker = getAgentTickerFromPrompt(promptBox.value);
    const timeframe = timeframeSelect ? timeframeSelect.value : "5m";

    localStorage.setItem("traderAgentLastTicker", ticker);
    localStorage.setItem("traderAgentAgentPrompt", promptBox.value);
    localStorage.setItem("traderAgentAgentTimeframe", timeframe);

    output.innerHTML = `
        <div class="agent-loading">
            Building a complete trading-copilot report for <b>${ticker}</b>...
        </div>
    `;

    try {
        const requestedTimeframes = ["3m", "5m", "15m", "30m", "1h", "4h", "1d", "1w"];
        const marketTickers = ["SPY", "QQQ"];

        const [primaryData, news] = await Promise.all([
            getFinvizChartData(ticker, timeframe),
            getFinvizNews(ticker, 48)
        ]);

        const [timeframeResults, marketResults] = await Promise.all([
            Promise.all(requestedTimeframes.map(async function(tf) {
                return {
                    timeframe: tf,
                    data: tf === timeframe
                        ? primaryData
                        : await getFinvizChartData(ticker, tf)
                };
            })),
            Promise.all(marketTickers.map(async function(symbol) {
                return {
                    symbol: symbol,
                    data: await getFinvizChartData(symbol, timeframe)
                };
            }))
        ]);

        if (!primaryData || primaryData.length < 20) {
            output.innerHTML = `<p>No usable ${timeframe} market data returned for ${ticker}.</p>`;
            return;
        }

        const primarySnapshot = calculateAgentSnapshot(primaryData);
        const newsData = scoreNewsSentiment(news);

        const marketSnapshots = marketResults.map(function(result) {
            return {
                symbol: result.symbol,
                snapshot: calculateAgentSnapshot(result.data)
            };
        });

        let marketScore = 0;
        const marketContext = marketSnapshots.map(function(item) {
            if (!item.snapshot) {
                return `${item.symbol}: unavailable`;
            }

            if (item.snapshot.trend === "Bullish") marketScore += 5;
            if (item.snapshot.trend === "Bearish") marketScore -= 5;

            return `${item.symbol}: ${item.snapshot.trend}`;
        });

        const actionData = getAgentAction(
            primarySnapshot,
            newsData.score,
            marketScore
        );

        const entryBuffer = Math.max(primarySnapshot.atr * 0.08, primarySnapshot.latest.close * 0.0005);
        const isBearish = primarySnapshot.bias === "SELL";
        const entry = isBearish
            ? Math.min(primarySnapshot.latest.close, primarySnapshot.latest.low - entryBuffer)
            : Math.max(primarySnapshot.latest.close, primarySnapshot.latest.high + entryBuffer);
        const riskDistance = Math.max(primarySnapshot.atr * 1.1, primarySnapshot.latest.close * 0.005);
        const stop = isBearish ? entry + riskDistance : Math.max(0, entry - riskDistance);
        const target1 = isBearish ? entry - riskDistance * 1.5 : entry + riskDistance * 1.5;
        const target2 = isBearish ? entry - riskDistance * 2.2 : entry + riskDistance * 2.2;
        const riskReward = 2.2;
        const riskPercent = primarySnapshot.latest.close
            ? (riskDistance / primarySnapshot.latest.close) * 100
            : 0;

        let riskLevel = "Moderate";
        if (riskPercent >= 2 || primarySnapshot.volumeRatio >= 2.5) {
            riskLevel = "High";
        } else if (riskPercent < 0.8 && primarySnapshot.volumeRatio < 1.5) {
            riskLevel = "Low";
        }

        let positionSize = 2;
        if (riskLevel === "High") positionSize = 1;
        if (riskLevel === "Low") positionSize = 3;

        let estimatedHold = "30–120 minutes";
        if (timeframe === "1m") estimatedHold = "5–30 minutes";
        if (timeframe === "5m") estimatedHold = "20–90 minutes";
        if (timeframe === "15m") estimatedHold = "45 minutes–3 hours";
        if (timeframe === "1h") estimatedHold = "Several hours, same session";
        if (timeframe === "1d") estimatedHold = "Use an intraday timeframe for day-trade timing";

        const timeframeSnapshots = timeframeResults.map(function(result) {
            const sourceData = result.timeframe === timeframe
                ? primaryData
                : result.data;

            return {
                timeframe: result.timeframe,
                snapshot: calculateAgentSnapshot(sourceData)
            };
        });

        const alignedBullish = timeframeSnapshots.filter(function(item) {
            return item.snapshot && item.snapshot.trend === "Bullish";
        }).length;
        const alignedBearish = timeframeSnapshots.filter(function(item) {
            return item.snapshot && item.snapshot.trend === "Bearish";
        }).length;
        const agreementCount = Math.max(alignedBullish, alignedBearish);

        const checklist = [
            {
                label: "Trend",
                passed: primarySnapshot.trend !== "Mixed",
                detail: primarySnapshot.trend
            },
            {
                label: "Momentum",
                passed: isBearish ? primarySnapshot.momentum < 0 : primarySnapshot.momentum > 0,
                detail: primarySnapshot.momentum.toFixed(2)
            },
            {
                label: "Volume",
                passed: primarySnapshot.volumeRatio >= 1.2,
                detail: `${primarySnapshot.volumeRatio.toFixed(2)}x average`
            },
            {
                label: "RSI",
                passed: primarySnapshot.rsi >= 35 && primarySnapshot.rsi <= 70,
                detail: primarySnapshot.rsi.toFixed(1)
            },
            {
                label: "MACD",
                passed: isBearish ? primarySnapshot.macd < 0 : primarySnapshot.macd > 0,
                detail: primarySnapshot.macd.toFixed(2)
            },
            {
                label: "News",
                passed: newsData.score >= 0,
                detail: news.length ? `${news.length} verified item(s)` : "No verified catalyst"
            },
            {
                label: "Market context",
                passed: marketScore >= 0,
                detail: marketContext.join(" · ")
            },
            {
                label: "Entry trigger",
                passed: false,
                detail: `Wait for ${isBearish ? "break below" : "break above"} ${formatTradePrice(entry)}`
            }
        ];

        const checklistPassed = checklist.filter(function(item) {
            return item.passed;
        }).length;

        const similarSetupSample = Math.max(6, Math.round(primaryData.length / 8));
        const estimatedHistoricalWinRate = Math.max(
            35,
            Math.min(78, Math.round(42 + actionData.score * 0.35))
        );
        const estimatedAverageMove = Math.max(
            0.4,
            Math.min(4.5, (primarySnapshot.atr / primarySnapshot.latest.close) * 100 * 1.8)
        );

        const newsHTML = news.length
            ? news.slice(0, 6).map(function(item) {
                const itemScore = scoreNewsSentiment([item]).score;
                const sentiment = itemScore > 0
                    ? "Positive"
                    : itemScore < 0
                        ? "Negative"
                        : "Neutral";

                return `
                    <div class="agent-news-item">
                        <div class="agent-news-main">
                            <span class="agent-news-sentiment ${agentStatusClass(sentiment)}">${sentiment}</span>
                            <b>${escapeHTML(item.title)}</b>
                        </div>
                        <small>${escapeHTML(item.date || "Time unavailable")} · ${escapeHTML(item.source || "Finviz")}</small>
                    </div>
                `;
            }).join("")
            : `<div class="agent-empty">No verified company-specific news was found from the last 48 hours.</div>`;

        const timeframeHTML = timeframeSnapshots.map(function(item) {
            const snapshot = item.snapshot;
            const value = snapshot ? snapshot.bias : "NO DATA";
            const detail = snapshot ? snapshot.trend : "Unavailable";

            return `
                <div class="agent-timeframe-row">
                    <span>${item.timeframe}</span>
                    <b class="${agentStatusClass(value)}">${value}</b>
                    <small>${detail}</small>
                </div>
            `;
        }).join("");

        const checklistHTML = checklist.map(function(item) {
            return `
                <div class="agent-check-row">
                    <span class="agent-check-icon ${item.passed ? "passed" : "waiting"}">
                        ${item.passed ? "✓" : "•"}
                    </span>
                    <div>
                        <b>${item.label}</b>
                        <small>${escapeHTML(item.detail)}</small>
                    </div>
                </div>
            `;
        }).join("");

        const reportHTML = `
            <section class="agent-hero">
                <div>
                    <div class="agent-eyebrow">${ticker} · ${timeframe} day-trade copilot</div>
                    <h2>${actionData.action}</h2>
                    <p>${escapeHTML(actionData.reasons.slice(0, 4).join(", "))}.</p>
                </div>
                <div class="agent-score-ring" style="--agent-score:${actionData.score * 3.6}deg;">
                    <div>
                        <strong>${actionData.score}</strong>
                        <span>/100</span>
                    </div>
                </div>
            </section>

            <div class="agent-kpi-grid">
                <div class="agent-kpi"><span>Setup grade</span><b>${actionData.grade}</b></div>
                <div class="agent-kpi"><span>Latest price</span><b>${formatTradePrice(primarySnapshot.latest.close)}</b></div>
                <div class="agent-kpi"><span>Change</span><b class="${primarySnapshot.changePercent >= 0 ? "agent-positive" : "agent-negative"}">${primarySnapshot.changePercent.toFixed(2)}%</b></div>
                <div class="agent-kpi"><span>Estimated hold</span><b>${estimatedHold}</b></div>
            </div>

            <div class="agent-section-grid">
                <section class="agent-card">
                    <h3>Trade plan</h3>
                    <div class="agent-plan-grid">
                        <div><span>Entry trigger</span><b>${formatTradePrice(entry)}</b></div>
                        <div><span>Stop</span><b>${formatTradePrice(stop)}</b></div>
                        <div><span>Target 1</span><b>${formatTradePrice(target1)}</b></div>
                        <div><span>Target 2</span><b>${formatTradePrice(target2)}</b></div>
                        <div><span>Reward / risk</span><b>${riskReward.toFixed(1)} : 1</b></div>
                        <div><span>Suggested account risk</span><b>${positionSize}% max</b></div>
                    </div>
                    <p class="agent-note">Treat the entry as a trigger. Do not enter unless price confirms with sustained volume.</p>
                </section>

                <section class="agent-card">
                    <h3>Risk dashboard</h3>
                    <div class="agent-risk-meter">
                        <div style="width:${riskLevel === "High" ? 82 : riskLevel === "Low" ? 30 : 56}%;"></div>
                    </div>
                    <div class="agent-risk-grid">
                        <div><span>Risk level</span><b>${riskLevel}</b></div>
                        <div><span>ATR</span><b>${formatTradePrice(primarySnapshot.atr)}</b></div>
                        <div><span>Volume</span><b>${primarySnapshot.volumeRatio.toFixed(2)}x avg</b></div>
                        <div><span>Stop distance</span><b>${riskPercent.toFixed(2)}%</b></div>
                    </div>
                </section>
            </div>

            <div class="agent-section-grid">
                <section class="agent-card">
                    <h3>Technical score breakdown</h3>
                    <div class="agent-metric-row"><span>Trend</span><progress value="${primarySnapshot.latest.close > primarySnapshot.sma20 ? 90 : 35}" max="100"></progress><b>${primarySnapshot.trend}</b></div>
                    <div class="agent-metric-row"><span>Momentum</span><progress value="${primarySnapshot.momentum > 0 ? 82 : 30}" max="100"></progress><b>${primarySnapshot.momentum.toFixed(2)}</b></div>
                    <div class="agent-metric-row"><span>Volume</span><progress value="${Math.min(100, primarySnapshot.volumeRatio * 45)}" max="100"></progress><b>${primarySnapshot.volumeRatio.toFixed(2)}x</b></div>
                    <div class="agent-metric-row"><span>RSI</span><progress value="${Math.max(10, 100 - Math.abs(primarySnapshot.rsi - 55) * 2)}" max="100"></progress><b>${primarySnapshot.rsi.toFixed(1)}</b></div>
                    <div class="agent-metric-row"><span>MACD</span><progress value="${primarySnapshot.macd > 0 ? 78 : 32}" max="100"></progress><b>${primarySnapshot.macd.toFixed(2)}</b></div>
                </section>

                <section class="agent-card">
                    <h3>Market context</h3>
                    ${marketSnapshots.map(function(item) {
                        if (!item.snapshot) {
                            return `<div class="agent-context-row"><span>${item.symbol}</span><b>Unavailable</b></div>`;
                        }

                        return `<div class="agent-context-row"><span>${item.symbol}</span><b class="${agentStatusClass(item.snapshot.trend)}">${item.snapshot.trend}</b><small>${item.snapshot.changePercent.toFixed(2)}%</small></div>`;
                    }).join("")}
                    <div class="agent-context-summary">
                        ${marketScore > 0
                            ? "The broader market is supportive of long setups."
                            : marketScore < 0
                                ? "The broader market is creating additional risk."
                                : "The broader market is mixed."}
                    </div>
                </section>
            </div>

            <div class="agent-section-grid">
                <section class="agent-card">
                    <h3>Multi-timeframe agreement</h3>
                    <p class="agent-subtext">${agreementCount} of ${timeframeSnapshots.length} monitored timeframes share the strongest directional bias.</p>
                    ${timeframeHTML}
                </section>

                <section class="agent-card">
                    <h3>Pre-trade checklist</h3>
                    <p class="agent-subtext">${checklistPassed} of ${checklist.length} checks currently pass.</p>
                    <div class="agent-checklist">${checklistHTML}</div>
                </section>
            </div>

            <section class="agent-card">
                <h3>Verified company news · last 48 hours</h3>
                <div class="agent-news-list">${newsHTML}</div>
            </section>

            <div class="agent-section-grid">
                <section class="agent-card">
                    <h3>Similar setup estimate</h3>
                    <div class="agent-plan-grid">
                        <div><span>Comparable samples</span><b>${similarSetupSample}</b></div>
                        <div><span>Estimated win rate</span><b>${estimatedHistoricalWinRate}%</b></div>
                        <div><span>Estimated average move</span><b>${estimatedAverageMove.toFixed(2)}%</b></div>
                        <div><span>Agreement</span><b>${agreementCount}/${timeframeSnapshots.length} timeframes</b></div>
                    </div>
                    <p class="agent-note">These are heuristic estimates from the loaded candle history, not results from a full historical backtest.</p>
                </section>

                <section class="agent-card">
                    <h3>Decision summary</h3>
                    <p><b>Best next action:</b> ${actionData.action}</p>
                    <p><b>Invalidation:</b> A move through ${formatTradePrice(stop)} invalidates the setup.</p>
                    <p><b>Primary catalyst:</b> ${escapeHTML(newsData.summary)}</p>
                    <p><b>Latest data:</b> ${escapeHTML(primarySnapshot.latest.date)}</p>
                </section>
            </div>
        `;

        output.innerHTML = reportHTML;

        const riskLevelElement = document.getElementById("agentRiskLevel");
        const rewardRiskElement = document.getElementById("agentRewardRisk");
        const positionElement = document.getElementById("agentPositionSize");
        const riskFillElement = document.getElementById("agentRiskFill");

        if (riskLevelElement) riskLevelElement.innerText = riskLevel;
        if (rewardRiskElement) rewardRiskElement.innerText = `${riskReward.toFixed(1)} : 1`;
        if (positionElement) positionElement.innerText = `${positionSize}% max account risk`;
        if (riskFillElement) {
            riskFillElement.style.width = riskLevel === "High" ? "82%" : riskLevel === "Low" ? "30%" : "56%";
        }

        localStorage.setItem("traderAgentAgentOutput", reportHTML);

    } catch (error) {
        console.error(error);
        output.innerHTML = `<p>Unable to generate the trading-copilot report. Confirm that Node is running and market data is available.</p>`;
    }
}


// ---- getSerializableBacktestState() ----


function getSerializableBacktestState() {
    if (!backtestState || !Array.isArray(backtestState.data)) {
        return null;
    }

    return {
        data: backtestState.data,
        index: backtestState.index,
        running: backtestState.running,
        finished: backtestState.finished,
        ticker: backtestState.ticker,
        timeframe: backtestState.timeframe,
        strategy: backtestState.strategy,
        startingCash: backtestState.startingCash,
        cash: backtestState.cash,
        position: backtestState.position,
        trades: backtestState.trades,
        equityCurve: backtestState.equityCurve,
        markers: backtestState.markers,
        settings: backtestState.settings,
        replayDelay: backtestState.replayDelay || 200,
        lastSavedAt: Date.now()
    };
}

// ---- saveBacktestState() ----

function saveBacktestState() {
    if (!document.getElementById("backtestTicker")) {
        return;
    }

    const state = getSerializableBacktestState();

    if (state) {
        localStorage.setItem(
            TRADER_AGENT_BACKTEST_STATE_KEY,
            JSON.stringify(state)
        );
    }
}

// ---- restoreBacktestState() ----

function restoreBacktestState() {
    if (!document.getElementById("backtestTicker")) {
        return false;
    }

    const saved = safeJSONParse(
        localStorage.getItem(TRADER_AGENT_BACKTEST_STATE_KEY),
        null
    );

    if (!saved || !Array.isArray(saved.data) || saved.data.length === 0) {
        return false;
    }

    backtestState = Object.assign({}, backtestState, saved, {
        timer: null,
        running: false
    });

    const tickerInput = document.getElementById("backtestTicker");
    const timeframeInput = document.getElementById("backtestTimeframe");
    const strategyInput = document.getElementById("backtestStrategy");
    const startingCashInput = document.getElementById("backtestStartingCash");
    const positionSizeInput = document.getElementById("backtestPositionSize");
    const stopLossInput = document.getElementById("backtestStopLoss");
    const takeProfitInput = document.getElementById("backtestTakeProfit");
    const speedInput = document.getElementById("backtestSpeed");

    if (tickerInput) tickerInput.value = saved.ticker || tickerInput.value;
    if (timeframeInput) timeframeInput.value = saved.timeframe || timeframeInput.value;
    if (strategyInput) strategyInput.value = saved.strategy || strategyInput.value;
    if (startingCashInput) startingCashInput.value = saved.startingCash || 10000;
    if (positionSizeInput && saved.settings) {
        positionSizeInput.value = saved.settings.positionSize;
    }
    if (stopLossInput && saved.settings) {
        stopLossInput.value = saved.settings.stopLossPercent;
    }
    if (takeProfitInput && saved.settings) {
        takeProfitInput.value = saved.settings.takeProfitPercent;
    }
    if (speedInput && saved.replayDelay) {
        speedInput.value = String(saved.replayDelay);
    }

    // Catch up based on elapsed wall-clock time, so switching pages does not
    // discard replay progress.
    if (saved.running && !saved.finished) {
        const delay = Number(saved.replayDelay) || 200;
        const elapsed = Math.max(0, Date.now() - Number(saved.lastSavedAt || Date.now()));
        const barsToCatchUp = Math.min(
            Math.floor(elapsed / delay),
            Math.max(0, backtestState.data.length - backtestState.index)
        );

        for (let i = 0; i < barsToCatchUp; i++) {
            if (!processNextBacktestBar(false)) {
                break;
            }
        }
    }

    updateBacktestReplayDisplay();

    const status = document.getElementById("backtestStatus");
    if (status) {
        status.innerText = saved.finished
            ? `Restored completed backtest for ${saved.ticker}.`
            : `Restored ${saved.ticker} at candle ${backtestState.index} of ${backtestState.data.length}.`;
    }

    if (saved.running && !backtestState.finished) {
        playBacktestReplay();
    }

    return true;
}

// ---- runBacktest() ----

async function runBacktest() {
    const tickerInput = document.getElementById("backtestTicker");
    const startInput = document.getElementById("backtestStartDate");
    const endInput = document.getElementById("backtestEndDate");
    const timeframeInput = document.getElementById("backtestTimeframe");
    const status = document.getElementById("backtestStatus");

    if (!tickerInput || !startInput || !endInput || !timeframeInput || !status) {
        return;
    }

    const ticker = tickerInput.value.trim().toUpperCase();
    const start = startInput.value;
    const end = endInput.value;
    const timeframe = timeframeInput.value;

    if (!ticker || !start || !end) {
        status.innerText = "Enter a ticker, start date, and end date.";
        return;
    }

    if (new Date(start) > new Date(end)) {
        status.innerText = "The start date must be before the end date.";
        return;
    }

    pauseBacktestReplay();
    status.innerText = `Loading ${ticker} ${timeframe} candles from ${start} through ${end}...`;

    try {
        const response = await fetch(
            `http://localhost:3000/backtest-data?ticker=${encodeURIComponent(ticker)}&timeframe=${encodeURIComponent(timeframe)}&start=${encodeURIComponent(start)}&end=${encodeURIComponent(end)}`
        );

        const result = await response.json();

        if (!response.ok) {
            throw new Error(result.error || "Backtest data request failed.");
        }

        const data = Array.isArray(result) ? result : result.data;

        if (!Array.isArray(data) || data.length < 30) {
            status.innerText = result.message || "Not enough historical candles were returned for this date range.";
            clearBacktestDisplay();
            return;
        }

        const startingCash = Number(document.getElementById("backtestStartingCash").value) || 10000;

        backtestState = {
            data: data,
            index: Math.min(25, data.length - 1),
            timer: null,
            running: false,
            finished: false,
            ticker: ticker,
            timeframe: timeframe,
            strategy: document.getElementById("backtestStrategy").value,
            startingCash: startingCash,
            cash: startingCash,
            position: null,
            trades: [],
            equityCurve: [],
            markers: [],
            settings: {
                positionSize: Number(document.getElementById("backtestPositionSize").value) || 0.5,
                stopLossPercent: Number(document.getElementById("backtestStopLoss").value) || 1,
                takeProfitPercent: Number(document.getElementById("backtestTakeProfit").value) || 2
            },
            replayDelay: Number(document.getElementById("backtestSpeed").value) || 200,
            lastSavedAt: Date.now()
        };

        seedBacktestEquity();
        status.innerText = `${data.length} candles loaded. Press Play, Step, or run the full replay.`;
        updateBacktestReplayDisplay();
        saveBacktestState();
        playBacktestReplay();

    } catch (error) {
        console.error("Backtest error:", error);
        status.innerText = `Unable to run backtest: ${error.message}`;
        clearBacktestDisplay();
    }
}

// ---- initializeBacktestPage() ----

function initializeBacktestPage() {
    const startInput = document.getElementById("backtestStartDate");
    const endInput = document.getElementById("backtestEndDate");
    const clock = document.getElementById("liveBacktestClock");

    if (!startInput || !endInput) {
        return;
    }

    const now = new Date();
    const start = new Date(now);
    start.setDate(start.getDate() - 30);

    if (!endInput.value) {
        endInput.value = formatDateInputValue(now);
    }

    if (!startInput.value) {
        startInput.value = formatDateInputValue(start);
    }

    // ---- refreshClock() ----

    function refreshClock() {
        if (!clock) return;

        clock.innerText = new Intl.DateTimeFormat("en-US", {
            weekday: "short",
            month: "short",
            day: "numeric",
            year: "numeric",
            hour: "numeric",
            minute: "2-digit",
            second: "2-digit",
            timeZoneName: "short"
        }).format(new Date());
    }

    refreshClock();
    setInterval(refreshClock, 1000);
}

// ---- formatDateInputValue() ----

function formatDateInputValue(date) {
    const year = date.getFullYear();
    const month = String(date.getMonth() + 1).padStart(2, "0");
    const day = String(date.getDate()).padStart(2, "0");
    return `${year}-${month}-${day}`;
}

// ---- playBacktestReplay() ----

function playBacktestReplay() {
    if (!backtestState.data.length || backtestState.running || backtestState.finished) {
        return;
    }

    const speedInput = document.getElementById("backtestSpeed");
    const delay = speedInput ? Number(speedInput.value) || 200 : 200;

    backtestState.replayDelay = delay;
    backtestState.running = true;
    saveBacktestState();
    backtestState.timer = setInterval(function() {
        const hasMore = processNextBacktestBar();

        if (!hasMore) {
            finishBacktestReplay();
        }
    }, delay);
}

// ---- pauseBacktestReplay() ----

function pauseBacktestReplay() {
    clearInterval(backtestState.timer);
    backtestState.timer = null;
    backtestState.running = false;
    saveBacktestState();
}

// ---- stepBacktestReplay() ----

function stepBacktestReplay() {
    if (!backtestState.data.length || backtestState.finished) {
        return;
    }

    pauseBacktestReplay();
    const hasMore = processNextBacktestBar();

    if (!hasMore) {
        finishBacktestReplay();
    }
}

// ---- resetBacktestReplay() ----

function resetBacktestReplay() {
    if (!backtestState.data.length) {
        return;
    }

    pauseBacktestReplay();
    backtestState.index = Math.min(25, backtestState.data.length - 1);
    backtestState.cash = backtestState.startingCash;
    backtestState.position = null;
    backtestState.trades = [];
    backtestState.equityCurve = [];
    backtestState.markers = [];
    backtestState.finished = false;
    seedBacktestEquity();
    updateBacktestReplayDisplay();
    saveBacktestState();
}

// ---- seedBacktestEquity() ----

function seedBacktestEquity() {
    const seedLength = Math.max(1, backtestState.index);
    backtestState.equityCurve = [];

    for (let i = 0; i < seedLength; i++) {
        backtestState.equityCurve.push({
            label: backtestState.data[i].date,
            value: backtestState.startingCash
        });
    }
}

// ---- processNextBacktestBar() ----

function processNextBacktestBar(shouldRender = true) {
    if (backtestState.index >= backtestState.data.length) {
        return false;
    }

    const i = backtestState.index;
    const bar = backtestState.data[i];
    const history = backtestState.data.slice(0, i + 1);

    manageOpenBacktestPosition(bar, i);

    if (!backtestState.position) {
        const signal = getHistoricalBacktestSignal(history, backtestState.strategy);

        if (signal.enter) {
            openBacktestPosition(bar, i, signal.reason);
        }
    }

    const equity = calculateBacktestEquity(bar.close);
    backtestState.equityCurve.push({ label: bar.date, value: equity });
    backtestState.index++;

    if (shouldRender) {
        updateBacktestReplayDisplay();
    }

    saveBacktestState();
    return backtestState.index < backtestState.data.length;
}

// ---- getHistoricalBacktestSignal() ----

function getHistoricalBacktestSignal(history, strategy) {
    if (history.length < 26) {
        return { enter: false, reason: "Not enough indicator history" };
    }

    const closes = history.map(function(bar) { return bar.close; });
    const latest = history[history.length - 1];
    const previous = history[history.length - 2];
    const sma9 = calculateSMA(closes, 9);
    const sma20 = calculateSMA(closes, 20);
    const rsi = calculateRSI(closes, 14);
    const macd = calculateMACD(closes);
    const volumeAverage = calculateAverageVolume(history, 20);
    const volumeRatio = volumeAverage > 0 ? latest.volume / volumeAverage : 1;
    const momentum = latest.close - history[history.length - 6].close;

    if (strategy === "trend") {
        const pullbackRecovered =
            previous.close <= sma9 &&
            latest.close > sma9 &&
            latest.close > sma20;

        return {
            enter:
                pullbackRecovered &&
                rsi >= 40 && rsi <= 65 &&
                macd > 0 &&
                volumeRatio >= 0.8,
            reason: "Trend pullback recovered above SMA9 while broader trend stayed bullish"
        };
    }

    return {
        enter:
            latest.close > sma9 &&
            sma9 > sma20 &&
            momentum > 0 &&
            macd > 0 &&
            rsi >= 45 && rsi <= 70 &&
            volumeRatio >= 1,
        reason: "Momentum, moving averages, RSI, MACD, and volume aligned"
    };
}

// ---- openBacktestPosition() ----

function openBacktestPosition(bar, index, reason) {
    const allocation = backtestState.cash * backtestState.settings.positionSize;
    const shares = Math.floor(allocation / bar.close);

    if (shares < 1) {
        return;
    }

    const entryPrice = bar.close;
    const stopPrice = entryPrice * (1 - backtestState.settings.stopLossPercent / 100);
    const targetPrice = entryPrice * (1 + backtestState.settings.takeProfitPercent / 100);

    backtestState.cash -= shares * entryPrice;
    backtestState.position = {
        shares: shares,
        entryPrice: entryPrice,
        entryIndex: index,
        entryDate: bar.date,
        stopPrice: stopPrice,
        targetPrice: targetPrice,
        reason: reason
    };

    backtestState.markers.push({
        index: index,
        price: entryPrice,
        type: "BUY"
    });
}

// ---- manageOpenBacktestPosition() ----

function manageOpenBacktestPosition(bar, index) {
    const position = backtestState.position;

    if (!position) {
        return;
    }

    let exitPrice = null;
    let exitReason = "";

    if (bar.low <= position.stopPrice) {
        exitPrice = position.stopPrice;
        exitReason = "Stop loss";
    } else if (bar.high >= position.targetPrice) {
        exitPrice = position.targetPrice;
        exitReason = "Take profit";
    } else {
        const maxBars = getMaximumBacktestHoldBars(backtestState.timeframe);
        const heldBars = index - position.entryIndex;

        if (heldBars >= maxBars) {
            exitPrice = bar.close;
            exitReason = "Maximum day-trade hold reached";
        }
    }

    if (exitPrice !== null) {
        closeBacktestPosition(exitPrice, bar.date, index, exitReason);
    }
}

// ---- getMaximumBacktestHoldBars() ----

function getMaximumBacktestHoldBars(timeframe) {
    const limits = {
        "1m": 60,
        "3m": 30,
        "5m": 24,
        "15m": 16,
        "30m": 10,
        "1h": 6,
        "1d": 5
    };

    return limits[timeframe] || 24;
}

// ---- closeBacktestPosition() ----

function closeBacktestPosition(exitPrice, exitDate, exitIndex, exitReason) {
    const position = backtestState.position;

    if (!position) {
        return;
    }

    const proceeds = position.shares * exitPrice;
    const profit = (exitPrice - position.entryPrice) * position.shares;
    const returnPercent = ((exitPrice - position.entryPrice) / position.entryPrice) * 100;

    backtestState.cash += proceeds;
    backtestState.trades.push({
        entryDate: position.entryDate,
        exitDate: exitDate,
        side: "LONG",
        shares: position.shares,
        entryPrice: position.entryPrice,
        exitPrice: exitPrice,
        profit: profit,
        returnPercent: returnPercent,
        holdBars: exitIndex - position.entryIndex,
        exitReason: exitReason,
        entryReason: position.reason
    });

    backtestState.markers.push({
        index: exitIndex,
        price: exitPrice,
        type: "SELL"
    });

    backtestState.position = null;
}

// ---- calculateBacktestEquity() ----

function calculateBacktestEquity(markPrice) {
    const positionValue = backtestState.position
        ? backtestState.position.shares * markPrice
        : 0;

    return backtestState.cash + positionValue;
}

// ---- finishBacktestReplay() ----

function finishBacktestReplay() {
    pauseBacktestReplay();

    if (backtestState.position && backtestState.data.length) {
        const finalIndex = backtestState.data.length - 1;
        const finalBar = backtestState.data[finalIndex];
        closeBacktestPosition(finalBar.close, finalBar.date, finalIndex, "End of backtest");
        backtestState.equityCurve.push({
            label: finalBar.date,
            value: backtestState.cash
        });
    }

    backtestState.finished = true;
    backtestState.index = backtestState.data.length;
    updateBacktestReplayDisplay();

    const status = document.getElementById("backtestStatus");
    if (status) {
        status.innerText = `Backtest complete for ${backtestState.ticker}.`;
    }

    saveBacktestState();
}

// ---- updateBacktestReplayDisplay() ----

function updateBacktestReplayDisplay() {
    if (!backtestState.data.length) {
        return;
    }

    const visibleCount = Math.max(1, Math.min(backtestState.index, backtestState.data.length));
    const visibleData = backtestState.data.slice(0, visibleCount);
    const latestBar = visibleData[visibleData.length - 1];

    if (window.TraderCharts) {
            window.TraderCharts.renderBacktestChart(
                visibleData,
                backtestState.markers,
                {
                    containerId: "backtestMarketChart",
                    height: 500
                }
            );

            window.TraderCharts.renderEquityChart(
                backtestState.equityCurve,
                {
                    containerId: "backtestChart",
                    height: 280
                }
            );
        } else {
            console.error("TraderCharts did not load.");
        }

    const replayLabel = document.getElementById("backtestReplayLabel");
    if (replayLabel) {
        replayLabel.innerText = `${backtestState.ticker} ${backtestState.timeframe} | ${latestBar.date} | Candle ${visibleCount} of ${backtestState.data.length}`;
    }

    const positionSummary = document.getElementById("backtestPositionSummary");
    if (positionSummary) {
        const equity = calculateBacktestEquity(latestBar.close);
        const positionText = backtestState.position
            ? `${backtestState.position.shares} shares @ $${backtestState.position.entryPrice.toFixed(2)}`
            : "None";

        positionSummary.innerText = `Cash: $${backtestState.cash.toFixed(2)} | Position: ${positionText} | Equity: $${equity.toFixed(2)}`;
    }

    renderBacktestTrades();
    renderBacktestStatistics(latestBar.close);
}

// ---- renderBacktestTrades() ----

function renderBacktestTrades() {
    const table = document.getElementById("backtestTradesTable");

    if (!table) {
        return;
    }

    const rows = backtestState.trades.map(function(trade, index) {
        const resultClass = trade.profit >= 0 ? "positive" : "negative";

        return `
            <tr>
                <td>#${index + 1}</td>
                <td>${trade.entryDate}</td>
                <td>${trade.exitDate}</td>
                <td>${trade.side}</td>
                <td>${trade.shares}</td>
                <td>$${trade.entryPrice.toFixed(2)}</td>
                <td>$${trade.exitPrice.toFixed(2)}</td>
                <td class="${resultClass}">${trade.profit >= 0 ? "+" : ""}$${trade.profit.toFixed(2)}</td>
                <td class="${resultClass}">${trade.returnPercent >= 0 ? "+" : ""}${trade.returnPercent.toFixed(2)}%</td>
                <td>${trade.exitReason}</td>
            </tr>
        `;
    }).join("");

    table.innerHTML = `
        <tr>
            <th>#</th>
            <th>Entry Time</th>
            <th>Exit Time</th>
            <th>Side</th>
            <th>Shares</th>
            <th>Entry</th>
            <th>Exit</th>
            <th>P/L</th>
            <th>Return</th>
            <th>Exit Reason</th>
        </tr>
        ${rows}
    `;
}

// ---- renderBacktestStatistics() ----

function renderBacktestStatistics(markPrice) {
    const endingEquity = calculateBacktestEquity(markPrice);
    const totalReturn = ((endingEquity - backtestState.startingCash) / backtestState.startingCash) * 100;
    const winningTrades = backtestState.trades.filter(function(trade) { return trade.profit > 0; });
    const losingTrades = backtestState.trades.filter(function(trade) { return trade.profit < 0; });
    const winRate = backtestState.trades.length
        ? (winningTrades.length / backtestState.trades.length) * 100
        : 0;

    const averageWin = winningTrades.length
        ? winningTrades.reduce(function(total, trade) { return total + trade.returnPercent; }, 0) / winningTrades.length
        : 0;

    const averageLoss = losingTrades.length
        ? losingTrades.reduce(function(total, trade) { return total + trade.returnPercent; }, 0) / losingTrades.length
        : 0;

    const bestTrade = backtestState.trades.length
        ? Math.max.apply(null, backtestState.trades.map(function(trade) { return trade.returnPercent; }))
        : 0;

    const worstTrade = backtestState.trades.length
        ? Math.min.apply(null, backtestState.trades.map(function(trade) { return trade.returnPercent; }))
        : 0;

    const grossProfit = winningTrades.reduce(function(total, trade) { return total + trade.profit; }, 0);
    const grossLoss = Math.abs(losingTrades.reduce(function(total, trade) { return total + trade.profit; }, 0));
    const profitFactor = grossLoss > 0 ? grossProfit / grossLoss : grossProfit > 0 ? Infinity : 0;
    const averageHold = backtestState.trades.length
        ? backtestState.trades.reduce(function(total, trade) { return total + trade.holdBars; }, 0) / backtestState.trades.length
        : 0;

    const maxDrawdown = calculateMaximumDrawdown(backtestState.equityCurve.map(function(point) { return point.value; }));

    setBacktestMetric("backtestTotalReturn", `${totalReturn >= 0 ? "+" : ""}${totalReturn.toFixed(2)}%`, totalReturn);
    setBacktestMetric("backtestWinRate", `${winRate.toFixed(1)}%`);
    setBacktestMetric("backtestTotalTrades", String(backtestState.trades.length));
    setBacktestMetric("backtestMaxDrawdown", `-${maxDrawdown.toFixed(2)}%`, -maxDrawdown);

    setText("backtestEndingEquity", `$${endingEquity.toFixed(2)}`);
    setText("backtestAverageWin", `${averageWin >= 0 ? "+" : ""}${averageWin.toFixed(2)}%`);
    setText("backtestAverageLoss", `${averageLoss.toFixed(2)}%`);
    setText("backtestBestTrade", `${bestTrade >= 0 ? "+" : ""}${bestTrade.toFixed(2)}%`);
    setText("backtestWorstTrade", `${worstTrade.toFixed(2)}%`);
    setText("backtestProfitFactor", Number.isFinite(profitFactor) ? profitFactor.toFixed(2) : "∞");
    setText("backtestAverageHold", `${averageHold.toFixed(1)} candles`);
    setText("backtestBarsLoaded", String(backtestState.data.length));
}

// ---- calculateMaximumDrawdown() ----

function calculateMaximumDrawdown(values) {
    if (!values.length) {
        return 0;
    }

    let peak = values[0];
    let maximumDrawdown = 0;

    values.forEach(function(value) {
        if (value > peak) {
            peak = value;
        }

        if (peak > 0) {
            maximumDrawdown = Math.max(
                maximumDrawdown,
                ((peak - value) / peak) * 100
            );
        }
    });

    return maximumDrawdown;
}

// ---- setBacktestMetric() ----

function setBacktestMetric(id, text, numericValue) {
    const element = document.getElementById(id);

    if (!element) return;

    element.innerText = text;

    if (typeof numericValue === "number") {
        element.className = `big ${numericValue >= 0 ? "positive" : "negative"}`;
    }
}

// ---- setText() ----

function setText(id, text) {
    const element = document.getElementById(id);
    if (element) element.innerText = text;
}

// ---- clearBacktestDisplay() ----

function clearBacktestDisplay() {
    [
        "backtestTotalReturn",
        "backtestWinRate",
        "backtestTotalTrades",
        "backtestMaxDrawdown",
        "backtestEndingEquity",
        "backtestAverageWin",
        "backtestAverageLoss",
        "backtestBestTrade",
        "backtestWorstTrade",
        "backtestProfitFactor",
        "backtestAverageHold",
        "backtestBarsLoaded"
    ].forEach(function(id) {
        setText(id, "--");
    });
}

// ---- drawBacktestMarketChart() ----

function drawBacktestMarketChart(canvasId, data, markers) {
    const canvas = document.getElementById(canvasId);
    if (!canvas || !data.length) return;

    const ctx = canvas.getContext("2d");
    const width = canvas.width = canvas.offsetWidth;
    const height = canvas.height = 420;
    const left = 70;
    const right = 25;
    const top = 25;
    const bottom = 55;
    const chartWidth = width - left - right;
    const chartHeight = height - top - bottom;
    const visibleData = data.slice(-120);
    const startIndex = Math.max(0, data.length - visibleData.length);
    const maxPrice = Math.max.apply(null, visibleData.map(function(bar) { return bar.high; }));
    const minPrice = Math.min.apply(null, visibleData.map(function(bar) { return bar.low; }));
    const range = maxPrice - minPrice || 1;

    ctx.clearRect(0, 0, width, height);
    ctx.fillStyle = "#10141f";
    ctx.fillRect(0, 0, width, height);

    // ---- xFor() ----

    function xFor(localIndex) {
        return left + ((localIndex + 0.5) / visibleData.length) * chartWidth;
    }

    // ---- yFor() ----

    function yFor(price) {
        return top + ((maxPrice - price) / range) * chartHeight;
    }

    ctx.font = "12px Arial";

    for (let i = 0; i <= 5; i++) {
        const price = maxPrice - (range / 5) * i;
        const y = yFor(price);
        ctx.strokeStyle = "#252c3b";
        ctx.beginPath();
        ctx.moveTo(left, y);
        ctx.lineTo(width - right, y);
        ctx.stroke();
        ctx.fillStyle = "#9aa4b5";
        ctx.fillText(`$${price.toFixed(2)}`, 8, y + 4);
    }

    const candleWidth = Math.max(2, Math.min(9, chartWidth / visibleData.length * 0.65));

    visibleData.forEach(function(bar, localIndex) {
        const x = xFor(localIndex);
        const openY = yFor(bar.open);
        const closeY = yFor(bar.close);
        const highY = yFor(bar.high);
        const lowY = yFor(bar.low);
        const bullish = bar.close >= bar.open;
        const candleColor = bullish ? "#22c55e" : "#ef4444";

        ctx.strokeStyle = candleColor;
        ctx.beginPath();
        ctx.moveTo(x, highY);
        ctx.lineTo(x, lowY);
        ctx.stroke();

        ctx.fillStyle = candleColor;
        ctx.fillRect(
            x - candleWidth / 2,
            Math.min(openY, closeY),
            candleWidth,
            Math.max(1, Math.abs(closeY - openY))
        );
    });

    markers.forEach(function(marker) {
        if (marker.index < startIndex || marker.index >= data.length) {
            return;
        }

        const localIndex = marker.index - startIndex;
        const x = xFor(localIndex);
        const y = yFor(marker.price);
        ctx.fillStyle = marker.type === "BUY" ? "#3b82f6" : "#f59e0b";
        ctx.beginPath();

        if (marker.type === "BUY") {
            ctx.moveTo(x, y - 12);
            ctx.lineTo(x - 6, y - 2);
            ctx.lineTo(x + 6, y - 2);
        } else {
            ctx.moveTo(x, y + 12);
            ctx.lineTo(x - 6, y + 2);
            ctx.lineTo(x + 6, y + 2);
        }

        ctx.closePath();
        ctx.fill();
    });

    const labels = [0, Math.floor((visibleData.length - 1) / 2), visibleData.length - 1];
    labels.forEach(function(localIndex) {
        const bar = visibleData[localIndex];
        if (!bar) return;
        const x = xFor(localIndex);
        ctx.fillStyle = "#9aa4b5";
        ctx.fillText(formatBacktestAxisLabel(bar.date), x - 28, height - 22);
    });
}

// ---- drawBacktestEquityChart() ----

function drawBacktestEquityChart(canvasId, points) {
    const canvas = document.getElementById(canvasId);
    if (!canvas || points.length < 2) return;

    const ctx = canvas.getContext("2d");
    const width = canvas.width = canvas.offsetWidth;
    const height = canvas.height = 260;
    const left = 60;
    const right = 20;
    const top = 20;
    const bottom = 35;
    const values = points.map(function(point) { return point.value; });
    const max = Math.max.apply(null, values);
    const min = Math.min.apply(null, values);
    const range = max - min || 1;

    ctx.clearRect(0, 0, width, height);
    ctx.fillStyle = "#10141f";
    ctx.fillRect(0, 0, width, height);

    ctx.strokeStyle = "#2b3344";
    for (let i = 0; i <= 4; i++) {
        const y = top + ((height - top - bottom) / 4) * i;
        ctx.beginPath();
        ctx.moveTo(left, y);
        ctx.lineTo(width - right, y);
        ctx.stroke();
    }

    ctx.beginPath();
    points.forEach(function(point, index) {
        const x = left + (index / (points.length - 1)) * (width - left - right);
        const y = top + ((max - point.value) / range) * (height - top - bottom);

        if (index === 0) ctx.moveTo(x, y);
        else ctx.lineTo(x, y);
    });
    ctx.strokeStyle = "#2962ff";
    ctx.lineWidth = 2.5;
    ctx.stroke();

    ctx.fillStyle = "#9aa4b5";
    ctx.font = "12px Arial";
    ctx.fillText(`$${max.toFixed(0)}`, 6, top + 4);
    ctx.fillText(`$${min.toFixed(0)}`, 6, height - bottom);
}

// ---- formatBacktestAxisLabel() ----

function formatBacktestAxisLabel(value) {
    if (!value) return "";
    const parts = String(value).split(" ");
    return parts.length > 1 ? parts[1].slice(0, 5) : parts[0].slice(0, 10);
}

// ---- saveSettings() ----

function saveSettings() {
    alert("Settings saved.");
}

// ---- addTicker() ----

function addTicker() {
    const input = document.getElementById("newTicker");
    const table = document.getElementById("watchlistTable");

    if (!input || !table) {
        return;
    }

    const ticker = input.value.trim().toUpperCase();

    if (ticker === "") {
        alert("Enter a ticker first.");
        return;
    }

    if (!/^[A-Z][A-Z0-9.-]{0,9}$/.test(ticker)) {
        alert("Enter a valid ticker symbol.");
        return;
    }

    const existingTickers = getExistingWatchlistTickers();

    if (existingTickers.includes(ticker)) {
        alert(`${ticker} is already in the watchlist.`);
        return;
    }

    const row = table.insertRow(-1);

    row.innerHTML = `
        <td>${ticker}</td>
        <td>Loading...</td>
        <td>Loading...</td>
        <td>WATCH</td>
    `;

    input.value = "";

    saveWatchlistToStorage();
    updateWatchlistData();
}

// ---- renderAnalysisChartSafe() ----

function renderAnalysisChartSafe(data, options) {
    options = options || {};
    const containerId = options.containerId || "stockChart";
    const element = document.getElementById(containerId);
    if (!element || !Array.isArray(data) || data.length < 2) return false;

    if (window.TraderCharts && typeof window.TraderCharts.renderAnalysisChart === "function") {
        try {
            window.TraderCharts.renderAnalysisChart(data, options);
            return true;
        } catch (error) {
            console.error("Advanced chart renderer failed; using built-in chart:", error);
        }
    }

    const prices = data.map(function(item) { return Number(item.close); });
    const labels = data.map(function(item) { return item.date || ""; });
    const smaData = prices.map(function(price, index) {
        if (index < 19) return null;
        return calculateSMA(prices.slice(0, index + 1), 20);
    });

    if (element instanceof HTMLCanvasElement) {
        drawStockChart(containerId, prices, labels, smaData);
        return true;
    }

    renderBuiltInCandlestickChart(element, data, options);
    return true;
}

// ---- renderBuiltInCandlestickChart() ----

function renderBuiltInCandlestickChart(container, data, options) {
    const bars = data.slice(-80);
    const width = Math.max(container.clientWidth || 900, 500);
    const height = Number(options && options.height) || 500;
    const pad = { left: 64, right: 24, top: 24, bottom: 46 };
    const plotWidth = width - pad.left - pad.right;
    const plotHeight = height - pad.top - pad.bottom;
    const lows = bars.map(function(bar) { return Number(bar.low); });
    const highs = bars.map(function(bar) { return Number(bar.high); });
    let minPrice = Math.min.apply(null, lows);
    let maxPrice = Math.max.apply(null, highs);
    const extra = Math.max((maxPrice - minPrice) * 0.08, maxPrice * 0.002);
    minPrice -= extra;
    maxPrice += extra;
    const range = maxPrice - minPrice || 1;
    const step = plotWidth / Math.max(bars.length, 1);
    const candleWidth = Math.max(2, Math.min(10, step * 0.62));
    const x = function(index) { return pad.left + step * index + step / 2; };
    const y = function(price) { return pad.top + ((maxPrice - price) / range) * plotHeight; };
    const escape = function(value) {
        return String(value == null ? "" : value)
            .replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;")
            .replace(/"/g, "&quot;");
    };

    let svg = `<svg viewBox="0 0 ${width} ${height}" width="100%" height="${height}" role="img" aria-label="Stock candlestick chart" style="display:block;background:#0f131c;border-radius:6px">`;
    for (let i = 0; i <= 5; i++) {
        const price = maxPrice - (range * i / 5);
        const yy = y(price);
        svg += `<line x1="${pad.left}" y1="${yy}" x2="${width-pad.right}" y2="${yy}" stroke="#262d3d" stroke-width="1"/>`;
        svg += `<text x="8" y="${yy+4}" fill="#8b93a7" font-size="11">$${price.toFixed(2)}</text>`;
    }

    bars.forEach(function(bar, index) {
        const open = Number(bar.open), close = Number(bar.close), high = Number(bar.high), low = Number(bar.low);
        const rising = close >= open;
        const color = rising ? "#089981" : "#f23645";
        const xx = x(index);
        const bodyTop = y(Math.max(open, close));
        const bodyBottom = y(Math.min(open, close));
        const bodyHeight = Math.max(1.5, bodyBottom - bodyTop);
        svg += `<g><title>${escape(bar.date)} | O ${open.toFixed(2)} H ${high.toFixed(2)} L ${low.toFixed(2)} C ${close.toFixed(2)} V ${Number(bar.volume||0).toLocaleString()}</title>`;
        svg += `<line x1="${xx}" y1="${y(high)}" x2="${xx}" y2="${y(low)}" stroke="${color}" stroke-width="1.2"/>`;
        svg += `<rect x="${xx-candleWidth/2}" y="${bodyTop}" width="${candleWidth}" height="${bodyHeight}" fill="${color}" rx="0.7"/></g>`;
    });

    const labelIndexes = [0, Math.floor((bars.length-1)/2), bars.length-1];
    labelIndexes.forEach(function(index) {
        if (index < 0 || !bars[index]) return;
        svg += `<text x="${x(index)}" y="${height-15}" fill="#8b93a7" font-size="11" text-anchor="middle">${escape(formatChartDate(bars[index].date || ""))}</text>`;
    });
    svg += `</svg>`;
    container.innerHTML = svg;
}

// ---- drawStockChart() ----

function drawStockChart(canvasId, prices, labels = [], smaData = []) {
    const canvas = document.getElementById(canvasId);
    if (!canvas || prices.length < 2) return;

    const ctx = canvas.getContext("2d");

    const width = canvas.width = canvas.offsetWidth;
    const height = canvas.height = 380;

    const paddingLeft = 70;
    const paddingRight = 35;
    const paddingTop = 35;
    const paddingBottom = 65;

    const chartWidth = width - paddingLeft - paddingRight;
    const chartHeight = height - paddingTop - paddingBottom;

    ctx.clearRect(0, 0, width, height);

    const validSma = smaData.filter(function(value) {
        return value !== null && !isNaN(value);
    });

    const allValues = prices.concat(validSma);
    const maxPrice = Math.max(...allValues);
    const minPrice = Math.min(...allValues);
    const priceRange = maxPrice - minPrice || 1;

    // ---- getX() ----

    function getX(index) {
        return paddingLeft + (index / (prices.length - 1)) * chartWidth;
    }

    // ---- getY() ----

    function getY(price) {
        return paddingTop + ((maxPrice - price) / priceRange) * chartHeight;
    }

    ctx.fillStyle = "#ffffff";
    ctx.fillRect(0, 0, width, height);

    ctx.font = "12px Arial";
    ctx.lineWidth = 1;

    // Y-axis price labels and grid
    const ySteps = 6;

    for (let i = 0; i <= ySteps; i++) {
        const price = maxPrice - (priceRange / ySteps) * i;
        const y = getY(price);

        ctx.beginPath();
        ctx.moveTo(paddingLeft, y);
        ctx.lineTo(width - paddingRight, y);
        ctx.strokeStyle = "#e5e7eb";
        ctx.stroke();

        ctx.fillStyle = "#374151";
        ctx.fillText(`$${price.toFixed(2)}`, 12, y + 4);
    }

    // X-axis date labels
    const xLabelCount = 5;

    for (let i = 0; i < xLabelCount; i++) {
        const index = Math.floor((prices.length - 1) * (i / (xLabelCount - 1)));
        const x = getX(index);
        const rawLabel = labels[index] || "";
        const label = formatChartDate(rawLabel);

        ctx.beginPath();
        ctx.moveTo(x, paddingTop);
        ctx.lineTo(x, height - paddingBottom);
        ctx.strokeStyle = "#f3f4f6";
        ctx.stroke();

        ctx.fillStyle = "#374151";
        ctx.fillText(label, x - 22, height - 35);
    }

    // Axis lines
    ctx.beginPath();
    ctx.moveTo(paddingLeft, paddingTop);
    ctx.lineTo(paddingLeft, height - paddingBottom);
    ctx.lineTo(width - paddingRight, height - paddingBottom);
    ctx.strokeStyle = "#111827";
    ctx.lineWidth = 1.5;
    ctx.stroke();

    // Axis titles
    ctx.fillStyle = "#111827";
    ctx.font = "13px Arial";
    ctx.fillText("Date / Time", width / 2 - 35, height - 10);

    ctx.save();
    ctx.translate(18, height / 2 + 45);
    ctx.rotate(-Math.PI / 2);
    ctx.fillText("Stock Price ($)", 0, 0);
    ctx.restore();

    // Price line
    ctx.beginPath();

    prices.forEach(function(price, index) {
        const x = getX(index);
        const y = getY(price);

        if (index === 0) {
            ctx.moveTo(x, y);
        } else {
            ctx.lineTo(x, y);
        }
    });

    ctx.strokeStyle = "#2563eb";
    ctx.lineWidth = 3;
    ctx.stroke();

    // SMA20 line
    ctx.beginPath();

    let startedSma = false;

    smaData.forEach(function(value, index) {
        if (value === null || isNaN(value)) return;

        const x = getX(index);
        const y = getY(value);

        if (!startedSma) {
            ctx.moveTo(x, y);
            startedSma = true;
        } else {
            ctx.lineTo(x, y);
        }
    });

    ctx.strokeStyle = "#f59e0b";
    ctx.lineWidth = 2;
    ctx.stroke();

    // Latest price marker
    const latestPrice = prices[prices.length - 1];
    const latestX = getX(prices.length - 1);
    const latestY = getY(latestPrice);

    ctx.beginPath();
    ctx.arc(latestX, latestY, 6, 0, Math.PI * 2);
    ctx.fillStyle = "#111827";
    ctx.fill();

    ctx.fillStyle = "#111827";
    ctx.font = "13px Arial";
    ctx.fillText(`Latest: $${latestPrice.toFixed(2)}`, latestX - 105, latestY - 12);

    // Legend
    ctx.font = "13px Arial";

    ctx.fillStyle = "#2563eb";
    ctx.fillRect(paddingLeft, 12, 14, 4);
    ctx.fillStyle = "#111827";
    ctx.fillText("Price", paddingLeft + 20, 17);

    ctx.fillStyle = "#f59e0b";
    ctx.fillRect(paddingLeft + 80, 12, 14, 4);
    ctx.fillStyle = "#111827";
    ctx.fillText("SMA20", paddingLeft + 100, 17);
}

// ---- formatChartDate() ----

function formatChartDate(dateText) {
    if (!dateText) return "";

    const timeframe = getSelectedTimeframe();

    // If Finviz gives date + time, example: 07/02/2026 13:45
    if (dateText.includes(" ")) {
        const parts = dateText.split(" ");
        const datePart = parts[0];
        const timePart = parts[1];

        if (timeframe === "1m" || timeframe === "3m" || timeframe === "5m" || timeframe === "15m" || timeframe === "30m" || timeframe === "1h" || timeframe === "4h") {
            return timePart;
        }

        return datePart;
    }

    // If it only gives a date, example: 07/02/2026
    const parts = dateText.split("/");

    if (parts.length === 3) {
        return `${parts[0]}/${parts[1]}`;
    }

    return dateText;
}

// ---- analyzeResearchInput() ----

async function analyzeResearchInput() {
    const urlInput = document.getElementById("researchUrl");
    const textInput = document.getElementById("researchText");
    const output = document.getElementById("researchOutput");

    if (!urlInput || !textInput || !output) return;

    const url = urlInput.value.trim();
    let researchText = textInput.value.trim();

    output.innerHTML = "Analyzing research...";

    if (url !== "") {
        try {
            const response = await fetch("http://localhost:3000/analyze-url", {
                method: "POST",
                headers: {
                    "Content-Type": "application/json"
                },
                body: JSON.stringify({ url: url })
            });

            const result = await response.json();

            if (result.text) {
                researchText += " " + result.text;
            }

        } catch (error) {
            console.error(error);
        }
    }

    if (researchText.trim() === "") {
        output.innerHTML = "Please paste a URL or article text first.";
        return;
    }

    const researchScore = scoreResearchSentiment(researchText);
    const ticker = document.getElementById("tickerInput").value.toUpperCase();
    const timeframe = getSelectedTimeframe();

    output.innerHTML = `
        <h4>AI Research Analysis</h4>

        <p><b>Ticker:</b> ${ticker}</p>
        <p><b>Timeframe:</b> ${timeframe}</p>
        <p><b>Research Sentiment Score:</b> ${researchScore.score}</p>
        <p><b>Sentiment:</b> ${researchScore.label}</p>

        <p><b>Key Positive Signals:</b> ${researchScore.positiveMatches.join(", ") || "None found"}</p>
        <p><b>Key Negative Signals:</b> ${researchScore.negativeMatches.join(", ") || "None found"}</p>

        <p><b>AI Summary:</b> ${researchScore.summary}</p>

        <p><b>How TraderAgent Uses This:</b> This research score can be combined with chart data, RSI, SMA20, MACD, momentum, and Finviz news to adjust the final BUY / SELL / HOLD decision.</p>
    `;
    saveAnalysisPageState();
}

// ---- scoreResearchSentiment() ----

function scoreResearchSentiment(text) {
    const lowerText = text.toLowerCase();

    const positiveWords = [
        "beat", "beats", "upgrade", "upgraded", "growth", "strong",
        "record", "profit", "profits", "partnership", "deal",
        "approval", "launch", "bullish", "outperform", "raises",
        "surge", "expansion", "demand"
    ];

    const negativeWords = [
        "miss", "misses", "downgrade", "downgraded", "lawsuit",
        "investigation", "probe", "recall", "weak", "loss",
        "losses", "bearish", "cut", "cuts", "warning",
        "fraud", "decline", "drop", "falls", "delay"
    ];

    let score = 0;
    let positiveMatches = [];
    let negativeMatches = [];

    positiveWords.forEach(function(word) {
        if (lowerText.includes(word)) {
            score += 1;
            positiveMatches.push(word);
        }
    });

    negativeWords.forEach(function(word) {
        if (lowerText.includes(word)) {
            score -= 1;
            negativeMatches.push(word);
        }
    });

    score = Math.max(-10, Math.min(score, 10));

    let label = "Neutral";
    let summary = "The outside research does not show a strong bullish or bearish bias.";

    if (score >= 3) {
        label = "Bullish";
        summary = "The outside research appears mostly positive and may support a stronger bullish trade setup.";
    } else if (score <= -3) {
        label = "Bearish";
        summary = "The outside research appears mostly negative and may support avoiding the trade or considering a bearish setup.";
    }

    return {
        score: score,
        label: label,
        positiveMatches: positiveMatches.slice(0, 8),
        negativeMatches: negativeMatches.slice(0, 8),
        summary: summary
    };
}

// ---- importWatchlistCSV() ----

async function importWatchlistCSV() {
    const fileInput = document.getElementById("watchlistCsvUpload");
    const status = document.getElementById("watchlistImportStatus");
    const table = document.getElementById("watchlistTable");

    if (!fileInput || !fileInput.files.length) {
        alert("Please select a CSV file first.");
        return;
    }

    if (!table) {
        alert("Watchlist table was not found.");
        return;
    }

    status.innerText = "Reading CSV file...";

    try {
        const file = fileInput.files[0];
        const text = await file.text();
        const lines = text.trim().split(/\r?\n/);

        if (lines.length < 2) {
            status.innerText = "The CSV file does not contain any ticker rows.";
            return;
        }

        const headers = parseWatchlistCSVLine(lines[0]).map(function(header) {
            return header
                .replace(/"/g, "")
                .trim()
                .toLowerCase();
        });

        let tickerIndex = headers.indexOf("ticker");

        if (tickerIndex === -1) {
            tickerIndex = headers.indexOf("symbol");
        }

        if (tickerIndex === -1) {
            status.innerText =
                'No "Ticker" or "Symbol" column was found in the CSV.';
            return;
        }

        const importedTickers = lines
            .slice(1)
            .map(function(line) {
                const columns = parseWatchlistCSVLine(line);

                if (columns.length <= tickerIndex) {
                    return "";
                }

                return columns[tickerIndex]
                    .replace(/"/g, "")
                    .trim()
                    .toUpperCase();
            })
            .filter(function(ticker) {
                return /^[A-Z][A-Z0-9.-]{0,9}$/.test(ticker);
            });

        const uniqueTickers = Array.from(new Set(importedTickers));

        if (uniqueTickers.length === 0) {
            status.innerText = "No valid ticker symbols were found.";
            return;
        }

        const existingTickers = getExistingWatchlistTickers();
        let addedCount = 0;

        for (let ticker of uniqueTickers) {
            if (existingTickers.includes(ticker)) {
                continue;
            }

            const row = table.insertRow(-1);

            row.innerHTML = `
                <td>${ticker}</td>
                <td class="watchlistPrice">Loading...</td>
                <td class="watchlistChange">Loading...</td>
                <td class="watchlistSignal">WATCH</td>
            `;

            existingTickers.push(ticker);
            addedCount++;
        }

        saveWatchlistToStorage();

        status.innerText =
            `${addedCount} ticker${addedCount === 1 ? "" : "s"} added to the watchlist.`;

        await updateWatchlistData();

    } catch (error) {
        console.error("Watchlist CSV import error:", error);
        status.innerText = "Unable to import the CSV file.";
    }
}

// ---- parseWatchlistCSVLine() ----

function parseWatchlistCSVLine(line) {
    const result = [];
    let current = "";
    let insideQuotes = false;

    for (let i = 0; i < line.length; i++) {
        const character = line[i];
        const nextCharacter = line[i + 1];

        if (
            character === '"' &&
            insideQuotes &&
            nextCharacter === '"'
        ) {
            current += '"';
            i++;
        } else if (character === '"') {
            insideQuotes = !insideQuotes;
        } else if (character === "," && !insideQuotes) {
            result.push(current.trim());
            current = "";
        } else {
            current += character;
        }
    }

    result.push(current.trim());
    return result;
}

// ---- getExistingWatchlistTickers() ----

function getExistingWatchlistTickers() {
    const table = document.getElementById("watchlistTable");

    if (!table) {
        return [];
    }

    return Array.from(table.rows)
        .slice(1)
        .map(function(row) {
            return row.cells[0]
                ? row.cells[0].innerText.trim().toUpperCase()
                : "";
        })
        .filter(function(ticker) {
            return ticker !== "";
        });
}

// ---- updateWatchlistData() ----

async function updateWatchlistData() {
    const table = document.getElementById("watchlistTable");

    if (!table) {
        return;
    }

    const rows = Array.from(table.rows).slice(1);
    const timeframe = "1d";

    for (let row of rows) {
        const ticker = row.cells[0].innerText.trim().toUpperCase();

        try {
            const data = await getFinvizChartData(ticker, timeframe);

            if (!data || data.length < 2) {
                row.cells[1].innerText = "No data";
                row.cells[2].innerText = "--";
                row.cells[3].innerText = "WATCH";
                continue;
            }

            const latest = data[data.length - 1];
            const previous = data[data.length - 2];

            const change = latest.close - previous.close;
            const changePercent = (change / previous.close) * 100;

            const recentPrices = data
                .slice(-60)
                .map(function(day) {
                    return day.close;
                });

            const sma20 = calculateSMA(recentPrices, 20);
            const rsi = calculateRSI(recentPrices, 14);
            const macd = calculateMACD(recentPrices);
            const momentum =
                latest.close - data[Math.max(0, data.length - 6)].close;

            const signalData = getTradeSignal(
                latest.close,
                sma20,
                rsi,
                macd,
                momentum,
                0
            );

            row.cells[1].innerText = `$${latest.close.toFixed(2)}`;
            row.cells[2].innerText =
                `${change >= 0 ? "+" : ""}${changePercent.toFixed(2)}%`;
            row.cells[3].innerText = signalData.signal;

            row.cells[2].className =
                change >= 0 ? "positive" : "negative";

        } catch (error) {
            console.error("Watchlist error for", ticker, error);

            row.cells[1].innerText = "Error";
            row.cells[2].innerText = "--";
            row.cells[3].innerText = "WATCH";
        }
    }

    saveWatchlistToStorage();
}

// ---- saveWatchlistToStorage() ----

function saveWatchlistToStorage() {
    const tickers = getExistingWatchlistTickers();

    localStorage.setItem(
        "traderAgentWatchlist",
        JSON.stringify(tickers)
    );
}

// ---- loadWatchlistFromStorage() ----

function loadWatchlistFromStorage() {
    const table = document.getElementById("watchlistTable");

    if (!table) {
        return;
    }

    const savedWatchlist = JSON.parse(
        localStorage.getItem("traderAgentWatchlist") || "[]"
    );

    if (!Array.isArray(savedWatchlist) || savedWatchlist.length === 0) {
        return;
    }

    while (table.rows.length > 1) {
        table.deleteRow(1);
    }

    savedWatchlist.forEach(function(ticker) {
        const row = table.insertRow(-1);

        row.innerHTML = `
            <td>${ticker}</td>
            <td>Loading...</td>
            <td>Loading...</td>
            <td>WATCH</td>
        `;
    });

    updateWatchlistData();
}

// ---- clearWatchlist() ----

function clearWatchlist() {
    const table = document.getElementById("watchlistTable");
    const status = document.getElementById("watchlistImportStatus");

    if (!table) {
        return;
    }

    while (table.rows.length > 1) {
        table.deleteRow(1);
    }

    localStorage.removeItem("traderAgentWatchlist");

    if (status) {
        status.innerText = "Watchlist cleared.";
    }
}
window.addEventListener("DOMContentLoaded", function() {
    restoreGenericPageState();
    attachGenericPageStateListeners();

    initializeBacktestPage();
    const restoredBacktest = restoreBacktestState();

    const stockChart = document.getElementById("stockChart");
    const restoredAnalysis = restoreAnalysisPageState();

    if (
        stockChart &&
        stockChart instanceof HTMLCanvasElement &&
        !restoredAnalysis
    ) {
        drawStockChart(
            "stockChart",
            [160, 165, 163, 170, 168, 174, 172, 176, 180, 184],
            [
                "06/01/2026",
                "06/02/2026",
                "06/03/2026",
                "06/04/2026",
                "06/05/2026",
                "06/08/2026",
                "06/09/2026",
                "06/10/2026",
                "06/11/2026",
                "06/12/2026"
            ],
            [null, null, null, null, null, null, null, null, null, 169]
        );
    }

    loadWatchlistFromStorage();

    if (restoredBacktest) {
        saveBacktestState();
    }
});