/*
 * server.js
 * TraderAgent backend API: serves the frontend, retrieves Finviz data/news, and supports scanner/research routes.
 * Keep configuration secrets in environment variables, not in this source file.
 */

require("dotenv").config();
const express = require("express");
const cors = require("cors");

const app = express();
app.use(cors());
app.use(express.json({ limit: "2mb" }));

// Serve the HTML, CSS, and browser JavaScript from this same Node process.
app.use(express.static(__dirname));

const FINVIZ_TOKEN = process.env.FINVIZ_TOKEN || "";

if (!FINVIZ_TOKEN) {
    console.warn(
        "FINVIZ_TOKEN is not set. Finviz routes will fail until you set it in your terminal."
    );
}

// ---- parseCSVLine() ----

function parseCSVLine(line) {
    const result = [];
    let current = "";
    let insideQuotes = false;

    for (let i = 0; i < line.length; i++) {
        const char = line[i];
        const nextChar = line[i + 1];

        if (char === '"' && insideQuotes && nextChar === '"') {
            current += '"';
            i++;
        } else if (char === '"') {
            insideQuotes = !insideQuotes;
        } else if (char === "," && !insideQuotes) {
            result.push(current.trim());
            current = "";
        } else {
            current += char;
        }
    }

    result.push(current.trim());
    return result;
}


// ---- normalizeCSVHeader() ----


function normalizeCSVHeader(value) {
    return String(value || "")
        .replace(/^\uFEFF/, "")
        .replace(/"/g, "")
        .trim()
        .toLowerCase()
        .replace(/[^a-z0-9]+/g, "");
}

// ---- parseOHLCVExport() ----

function parseOHLCVExport(csv) {
    if (!csv || !csv.trim()) {
        return [];
    }

    const rows = csv
        .replace(/^\uFEFF/, "")
        .trim()
        .split(/\r?\n/);

    if (rows.length < 2) {
        return [];
    }

    const headers = parseCSVLine(rows[0]).map(normalizeCSVHeader);

    // ---- indexOfAny() ----

    function indexOfAny(names) {
        for (const name of names) {
            const index = headers.indexOf(normalizeCSVHeader(name));
            if (index !== -1) return index;
        }
        return -1;
    }

    const dateIndex = indexOfAny(["date", "datetime", "time", "timestamp"]);
    const openIndex = indexOfAny(["open", "openprice"]);
    const highIndex = indexOfAny(["high", "highprice"]);
    const lowIndex = indexOfAny(["low", "lowprice"]);
    const closeIndex = indexOfAny(["close", "closeprice", "last", "price"]);
    const volumeIndex = indexOfAny(["volume", "vol"]);

    if ([dateIndex, openIndex, highIndex, lowIndex, closeIndex].includes(-1)) {
        console.error("Unexpected Finviz stock export headers:", headers);
        return [];
    }

    const data = rows.slice(1).map(function(rowText) {
        const parts = parseCSVLine(rowText);
        const item = {
            date: String(parts[dateIndex] || "").trim(),
            open: Number(String(parts[openIndex] || "").replace(/,/g, "")),
            high: Number(String(parts[highIndex] || "").replace(/,/g, "")),
            low: Number(String(parts[lowIndex] || "").replace(/,/g, "")),
            close: Number(String(parts[closeIndex] || "").replace(/,/g, "")),
            volume: volumeIndex === -1
                ? 0
                : Number(String(parts[volumeIndex] || "0").replace(/,/g, ""))
        };

        if (!Number.isFinite(item.volume)) item.volume = 0;
        return item;
    }).filter(function(item) {
        return (
            item.date &&
            Number.isFinite(item.open) &&
            Number.isFinite(item.high) &&
            Number.isFinite(item.low) &&
            Number.isFinite(item.close) &&
            item.high >= Math.max(item.open, item.close, item.low) &&
            item.low <= Math.min(item.open, item.close, item.high)
        );
    });

    console.log("Finviz OHLCV headers:", headers);
    console.log("Finviz OHLCV rows parsed:", data.length);
    if (data[0]) console.log("First OHLCV row:", data[0]);

    return data;
}

// ---- convertTimeframeToFinviz() ----

function convertTimeframeToFinviz(timeframe) {
    const map = {
        "1m": "i1",
        "3m": "i3",
        "5m": "i5",
        "15m": "i15",
        "30m": "i30",
        "1h": "h",
        "4h": "h4",
        "1d": "d",
        "1w": "w",
        "1mo": "m"
    };

    return map[timeframe] || "d";
}

// ---- getYahooChartConfig() ----

function getYahooChartConfig(timeframe) {
    const configurations = {
        "1m":  { interval: "1m",  range: "7d",  aggregateMinutes: 1 },
        "3m":  { interval: "1m",  range: "7d",  aggregateMinutes: 3 },
        "5m":  { interval: "5m",  range: "60d", aggregateMinutes: 5 },
        "15m": { interval: "15m", range: "60d", aggregateMinutes: 15 },
        "30m": { interval: "30m", range: "60d", aggregateMinutes: 30 },
        "1h":  { interval: "60m", range: "2y",  aggregateMinutes: 60 },
        "4h":  { interval: "60m", range: "2y",  aggregateMinutes: 240 },
        "1d":  { interval: "1d",  range: "10y", aggregateMinutes: 0 },
        "1w":  { interval: "1wk", range: "10y", aggregateMinutes: 0 },
        "1mo": { interval: "1mo", range: "max", aggregateMinutes: 0 }
    };

    return configurations[timeframe] || configurations["1d"];
}

// ---- normalizeYahooSymbol() ----

function normalizeYahooSymbol(ticker) {
    const symbol = String(ticker || "").trim().toUpperCase();
    const aliases = {
        "ES": "ES=F",
        "NQ": "NQ=F",
        "NDQ": "^NDX",
        "NASDAQ": "^IXIC",
        "NASDAQ100": "^NDX",
        "DOW": "^DJI",
        "SPX": "^GSPC",
        "S&P500": "^GSPC",
        "YM": "YM=F",
        "RTY": "RTY=F",
        "CL": "CL=F",
        "GC": "GC=F"
    };

    return aliases[symbol] || symbol;
}

// ---- resolveYahooSymbol() ----

async function resolveYahooSymbol(input) {
    const normalized = normalizeYahooSymbol(input);

    // A canonical symbol or a known alias can be tried immediately.
    if (normalized !== String(input || "").trim().toUpperCase()) {
        return normalized;
    }

    const query = encodeURIComponent(String(input || "").trim());
    const hosts = ["query1.finance.yahoo.com", "query2.finance.yahoo.com"];

    for (const host of hosts) {
        try {
            const response = await fetch(
                `https://${host}/v1/finance/search?q=${query}&quotesCount=10&newsCount=0`,
                {
                    redirect: "follow",
                    headers: {
                        "User-Agent": "Mozilla/5.0",
                        "Accept": "application/json,text/plain,*/*"
                    },
                    signal: AbortSignal.timeout(12000)
                }
            );

            if (!response.ok) continue;
            const payload = await response.json();
            const quotes = Array.isArray(payload && payload.quotes) ? payload.quotes : [];
            const allowedTypes = new Set(["EQUITY", "ETF", "INDEX", "FUTURE", "MUTUALFUND", "CRYPTOCURRENCY"]);
            const exact = quotes.find(function(item) {
                return String(item.symbol || "").toUpperCase() === normalized;
            });
            const best = exact || quotes.find(function(item) {
                return item.symbol && allowedTypes.has(String(item.quoteType || "").toUpperCase());
            });

            if (best && best.symbol) return String(best.symbol).toUpperCase();
        } catch (error) {
            console.warn("Yahoo symbol search failed:", error.message);
        }
    }

    return normalized;
}

// ---- aggregateMarketBars() ----

function aggregateMarketBars(bars, aggregateMinutes) {
    if (!Array.isArray(bars) || bars.length === 0 || aggregateMinutes <= 1) {
        return bars || [];
    }

    const bucketSeconds = aggregateMinutes * 60;
    const buckets = new Map();

    bars.forEach(function(bar) {
        const bucketTime = Math.floor(bar.timestamp / bucketSeconds) * bucketSeconds;
        const current = buckets.get(bucketTime);

        if (!current) {
            buckets.set(bucketTime, {
                timestamp: bucketTime,
                open: bar.open,
                high: bar.high,
                low: bar.low,
                close: bar.close,
                volume: bar.volume
            });
            return;
        }

        current.high = Math.max(current.high, bar.high);
        current.low = Math.min(current.low, bar.low);
        current.close = bar.close;
        current.volume += bar.volume;
    });

    return Array.from(buckets.values()).sort(function(a, b) {
        return a.timestamp - b.timestamp;
    });
}

// ---- formatMarketDate() ----

function formatMarketDate(timestamp, timeframe) {
    const date = new Date(timestamp * 1000);

    if (["1d", "1w", "1mo"].includes(timeframe)) {
        return new Intl.DateTimeFormat("en-US", {
            timeZone: "America/New_York",
            month: "2-digit",
            day: "2-digit",
            year: "numeric"
        }).format(date);
    }

    return new Intl.DateTimeFormat("en-US", {
        timeZone: "America/New_York",
        month: "2-digit",
        day: "2-digit",
        year: "numeric",
        hour: "2-digit",
        minute: "2-digit",
        hour12: true
    }).format(date).replace(",", "");
}

// ---- fetchYahooChartData() ----

async function fetchYahooChartData(ticker, timeframe, options) {
    options = options || {};

    const configuration = getYahooChartConfig(timeframe);
    const yahooSymbol = normalizeYahooSymbol(ticker);
    const parameters = new URLSearchParams({
        interval: configuration.interval,
        includePrePost: "false",
        events: "div,splits"
    });

    if (options.startDate instanceof Date && options.endDate instanceof Date) {
        parameters.set("period1", String(Math.floor(options.startDate.getTime() / 1000)));
        parameters.set("period2", String(Math.floor(options.endDate.getTime() / 1000) + 1));
    } else {
        parameters.set("range", configuration.range);
    }

    const hosts = ["query1.finance.yahoo.com", "query2.finance.yahoo.com"];
    let lastError = null;

    for (const host of hosts) {
        const url =
            `https://${host}/v8/finance/chart/${encodeURIComponent(yahooSymbol)}` +
            `?${parameters.toString()}`;

        try {
            const response = await fetch(url, {
                redirect: "follow",
                headers: {
                    "User-Agent": "Mozilla/5.0",
                    "Accept": "application/json,text/plain,*/*"
                },
                signal: AbortSignal.timeout(15000)
            });

            if (!response.ok) {
                lastError = new Error(`Market-data request failed with status ${response.status}.`);
                continue;
            }

            const payload = await response.json();
            const chart = payload && payload.chart;
            const result = chart && Array.isArray(chart.result) ? chart.result[0] : null;

            if (!result || !Array.isArray(result.timestamp)) {
                const message = chart && chart.error && chart.error.description
                    ? chart.error.description
                    : "No chart timestamps were returned.";
                lastError = new Error(message);
                continue;
            }

            const quote =
                result.indicators &&
                Array.isArray(result.indicators.quote)
                    ? result.indicators.quote[0]
                    : null;

            if (!quote) {
                lastError = new Error("No OHLCV quote data was returned.");
                continue;
            }

            let bars = result.timestamp.map(function(timestamp, index) {
                const open = Number(quote.open && quote.open[index]);
                const high = Number(quote.high && quote.high[index]);
                const low = Number(quote.low && quote.low[index]);
                const close = Number(quote.close && quote.close[index]);
                const volumeValue = Number(quote.volume && quote.volume[index]);

                return {
                    timestamp: Number(timestamp),
                    open: open,
                    high: high,
                    low: low,
                    close: close,
                    volume: Number.isFinite(volumeValue) ? volumeValue : 0
                };
            }).filter(function(bar) {
                return (
                    Number.isFinite(bar.timestamp) &&
                    Number.isFinite(bar.open) &&
                    Number.isFinite(bar.high) &&
                    Number.isFinite(bar.low) &&
                    Number.isFinite(bar.close) &&
                    bar.high >= Math.max(bar.open, bar.close, bar.low) &&
                    bar.low <= Math.min(bar.open, bar.close, bar.high)
                );
            }).sort(function(a, b) {
                return a.timestamp - b.timestamp;
            });

            if (configuration.aggregateMinutes > 1 &&
                configuration.aggregateMinutes !== Number(configuration.interval.replace(/\D/g, ""))) {
                bars = aggregateMarketBars(bars, configuration.aggregateMinutes);
            }

            const formatted = bars.map(function(bar) {
                return {
                    date: formatMarketDate(bar.timestamp, timeframe),
                    open: bar.open,
                    high: bar.high,
                    low: bar.low,
                    close: bar.close,
                    volume: bar.volume
                };
            });

            if (formatted.length > 0) {
                return formatted;
            }

            lastError = new Error("The market-data provider returned no valid candles.");
        } catch (error) {
            lastError = error;
        }
    }

    throw lastError || new Error("Unable to retrieve market data.");
}

app.get("/finviz", async function(req, res) {
    const requestedTicker = String(req.query.ticker || "MSFT").trim();
    const timeframe = String(req.query.timeframe || "1d").trim();

    if (!requestedTicker || requestedTicker.length > 50) {
        res.status(400).json({ data: [], error: "Enter a valid ticker or company name." });
        return;
    }

    let resolvedSymbol = normalizeYahooSymbol(requestedTicker);
    let firstError = null;

    try {
        const data = await fetchYahooChartData(resolvedSymbol, timeframe);
        res.set("Cache-Control", "no-store");
        res.json({
            data: data,
            requestedTicker: requestedTicker,
            resolvedSymbol: resolvedSymbol,
            timeframe: timeframe,
            provider: "Yahoo Finance"
        });
        return;
    } catch (error) {
        firstError = error;
    }

    try {
        const searchedSymbol = await resolveYahooSymbol(requestedTicker);
        if (searchedSymbol && searchedSymbol !== resolvedSymbol) {
            resolvedSymbol = searchedSymbol;
            const data = await fetchYahooChartData(resolvedSymbol, timeframe);
            res.set("Cache-Control", "no-store");
            res.json({
                data: data,
                requestedTicker: requestedTicker,
                resolvedSymbol: resolvedSymbol,
                timeframe: timeframe,
                provider: "Yahoo Finance",
                symbolWasResolved: true
            });
            return;
        }
    } catch (error) {
        console.error("Resolved-symbol chart request failed:", error);
        if (!firstError) firstError = error;
    }

    console.error("Stock chart data error:", firstError);
    res.status(404).json({
        data: [],
        requestedTicker: requestedTicker,
        resolvedSymbol: resolvedSymbol,
        error:
            `No chart data was found for “${requestedTicker}”. ` +
            `Try the exchange-listed symbol, such as AAPL, NDAQ, QQQ, ^NDX, NQ, or BTC-USD. ` +
            (firstError && firstError.message ? `Provider message: ${firstError.message}` : "")
    });
});

// ---- parseMarketDateTime() ----

function parseMarketDateTime(dateText) {
    if (!dateText) {
        return null;
    }

    const cleaned = String(dateText).trim();
    const direct = new Date(cleaned);

    if (!isNaN(direct.getTime())) {
        return direct;
    }

    const match = cleaned.match(
        /^(\d{1,2})\/(\d{1,2})\/(\d{2,4})(?:\s+(\d{1,2}):(\d{2})(?::(\d{2}))?\s*(AM|PM)?)?$/i
    );

    if (!match) {
        return null;
    }

    let year = Number(match[3]);
    let hour = Number(match[4] || 0);
    const minute = Number(match[5] || 0);
    const second = Number(match[6] || 0);
    const meridiem = String(match[7] || "").toUpperCase();

    if (year < 100) {
        year += 2000;
    }

    if (meridiem === "PM" && hour < 12) {
        hour += 12;
    }

    if (meridiem === "AM" && hour === 12) {
        hour = 0;
    }

    return new Date(
        year,
        Number(match[1]) - 1,
        Number(match[2]),
        hour,
        minute,
        second
    );
}

app.get("/backtest-data", async function(req, res) {
    const ticker = String(req.query.ticker || "MSFT").trim().toUpperCase();
    const timeframe = String(req.query.timeframe || "5m").trim();
    const startText = req.query.start;
    const endText = req.query.end;

    if (!startText || !endText) {
        res.status(400).json({
            data: [],
            error: "Start and end dates are required."
        });
        return;
    }

    const startDate = new Date(`${startText}T00:00:00`);
    const endDate = new Date(`${endText}T23:59:59.999`);

    if (isNaN(startDate.getTime()) || isNaN(endDate.getTime())) {
        res.status(400).json({
            data: [],
            error: "Invalid backtest date range."
        });
        return;
    }

    try {
        const data = await fetchYahooChartData(ticker, timeframe, {
            startDate: startDate,
            endDate: endDate
        });

        const filteredData = data.filter(function(item) {
            const marketDate = parseMarketDateTime(item.date);
            return marketDate && marketDate >= startDate && marketDate <= endDate;
        });

        res.set("Cache-Control", "no-store");
        res.json({
            ticker: ticker,
            timeframe: timeframe,
            start: startText,
            end: endText,
            sourceRows: data.length,
            data: filteredData,
            message: filteredData.length
                ? "Historical data loaded."
                : "No candles were available inside the selected date range. Intraday providers limit how far back minute data can be requested."
        });
    } catch (error) {
        console.error("Backtest data error:", error);
        res.status(502).json({
            ticker: ticker,
            timeframe: timeframe,
            data: [],
            error: error.message || "Error getting backtest chart data."
        });
    }
});

// ---- parseNewsDateTime() ----

function parseNewsDateTime(dateText) {
    if (!dateText) {
        return null;
    }

    const cleaned = String(dateText).trim();
    const now = new Date();

    if (/^today/i.test(cleaned)) {
        return applyNewsTime(now, cleaned.replace(/^today/i, "").trim());
    }

    if (/^yesterday/i.test(cleaned)) {
        const yesterday = new Date(now);
        yesterday.setDate(yesterday.getDate() - 1);
        return applyNewsTime(
            yesterday,
            cleaned.replace(/^yesterday/i, "").trim()
        );
    }

    const parsed = new Date(cleaned);

    if (!isNaN(parsed.getTime())) {
        return parsed;
    }

    const match = cleaned.match(
        /^(\d{1,2})\/(\d{1,2})\/(\d{2,4})(?:\s+(\d{1,2}):(\d{2})(?:\s*(AM|PM))?)?$/i
    );

    if (!match) {
        return null;
    }

    let year = Number(match[3]);
    let hour = Number(match[4] || 0);
    const minute = Number(match[5] || 0);
    const meridiem = (match[6] || "").toUpperCase();

    if (year < 100) {
        year += 2000;
    }

    if (meridiem === "PM" && hour < 12) {
        hour += 12;
    }

    if (meridiem === "AM" && hour === 12) {
        hour = 0;
    }

    return new Date(
        year,
        Number(match[1]) - 1,
        Number(match[2]),
        hour,
        minute
    );
}

// ---- applyNewsTime() ----

function applyNewsTime(baseDate, timeText) {
    const result = new Date(baseDate);

    if (!timeText) {
        result.setHours(0, 0, 0, 0);
        return result;
    }

    const match = timeText.match(
        /^(\d{1,2}):(\d{2})(?:\s*(AM|PM))?$/i
    );

    if (!match) {
        return null;
    }

    let hour = Number(match[1]);
    const minute = Number(match[2]);
    const meridiem = (match[3] || "").toUpperCase();

    if (meridiem === "PM" && hour < 12) {
        hour += 12;
    }

    if (meridiem === "AM" && hour === 12) {
        hour = 0;
    }

    result.setHours(hour, minute, 0, 0);
    return result;
}

// ---- isNewsWithinHours() ----

function isNewsWithinHours(dateText, maximumAgeHours) {
    const newsDate = parseNewsDateTime(dateText);

    if (!newsDate || isNaN(newsDate.getTime())) {
        return false;
    }

    const ageHours =
        (Date.now() - newsDate.getTime()) / (1000 * 60 * 60);

    return ageHours >= 0 && ageHours <= maximumAgeHours;
}

// ---- normalizeSymbols() ----

function normalizeSymbols(value) {
    return String(value || "")
        .toUpperCase()
        .split(/[\s,;|/]+/)
        .map(function(symbol) {
            return symbol.trim();
        })
        .filter(Boolean);
}

// ---- isTickerRelevantNews() ----

function isTickerRelevantNews(item, ticker) {
    const explicitSymbols = []
        .concat(normalizeSymbols(item.ticker))
        .concat(normalizeSymbols(item.tickers))
        .concat(normalizeSymbols(item.symbol))
        .concat(normalizeSymbols(item.symbols));

    if (explicitSymbols.length > 0) {
        return explicitSymbols.includes(ticker);
    }

    const searchableText =
        `${item.title || ""} ${item.url || ""}`.toUpperCase();

    const escapedTicker = ticker.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
    const tickerPattern = new RegExp(
        `(^|[^A-Z0-9])${escapedTicker}([^A-Z0-9]|$)`,
        "i"
    );

    // If the export does not identify a symbol and the headline does not
    // mention the requested ticker, reject it instead of applying broad
    // market news to an unrelated company.
    return tickerPattern.test(searchableText);
}

app.get("/finviz-news", async function(req, res) {
    const ticker = (req.query.ticker || "MSFT").toUpperCase();
    const requestedAge = Number(req.query.maxAgeHours);
    const maximumAgeHours =
        Number.isFinite(requestedAge)
            ? Math.max(1, Math.min(requestedAge, 168))
            : 48;

    const newsUrl =
        `https://elite.finviz.com/news_export?t=${encodeURIComponent(ticker)}&auth=${FINVIZ_TOKEN}`;

    try {
        const response = await fetch(newsUrl, {
            headers: {
                "User-Agent": "Mozilla/5.0"
            }
        });

        if (!response.ok) {
            res.status(response.status).json({
                ticker: ticker,
                news: [],
                error: `Finviz news request failed with status ${response.status}`
            });
            return;
        }

        const csv = await response.text();

        if (!csv || csv.trim() === "") {
            res.json({ ticker: ticker, news: [] });
            return;
        }

        if (
            csv.includes("<html") ||
            csv.includes("Gain Clarity") ||
            csv.includes("Sign In")
        ) {
            res.json({
                ticker: ticker,
                news: [],
                error: "Finviz returned a webpage instead of news CSV."
            });
            return;
        }

        const rows = csv.trim().split(/\r?\n/);

        if (rows.length < 2) {
            res.json({ ticker: ticker, news: [] });
            return;
        }

        const headers = parseCSVLine(rows[0]).map(function(header) {
            return header.replace(/"/g, "").trim().toLowerCase();
        });

        const news = rows
            .slice(1)
            .map(function(row) {
                const parts = parseCSVLine(row);
                const item = {};

                headers.forEach(function(header, index) {
                    item[header] = parts[index] || "";
                });

                return {
                    date:
                        item.date ||
                        item.datetime ||
                        item.time ||
                        item.published ||
                        "",
                    title:
                        item.title ||
                        item.headline ||
                        item.news ||
                        "",
                    source:
                        item.source ||
                        item.publisher ||
                        "Finviz",
                    url:
                        item.url ||
                        item.link ||
                        "",
                    ticker:
                        item.ticker ||
                        "",
                    tickers:
                        item.tickers ||
                        "",
                    symbol:
                        item.symbol ||
                        "",
                    symbols:
                        item.symbols ||
                        ""
                };
            })
            .filter(function(item) {
                return item.title !== "";
            })
            .filter(function(item) {
                return isTickerRelevantNews(item, ticker);
            })
            .filter(function(item) {
                return isNewsWithinHours(item.date, maximumAgeHours);
            })
            .sort(function(a, b) {
                const aDate = parseNewsDateTime(a.date);
                const bDate = parseNewsDateTime(b.date);

                return bDate.getTime() - aDate.getTime();
            })
            .slice(0, 10)
            .map(function(item) {
                return {
                    date: item.date,
                    title: item.title,
                    source: item.source,
                    url: item.url
                };
            });

        res.set("Cache-Control", "no-store");

        res.json({
            ticker: ticker,
            maximumAgeHours: maximumAgeHours,
            news: news
        });

    } catch (error) {
        console.error("Finviz news error:", error);

        res.status(500).json({
            ticker: ticker,
            news: [],
            error: "Error getting company-specific Finviz news"
        });
    }
});


// ---- normalizeHeaderName() ----


function normalizeHeaderName(value) {
    return String(value || "")
        .replace(/^\uFEFF/, "")
        .replace(/"/g, "")
        .trim()
        .toLowerCase()
        .replace(/[^a-z0-9]+/g, "");
}

// ---- parseNumberValue() ----

function parseNumberValue(value) {
    const text = String(value == null ? "" : value)
        .trim()
        .replace(/\$/g, "")
        .replace(/,/g, "");

    if (!text || text === "-" || text === "N/A") {
        return null;
    }

    const multiplier =
        /T$/i.test(text) ? 1e12 :
        /B$/i.test(text) ? 1e9 :
        /M$/i.test(text) ? 1e6 :
        /K$/i.test(text) ? 1e3 :
        1;

    const number = Number(text.replace(/[TBMK%]$/i, ""));
    return Number.isFinite(number) ? number * multiplier : null;
}

// ---- parsePercentValue() ----

function parsePercentValue(value) {
    const parsed = parseNumberValue(value);
    return Number.isFinite(parsed) ? parsed : null;
}

// ---- getField() ----

function getField(row, names) {
    for (const name of names) {
        const normalized = normalizeHeaderName(name);

        if (Object.prototype.hasOwnProperty.call(row, normalized)) {
            const value = row[normalized];

            if (value !== "" && value != null) {
                return value;
            }
        }
    }

    return "";
}

// ---- parseScreenerCSV() ----

function parseScreenerCSV(csv) {
    if (!csv || !csv.trim()) {
        return [];
    }

    const rows = csv
        .replace(/^\uFEFF/, "")
        .trim()
        .split(/\r?\n/);

    if (rows.length < 2) {
        return [];
    }

    const headers = parseCSVLine(rows[0]).map(function(header) {
        return String(header)
            .replace(/"/g, "")
            .trim()
            .toLowerCase()
            .replace(/[^a-z0-9]+/g, "");
    });

    const parsedRows = rows
        .slice(1)
        .map(function(line) {
            const values = parseCSVLine(line);
            const item = {};

            headers.forEach(function(header, index) {
                item[header] = values[index] || "";
            });

            return item;
        })
        .filter(function(item) {
            return item.ticker && item.ticker.trim() !== "";
        });

    console.log("SCREENER HEADERS:", headers);
    console.log("SCREENER ROW COUNT:", parsedRows.length);
    console.log("FIRST SCREENER ROW:", parsedRows[0]);

    return parsedRows;
}

// ---- fetchFinvizScreenerView() ----

async function fetchFinvizScreenerView(view) {
    const filters = "sh_price_o5,sh_avgvol_o500";

    const url =
        `https://elite.finviz.com/export/screener` +
        `?v=${encodeURIComponent(view)}` +
        `&f=${encodeURIComponent(filters)}` +
        `&o=-relativevolume` +
        `&auth=${encodeURIComponent(FINVIZ_TOKEN)}`;

    const response = await fetch(url, {
        
        redirect: "follow",
        headers: {
            "User-Agent": "Mozilla/5.0",
            "Accept": "text/csv,text/plain,*/*"
        }
        
    });

    const text = await response.text();
    console.log("STATUS:", response.status);
    console.log("URL:", url);
    console.log("RESPONSE:");
    console.log(text.substring(0, 1000));

    if (!response.ok) {
        throw new Error(
            `Finviz screener view ${view} returned status ${response.status}.`
        );
    }

    return parseScreenerCSV(text);
}

// ---- mergeScreenerRows() ----

function mergeScreenerRows(primaryRows, secondaryRows) {
    const merged = new Map();

    [primaryRows, secondaryRows].forEach(function(rows) {
        rows.forEach(function(row) {
            const ticker = String(
                getField(row, ["ticker", "symbol"])
            ).toUpperCase();

            if (!ticker) return;

            merged.set(ticker, Object.assign({}, merged.get(ticker) || {}, row));
        });
    });

    return Array.from(merged.entries()).map(function(entry) {
        return Object.assign({ ticker: entry[0] }, entry[1]);
    });
}

// ---- getEasternMarketMode() ----

function getEasternMarketMode(date) {
    const parts = new Intl.DateTimeFormat("en-US", {
        timeZone: "America/New_York",
        weekday: "short",
        hour: "2-digit",
        minute: "2-digit",
        hour12: false
    }).formatToParts(date);

    const values = {};

    parts.forEach(function(part) {
        values[part.type] = part.value;
    });

    const weekday = values.weekday;
    const minutes = Number(values.hour) * 60 + Number(values.minute);
    const isWeekend = weekday === "Sat" || weekday === "Sun";

    if (weekday === "Sun" && minutes >= 18 * 60) {
        return {
            mode: "sunday_outlook",
            label: "Monday Outlook",
            marketOpen: false
        };
    }

    if (isWeekend) {
        return {
            mode: "next_session",
            label: "Next-Session Forecast",
            marketOpen: false
        };
    }

    if (minutes < 4 * 60) {
        return {
            mode: "overnight_forecast",
            label: "Overnight Forecast",
            marketOpen: false
        };
    }

    if (minutes < 9 * 60 + 30) {
        return {
            mode: "premarket",
            label: "Premarket Ranking",
            marketOpen: false
        };
    }

    if (minutes < 16 * 60) {
        return {
            mode: "live",
            label: "Live Market Ranking",
            marketOpen: true
        };
    }

    if (minutes < 20 * 60) {
        return {
            mode: "after_hours",
            label: "After-Hours Review",
            marketOpen: false
        };
    }

    return {
        mode: "next_session",
        label: "Next-Session Forecast",
        marketOpen: false
    };
}

// ---- scoreComponent() ----

function scoreComponent(available, points, conditionScore, label, reasons, coverage) {
    if (!available) {
        return { points: 0, coverage: coverage };
    }

    const earned = Math.max(0, Math.min(points, conditionScore));
    coverage.available += points;

    if (earned >= points * 0.65 && label) {
        reasons.push(label);
    }

    return {
        points: earned,
        coverage: coverage
    };
}

// ---- calculateMarketOpportunity() ----

function calculateMarketOpportunity(row, marketMode, newsSummary) {
    const price = parseNumberValue(getField(row, ["price"]));
    const change = parsePercentValue(getField(row, ["change", "changepercent"]));
    const gap = parsePercentValue(getField(row, ["gap"]));
    const fromOpen = parsePercentValue(
        getField(row, ["changefromopen", "fromopen", "changeopen"])
    );
    const relativeVolume = parseNumberValue(
        getField(row, ["relativevolume", "relvolume", "relvol"])
    );
    const volume = parseNumberValue(getField(row, ["volume"]));
    const averageVolume = parseNumberValue(
        getField(row, ["averagevolume", "avgvolume"])
    );
    const rsi = parseNumberValue(getField(row, ["rsi", "rsi14"]));
    const sma20 = parsePercentValue(getField(row, ["sma20"]));
    const sma50 = parsePercentValue(getField(row, ["sma50"]));
    const sma200 = parsePercentValue(getField(row, ["sma200"]));
    const atr = parseNumberValue(getField(row, ["atr"]));
    const high52 = parsePercentValue(
        getField(row, ["52weekhigh", "52whigh"])
    );

    const reasons = [];
    const coverage = { available: 0 };
    let score = 35;

    const changeWeight =
        marketMode.mode === "premarket" ? 15 :
        marketMode.mode === "live" ? 12 :
        10;

    let component = scoreComponent(
        Number.isFinite(change),
        changeWeight,
        Number.isFinite(change)
            ? change >= 5 ? changeWeight :
              change >= 2 ? changeWeight * 0.9 :
              change > 0 ? changeWeight * 0.65 :
              change > -1 ? changeWeight * 0.3 : 0
            : 0,
        Number.isFinite(change) && change > 0
            ? `Positive price momentum (${change.toFixed(2)}%)`
            : "",
        reasons,
        coverage
    );
    score += component.points;

    component = scoreComponent(
        Number.isFinite(relativeVolume),
        15,
        Number.isFinite(relativeVolume)
            ? relativeVolume >= 3 ? 15 :
              relativeVolume >= 2 ? 13 :
              relativeVolume >= 1.5 ? 10 :
              relativeVolume >= 1 ? 6 : 2
            : 0,
        Number.isFinite(relativeVolume) && relativeVolume >= 1.5
            ? `Elevated relative volume (${relativeVolume.toFixed(2)}x)`
            : "",
        reasons,
        coverage
    );
    score += component.points;

    component = scoreComponent(
        Number.isFinite(fromOpen),
        10,
        Number.isFinite(fromOpen)
            ? fromOpen >= 2 ? 10 :
              fromOpen > 0 ? 7 :
              fromOpen > -0.5 ? 3 : 0
            : 0,
        Number.isFinite(fromOpen) && fromOpen > 0
            ? "Holding above the session open"
            : "",
        reasons,
        coverage
    );
    score += component.points;

    component = scoreComponent(
        Number.isFinite(gap),
        8,
        Number.isFinite(gap)
            ? gap >= 1 && gap <= 8 ? 8 :
              gap > 0 ? 5 :
              gap > -1 ? 2 : 0
            : 0,
        Number.isFinite(gap) && gap > 0
            ? `Positive gap (${gap.toFixed(2)}%)`
            : "",
        reasons,
        coverage
    );
    score += component.points;

    component = scoreComponent(
        Number.isFinite(sma20),
        8,
        Number.isFinite(sma20)
            ? sma20 >= 3 ? 8 :
              sma20 > 0 ? 6 :
              sma20 > -2 ? 3 : 0
            : 0,
        Number.isFinite(sma20) && sma20 > 0
            ? "Price above SMA20"
            : "",
        reasons,
        coverage
    );
    score += component.points;

    component = scoreComponent(
        Number.isFinite(sma50),
        6,
        Number.isFinite(sma50)
            ? sma50 > 0 ? 6 :
              sma50 > -3 ? 2 : 0
            : 0,
        Number.isFinite(sma50) && sma50 > 0
            ? "Price above SMA50"
            : "",
        reasons,
        coverage
    );
    score += component.points;

    component = scoreComponent(
        Number.isFinite(sma200),
        4,
        Number.isFinite(sma200) && sma200 > 0 ? 4 : 0,
        Number.isFinite(sma200) && sma200 > 0
            ? "Long-term trend is positive"
            : "",
        reasons,
        coverage
    );
    score += component.points;

    component = scoreComponent(
        Number.isFinite(rsi),
        8,
        Number.isFinite(rsi)
            ? rsi >= 52 && rsi <= 68 ? 8 :
              rsi >= 45 && rsi < 75 ? 5 :
              rsi >= 35 && rsi < 80 ? 2 : 0
            : 0,
        Number.isFinite(rsi) && rsi >= 52 && rsi <= 68
            ? `Constructive RSI (${rsi.toFixed(1)})`
            : "",
        reasons,
        coverage
    );
    score += component.points;

    const volumeRatio =
        Number.isFinite(volume) &&
        Number.isFinite(averageVolume) &&
        averageVolume > 0
            ? volume / averageVolume
            : null;

    component = scoreComponent(
        Number.isFinite(volumeRatio),
        5,
        Number.isFinite(volumeRatio)
            ? volumeRatio >= 1.5 ? 5 :
              volumeRatio >= 1 ? 3 : 1
            : 0,
        Number.isFinite(volumeRatio) && volumeRatio >= 1
            ? "Volume is running above average"
            : "",
        reasons,
        coverage
    );
    score += component.points;

    component = scoreComponent(
        Number.isFinite(atr) && Number.isFinite(price) && price > 0,
        4,
        Number.isFinite(atr) && Number.isFinite(price) && price > 0
            ? Math.max(0, Math.min(4, (atr / price) * 100 * 1.4))
            : 0,
        "",
        reasons,
        coverage
    );
    score += component.points;

    component = scoreComponent(
        Number.isFinite(high52),
        4,
        Number.isFinite(high52)
            ? high52 >= -5 ? 4 :
              high52 >= -15 ? 2 : 0
            : 0,
        Number.isFinite(high52) && high52 >= -5
            ? "Trading near its 52-week high"
            : "",
        reasons,
        coverage
    );
    score += component.points;

    const newsAvailable = Boolean(newsSummary && newsSummary.available);
    component = scoreComponent(
        newsAvailable,
        10,
        newsAvailable
            ? newsSummary.sentiment === "positive" ? 10 :
              newsSummary.sentiment === "neutral" ? 5 : 0
            : 0,
        newsAvailable && newsSummary.sentiment === "positive"
            ? "Recent positive company catalyst"
            : "",
        reasons,
        coverage
    );
    score += component.points;

    const totalWeightedData = 92;
    const dataCoverage = Math.min(
        100,
        Math.round((coverage.available / totalWeightedData) * 100)
    );

    // Reduce the displayed opportunity score when important data is missing.
    const coverageAdjustment = 0.55 + (dataCoverage / 100) * 0.45;
    score = Math.max(0, Math.min(100, score * coverageAdjustment));

    const direction =
        score >= 62 && (!Number.isFinite(change) || change > -1)
            ? "Bullish"
            : score < 45
                ? "Bearish"
                : "Neutral";

    const confirmation =
        marketMode.mode === "live"
            ? "Require price and volume confirmation before entry."
            : "Recalculate after active trading begins and require opening confirmation.";

    return {
        ticker: String(getField(row, ["ticker", "symbol"]) || row.ticker).toUpperCase(),
        company: getField(row, ["company"]),
        sector: getField(row, ["sector"]),
        price: price,
        changePercent: change,
        relativeVolume: relativeVolume,
        rsi: rsi,
        score: Number(score.toFixed(1)),
        dataCoverage: dataCoverage,
        direction: direction,
        setup:
            direction === "Bullish"
                ? "Bullish continuation candidate"
                : direction === "Bearish"
                    ? "Weak setup"
                    : "Watch for confirmation",
        reasons: reasons,
        confirmation: confirmation,
        news: newsSummary && newsSummary.headlines
            ? newsSummary.headlines
            : []
    };
}

// ---- classifyHeadlineSentiment() ----

function classifyHeadlineSentiment(title) {
    const text = String(title || "").toLowerCase();

    const positiveWords = [
        "beats", "beat estimates", "raises guidance", "upgrade", "upgraded",
        "approval", "approved", "record revenue", "partnership", "contract",
        "expands", "growth", "surge", "strong demand", "buyback"
    ];

    const negativeWords = [
        "misses", "cuts guidance", "downgrade", "downgraded", "lawsuit",
        "investigation", "recall", "decline", "layoffs", "offering",
        "bankruptcy", "warning", "fraud"
    ];

    let score = 0;

    positiveWords.forEach(function(word) {
        if (text.includes(word)) score += 1;
    });

    negativeWords.forEach(function(word) {
        if (text.includes(word)) score -= 1;
    });

    return score;
}


const MACRO_NEWS_CACHE_MS = 10 * 60 * 1000;
let macroNewsCache = { fetchedAt: 0, value: null };

const MACRO_NEWS_SOURCES = [
    {
        name: "Federal Reserve",
        type: "rss",
        url: "https://www.federalreserve.gov/feeds/press_all.xml"
    },
    {
        name: "Federal Reserve Monetary Policy",
        type: "rss",
        url: "https://www.federalreserve.gov/feeds/press_monetary.xml"
    },
    {
        name: "U.S. Bureau of Labor Statistics",
        type: "rss",
        url: "https://www.bls.gov/feed/bls_latest.rss"
    },
    {
        name: "White House",
        type: "html",
        url: "https://www.whitehouse.gov/briefings-statements/"
    }
];

const TICKER_EXPOSURE = {
    semiconductors: ["NVDA", "AMD", "AVGO", "MU", "ARM", "QCOM", "AMAT", "LRCX", "TSM", "SMCI", "DELL"],
    technology: ["AAPL", "MSFT", "AMZN", "META", "GOOGL", "CRM", "ORCL", "ADBE", "NOW", "INTU", "SNOW", "CRWD", "PANW", "PLTR"],
    financials: ["JPM", "BAC", "GS", "MS", "V", "MA", "SOFI", "HOOD"],
    energy: ["XOM", "CVX", "OXY"],
    healthcare: ["LLY", "UNH", "MRK", "NVO"],
    autos: ["TSLA", "F", "GM"],
    industrials: ["CAT", "GE", "BA", "UBER"],
    consumer: ["WMT", "COST", "NKE", "DIS", "NFLX", "SHOP"],
    crypto: ["COIN", "HOOD", "SOFI"],
    defense: ["BA", "PLTR", "GE"]
};

// ---- decodeXmlEntities() ----

function decodeXmlEntities(value) {
    return String(value || "")
        .replace(/<!\[CDATA\[([\s\S]*?)\]\]>/g, "$1")
        .replace(/&amp;/g, "&")
        .replace(/&quot;/g, '"')
        .replace(/&#39;|&apos;/g, "'")
        .replace(/&lt;/g, "<")
        .replace(/&gt;/g, ">");
}

// ---- stripHtml() ----

function stripHtml(value) {
    return decodeXmlEntities(String(value || "").replace(/<[^>]+>/g, " "))
        .replace(/\s+/g, " ")
        .trim();
}

// ---- fetchTextWithTimeout() ----

async function fetchTextWithTimeout(url, timeoutMs) {
    const controller = new AbortController();
    const timer = setTimeout(function() { controller.abort(); }, timeoutMs || 8000);
    try {
        const response = await fetch(url, {
            signal: controller.signal,
            redirect: "follow",
            headers: { "User-Agent": "Mozilla/5.0 TraderAgent/1.0" }
        });
        if (!response.ok) throw new Error(`${response.status} ${response.statusText}`);
        return await response.text();
    } finally {
        clearTimeout(timer);
    }
}

// ---- parseRssItems() ----

function parseRssItems(xml, sourceName) {
    const blocks = String(xml || "").match(/<item\b[\s\S]*?<\/item>/gi) || [];
    return blocks.slice(0, 12).map(function(block) {
        // ---- field() ----
        function field(tag) {
            const match = block.match(new RegExp(`<${tag}[^>]*>([\\s\\S]*?)<\\/${tag}>`, "i"));
            return match ? stripHtml(match[1]) : "";
        }
        return {
            title: field("title"),
            date: field("pubDate") || field("dc:date"),
            source: sourceName,
            url: field("link")
        };
    }).filter(function(item) { return item.title; });
}

// ---- parseWhiteHouseItems() ----

function parseWhiteHouseItems(html) {
    const items = [];
    const anchorRegex = /<a[^>]+href="([^"]+)"[^>]*>([\s\S]*?)<\/a>/gi;
    let match;
    while ((match = anchorRegex.exec(String(html || ""))) && items.length < 15) {
        const title = stripHtml(match[2]);
        const url = match[1];
        if (
            title.length >= 18 &&
            /whitehouse\.gov\/(briefings-statements|presidential-actions|remarks)/i.test(url) &&
            !/^(next|previous|read more|briefings|statements)$/i.test(title)
        ) {
            items.push({ title: title, date: "", source: "White House", url: url });
        }
    }
    return items;
}

// ---- macroTagsForHeadline() ----

function macroTagsForHeadline(title) {
    const text = String(title || "").toLowerCase();
    const tags = ["broad"];
    const add = function(tag, words) {
        if (words.some(function(word) { return text.includes(word); })) tags.push(tag);
    };
    add("semiconductors", ["chip", "semiconductor", "ai export", "advanced computing"]);
    add("technology", ["technology", "artificial intelligence", "cyber", "cloud", "digital"]);
    add("financials", ["bank", "credit", "capital requirement", "interest rate", "treasury yield"]);
    add("energy", ["oil", "gas", "energy", "drilling", "opec"]);
    add("healthcare", ["drug", "medicare", "medicaid", "healthcare", "pharma", "fda"]);
    add("autos", ["vehicle", "automobile", "ev", "electric vehicle", "auto tariff"]);
    add("industrials", ["infrastructure", "aviation", "aircraft", "manufacturing", "construction"]);
    add("consumer", ["consumer", "retail", "wage", "employment", "inflation", "cpi"]);
    add("crypto", ["crypto", "bitcoin", "digital asset", "stablecoin"]);
    add("defense", ["defense", "pentagon", "military", "weapons", "national security"]);
    return Array.from(new Set(tags));
}

// ---- classifyMacroTone() ----

function classifyMacroTone(title) {
    const text = String(title || "").toLowerCase();
    const positive = [
        "rate cut", "cuts rates", "lower inflation", "inflation falls", "jobs rise",
        "employment increases", "trade agreement", "contract awarded", "investment",
        "tax cut", "deregulation", "approval", "ceasefire"
    ];
    const negative = [
        "rate hike", "raises rates", "inflation rises", "higher inflation", "jobs fall",
        "tariff", "sanction", "export restriction", "ban", "war", "attack",
        "shutdown", "recession", "investigation", "enforcement action"
    ];
    let score = 0;
    positive.forEach(function(word) { if (text.includes(word)) score += 1; });
    negative.forEach(function(word) { if (text.includes(word)) score -= 1; });
    return clamp(score, -2, 2);
}

// ---- isRecentMacroItem() ----

function isRecentMacroItem(item, hours) {
    if (!item.date) return true;
    const timestamp = Date.parse(item.date);
    if (!Number.isFinite(timestamp)) return true;
    return Date.now() - timestamp <= hours * 60 * 60 * 1000;
}

// ---- fetchMacroMarketContext() ----

async function fetchMacroMarketContext() {
    if (macroNewsCache.value && Date.now() - macroNewsCache.fetchedAt < MACRO_NEWS_CACHE_MS) {
        return macroNewsCache.value;
    }

    const settled = await Promise.allSettled(MACRO_NEWS_SOURCES.map(async function(source) {
        const text = await fetchTextWithTimeout(source.url, 8000);
        return source.type === "rss"
            ? parseRssItems(text, source.name)
            : parseWhiteHouseItems(text);
    }));

    const items = settled.flatMap(function(result) {
        return result.status === "fulfilled" ? result.value : [];
    }).filter(function(item) {
        return item.title && isRecentMacroItem(item, 96);
    });

    const seen = new Set();
    const headlines = items.filter(function(item) {
        const key = item.title.toLowerCase();
        if (seen.has(key)) return false;
        seen.add(key);
        return true;
    }).slice(0, 24).map(function(item) {
        return Object.assign({}, item, {
            tone: classifyMacroTone(item.title),
            tags: macroTagsForHeadline(item.title)
        });
    });

    const toneScore = headlines.reduce(function(total, item) { return total + item.tone; }, 0);
    const value = {
        available: headlines.length > 0,
        sentiment: toneScore > 1 ? "positive" : toneScore < -1 ? "negative" : "mixed",
        toneScore: toneScore,
        headlines: headlines,
        sources: Array.from(new Set(headlines.map(function(item) { return item.source; })))
    };
    macroNewsCache = { fetchedAt: Date.now(), value: value };
    return value;
}

// ---- macroImpactForTicker() ----

function macroImpactForTicker(ticker, macroContext) {
    if (!macroContext || !macroContext.available) {
        return { score: 0, sentiment: "unknown", headlines: [], matchedTags: [] };
    }
    const exposureTags = Object.keys(TICKER_EXPOSURE).filter(function(tag) {
        return TICKER_EXPOSURE[tag].includes(ticker);
    });
    let score = 0;
    const matches = [];
    macroContext.headlines.forEach(function(item) {
        const sectorMatch = item.tags.some(function(tag) { return exposureTags.includes(tag); });
        const broadOnly = item.tags.length === 1 && item.tags[0] === "broad";
        if (sectorMatch || broadOnly) {
            score += item.tone * (sectorMatch ? 1.5 : 0.5);
            matches.push(item);
        }
    });
    score = clamp(score, -8, 8);
    return {
        score: score,
        sentiment: score > 1 ? "positive" : score < -1 ? "negative" : "mixed",
        headlines: matches.slice(0, 5),
        matchedTags: exposureTags
    };
}

// ---- fetchScannerNews() ----

async function fetchScannerNews(ticker) {
    const newsUrl =
        `https://elite.finviz.com/news_export?t=${encodeURIComponent(ticker)}` +
        `&auth=${encodeURIComponent(FINVIZ_TOKEN)}`;

    try {
        const response = await fetch(newsUrl, {
            redirect: "follow",
            headers: {
                "User-Agent": "Mozilla/5.0"
            }
        });

        if (!response.ok) {
            return { available: false, sentiment: "unknown", headlines: [] };
        }

        const csv = await response.text();
        const rows = csv.trim().split(/\r?\n/);

        if (
            rows.length < 2 ||
            csv.includes("<html") ||
            csv.includes("Sign In")
        ) {
            return { available: false, sentiment: "unknown", headlines: [] };
        }

        const headers = parseCSVLine(rows[0]).map(normalizeHeaderName);
        const headlines = rows.slice(1).map(function(line) {
            const parts = parseCSVLine(line);
            const row = {};

            headers.forEach(function(header, index) {
                row[header] = parts[index] || "";
            });

            return {
                date: getField(row, ["date", "datetime", "time", "published"]),
                title: getField(row, ["title", "headline", "news"]),
                source: getField(row, ["source", "publisher"]) || "Finviz"
            };
        }).filter(function(item) {
            return item.title && isNewsWithinHours(item.date, 48);
        }).slice(0, 5);

        if (!headlines.length) {
            return { available: false, sentiment: "unknown", headlines: [] };
        }

        const sentimentScore = headlines.reduce(function(total, item) {
            return total + classifyHeadlineSentiment(item.title);
        }, 0);

        return {
            available: true,
            sentiment:
                sentimentScore > 0 ? "positive" :
                sentimentScore < 0 ? "negative" :
                "neutral",
            headlines: headlines
        };
    } catch (error) {
        return { available: false, sentiment: "unknown", headlines: [] };
    }
}



const MARKET_CAP_RULES = [
    { category: "Nano", maximum: 50_000_000, minimumRelativeVolume: 2.0 },
    { category: "Micro", maximum: 300_000_000, minimumRelativeVolume: 2.0 },
    { category: "Small", maximum: 2_000_000_000, minimumRelativeVolume: 1.0 },
    { category: "Mid", maximum: 10_000_000_000, minimumRelativeVolume: 1.0 },
    { category: "Large", maximum: 200_000_000_000, minimumRelativeVolume: 0.75 },
    { category: "Mega", maximum: Infinity, minimumRelativeVolume: 0.75 }
];

const DEFAULT_LIQUIDITY_FILTERS = {
    enabledCaps: ["Nano", "Micro", "Small", "Mid", "Large", "Mega"],
    relativeVolume: {
        Nano: 2.0,
        Micro: 2.0,
        Small: 1.0,
        Mid: 1.0,
        Large: 0.75,
        Mega: 0.75
    },
    minimumCurrentVolume: 100000
};

// ---- getScannerLiquidityFilters() ----

function getScannerLiquidityFilters(query) {
    const allowedCaps = MARKET_CAP_RULES.map(function(rule) { return rule.category; });
    const requestedCaps = String(query.enabledCaps || allowedCaps.join(","))
        .split(",")
        .map(function(value) { return value.trim(); })
        .filter(function(value) { return allowedCaps.includes(value); });

    const enabledCaps = requestedCaps.length ? requestedCaps : allowedCaps.slice();
    const relativeVolume = {};

    allowedCaps.forEach(function(category) {
        const key = `rvol${category}`;
        const fallback = DEFAULT_LIQUIDITY_FILTERS.relativeVolume[category];
        const requested = Number(query[key]);
        relativeVolume[category] = Number.isFinite(requested)
            ? clamp(requested, 0, 20)
            : fallback;
    });

    const requestedMinimumVolume = Number(query.minimumCurrentVolume);

    return {
        enabledCaps: enabledCaps,
        relativeVolume: relativeVolume,
        minimumCurrentVolume: Number.isFinite(requestedMinimumVolume)
            ? Math.max(0, Math.round(requestedMinimumVolume))
            : DEFAULT_LIQUIDITY_FILTERS.minimumCurrentVolume
    };
}

// ---- classifyMarketCap() ----

function classifyMarketCap(marketCap) {
    const value = Number(marketCap);
    if (!Number.isFinite(value) || value <= 0) {
        return { category: "Unknown", minimumRelativeVolume: 1.0 };
    }
    return MARKET_CAP_RULES.find(function(rule) {
        return value < rule.maximum;
    }) || MARKET_CAP_RULES[MARKET_CAP_RULES.length - 1];
}

// ---- formatMarketCapValue() ----

function formatMarketCapValue(marketCap) {
    const value = Number(marketCap);
    if (!Number.isFinite(value) || value <= 0) return null;
    if (value >= 1_000_000_000_000) return `${(value / 1_000_000_000_000).toFixed(2)}T`;
    if (value >= 1_000_000_000) return `${(value / 1_000_000_000).toFixed(2)}B`;
    return `${(value / 1_000_000).toFixed(1)}M`;
}

// ---- parseFinvizMarketCapMillions() ----

function parseFinvizMarketCapMillions(value) {
    const text = String(value == null ? "" : value)
        .replace(/[$,\s]/g, "")
        .trim()
        .toUpperCase();

    if (!text || text === "-" || text === "N/A") {
        return null;
    }

    // Finviz may return values such as 39.08B, 402.90M, 1.25T,
    // or a plain number representing millions of dollars.
    const match = text.match(/^(-?\d+(?:\.\d+)?)([KMBT])?$/);

    if (!match) {
        console.warn("Unable to parse Finviz market cap:", value);
        return null;
    }

    const number = Number(match[1]);
    if (!Number.isFinite(number) || number <= 0) return null;

    const suffix = match[2] || "";
    const multipliers = {
        K: 1_000,
        M: 1_000_000,
        B: 1_000_000_000,
        T: 1_000_000_000_000
    };

    // A suffix gives the unit explicitly. A plain Finviz export value is
    // interpreted as millions, matching the legacy export format.
    return suffix
        ? number * multipliers[suffix]
        : number * 1_000_000;
}

// ---- fetchFinvizQuoteMetadata() ----

async function fetchFinvizQuoteMetadata() {
    const output = new Map();

    try {
        const rows = await fetchFinvizScreenerView("111");

        rows.forEach(function(row) {
            const ticker = String(getField(row, ["ticker", "symbol"]) || "")
                .trim()
                .toUpperCase();

            if (!ticker) return;

            const marketCap = parseFinvizMarketCapMillions(
                getField(row, ["marketcap", "marketcapitalization"])
            );
            const currentVolume = parseNumberValue(
                getField(row, ["volume", "currentvolume"])
            );

            output.set(ticker, {
                marketCap: marketCap,
                currentVolume: currentVolume,
                averageVolume: null,
                company: getField(row, ["company", "name"]) || ticker
            });
        });
    } catch (error) {
        console.warn("Finviz metadata fallback failed:", error.message);
    }

    return output;
}

// ---- mergeQuoteMetadata() ----

function mergeQuoteMetadata(primary, fallback) {
    const output = new Map();
    const tickers = new Set([
        ...Array.from((fallback || new Map()).keys()),
        ...Array.from((primary || new Map()).keys())
    ]);

    tickers.forEach(function(ticker) {
        const preferred = (primary || new Map()).get(ticker) || {};
        const backup = (fallback || new Map()).get(ticker) || {};
        output.set(ticker, {
            marketCap: Number.isFinite(Number(preferred.marketCap))
                ? Number(preferred.marketCap)
                : Number.isFinite(Number(backup.marketCap)) ? Number(backup.marketCap) : null,
            currentVolume: Number.isFinite(Number(preferred.currentVolume))
                ? Number(preferred.currentVolume)
                : Number.isFinite(Number(backup.currentVolume)) ? Number(backup.currentVolume) : null,
            averageVolume: Number.isFinite(Number(preferred.averageVolume))
                ? Number(preferred.averageVolume)
                : Number.isFinite(Number(backup.averageVolume)) ? Number(backup.averageVolume) : null,
            company: preferred.company || backup.company || ticker
        });
    });

    return output;
}

// ---- fetchYahooQuoteMetadata() ----

async function fetchYahooQuoteMetadata(symbols) {
    const output = new Map();
    const batches = [];
    for (let index = 0; index < symbols.length; index += 40) {
        batches.push(symbols.slice(index, index + 40));
    }

    for (const batch of batches) {
        let loaded = false;
        for (const host of ["query1.finance.yahoo.com", "query2.finance.yahoo.com"]) {
            try {
                const url = `https://${host}/v7/finance/quote?symbols=${encodeURIComponent(batch.join(","))}`;
                const response = await fetch(url, {
                    headers: { "User-Agent": "Mozilla/5.0", "Accept": "application/json" },
                    signal: AbortSignal.timeout(15000)
                });
                if (!response.ok) continue;
                const payload = await response.json();
                const rows = payload && payload.quoteResponse && Array.isArray(payload.quoteResponse.result)
                    ? payload.quoteResponse.result
                    : [];
                rows.forEach(function(row) {
                    const ticker = String(row.symbol || "").toUpperCase();
                    if (!ticker) return;
                    output.set(ticker, {
                        marketCap: Number(row.marketCap),
                        currentVolume: Number(row.regularMarketVolume),
                        averageVolume: Number(row.averageDailyVolume3Month || row.averageDailyVolume10Day),
                        company: row.longName || row.shortName || ticker
                    });
                });
                loaded = rows.length > 0;
                if (loaded) break;
            } catch (error) {
                // Try the alternate Yahoo host.
            }
        }
    }
    return output;
}

// ---- enrichScannerLiquidity() ----

function enrichScannerLiquidity(analysis, metadata, dailyBars, liquidityFilters) {
    if (!analysis) return null;
    const latest = dailyBars && dailyBars.length ? dailyBars[dailyBars.length - 1] : null;
    const fallbackAverage = dailyBars && dailyBars.length > 20
        ? average(dailyBars.slice(-21, -1).map(function(bar) { return Number(bar.volume); }))
        : null;
    const marketCap = Number(metadata && metadata.marketCap);
    const currentVolume = Number.isFinite(Number(metadata && metadata.currentVolume))
        ? Number(metadata.currentVolume)
        : Number(latest && latest.volume);
    const averageVolume = Number.isFinite(Number(metadata && metadata.averageVolume))
        ? Number(metadata.averageVolume)
        : fallbackAverage;
    const relativeVolume = Number.isFinite(currentVolume) && Number.isFinite(averageVolume) && averageVolume > 0
        ? currentVolume / averageVolume
        : Number(analysis.relativeVolume);
    const capRule = classifyMarketCap(marketCap);
    const filters = liquidityFilters || DEFAULT_LIQUIDITY_FILTERS;
    const marketCapKnown = capRule.category !== "Unknown";
    // Do not eliminate the entire scan when a metadata provider temporarily omits market cap.
    // Unknown-cap rows use a conservative 1.00x RVOL fallback and are labeled Unknown in the UI.
    const capEnabled = marketCapKnown
        ? filters.enabledCaps.includes(capRule.category)
        : true;
    const requiredRelativeVolume = marketCapKnown && Number.isFinite(Number(filters.relativeVolume[capRule.category]))
        ? Number(filters.relativeVolume[capRule.category])
        : 1.0;
    const minimumCurrentVolume = Number.isFinite(Number(filters.minimumCurrentVolume))
        ? Number(filters.minimumCurrentVolume)
        : DEFAULT_LIQUIDITY_FILTERS.minimumCurrentVolume;

    return Object.assign({}, analysis, {
        company: metadata && metadata.company ? metadata.company : analysis.company,
        marketCap: Number.isFinite(marketCap) ? marketCap : null,
        marketCapFormatted: formatMarketCapValue(marketCap),
        marketCapCategory: capRule.category,
        currentVolume: Number.isFinite(currentVolume) ? currentVolume : null,
        averageVolume: Number.isFinite(averageVolume) ? averageVolume : null,
        relativeVolume: Number.isFinite(relativeVolume) ? Number(relativeVolume.toFixed(2)) : null,
        requiredRelativeVolume: requiredRelativeVolume,
        minimumCurrentVolume: minimumCurrentVolume,
        marketCapEnabled: capEnabled,
        volumePass: Number.isFinite(currentVolume) && currentVolume >= minimumCurrentVolume,
        relativeVolumePass: Number.isFinite(relativeVolume) && relativeVolume >= requiredRelativeVolume,
        liquidityPass:
            capEnabled &&
            Number.isFinite(currentVolume) && currentVolume >= minimumCurrentVolume &&
            Number.isFinite(relativeVolume) && relativeVolume >= requiredRelativeVolume
    });
}

// ---- easternMinutesNow() ----

function easternMinutesNow(date) {
    const parts = new Intl.DateTimeFormat("en-US", {
        timeZone: "America/New_York",
        hour: "2-digit",
        minute: "2-digit",
        hour12: false
    }).formatToParts(date || new Date());
    const values = {};
    parts.forEach(function(part) { values[part.type] = part.value; });
    return Number(values.hour) * 60 + Number(values.minute);
}

// ---- createTradeTimeAlert() ----

function createTradeTimeAlert(marketMode, profile, direction) {
    const risk = Number(profile && profile.risk) || 6;
    const style = profile && profile.style || "day";
    const nowMinutes = easternMinutesNow(new Date());
    const aggressive = risk >= 8 || style === "aggressive" || style === "momentum";
    const conservative = risk <= 3 || style === "conservative";

    let entryStart = aggressive ? 575 : conservative ? 600 : 585; // 9:35, 10:00, 9:45 ET
    let entryEnd = aggressive ? 645 : conservative ? 690 : 660;   // 10:45, 11:30, 11:00 ET
    let entryWindow = aggressive ? "9:35-10:45 AM ET" : conservative ? "10:00-11:30 AM ET" : "9:45-11:00 AM ET";
    let exitWindow = style === "swing" || style === "conservative"
        ? "Manage into the close; hold 1-5 sessions only while the setup remains valid"
        : aggressive
            ? "Take partial profits into strength; close remaining position by 3:45 PM ET"
            : "Target 2:00-3:45 PM ET; close by the regular-session close";

    if (!marketMode || !marketMode.marketOpen) {
        return {
            entryWindow: `Next regular session, ${entryWindow}`,
            exitWindow: exitWindow,
            timeAlertStatus: "Scheduled",
            timeAlertDetail: "Forecast only. Recheck price, volume, and news after the opening bell."
        };
    }

    let status = "Entry Open";
    let detail = direction === "Short"
        ? "Wait for a confirmed breakdown or failed bounce before entering."
        : "Wait for the listed entry trigger and volume confirmation before entering.";
    if (nowMinutes < entryStart) {
        status = "Wait";
        detail = "The preferred entry window has not opened yet.";
    } else if (nowMinutes > entryEnd) {
        status = "Entry Window Closed";
        detail = "Avoid chasing. Only enter if a new setup forms with fresh confirmation.";
    } else if (entryEnd - nowMinutes <= 15) {
        status = "Entry Closing Soon";
    }

    return {
        entryWindow: entryWindow,
        exitWindow: exitWindow,
        timeAlertStatus: status,
        timeAlertDetail: detail
    };
}

const SCANNER_UNIVERSE = [
    "AAPL", "MSFT", "NVDA", "AMZN", "META", "GOOGL", "TSLA", "AVGO",
    "AMD", "PLTR", "NFLX", "CRM", "ORCL", "ADBE", "NOW", "INTU",
    "MU", "ARM", "QCOM", "AMAT", "LRCX", "TSM", "SMCI", "DELL",
    "COIN", "HOOD", "SOFI", "RDDT", "UBER", "SHOP", "SNOW", "CRWD",
    "PANW", "JPM", "BAC", "GS", "MS", "V", "MA", "XOM", "CVX",
    "OXY", "CAT", "GE", "BA", "WMT", "COST", "LLY", "UNH", "MRK",
    "NVO", "DIS", "NKE", "F", "GM"
];

// ---- average() ----

function average(values) {
    const valid = values.filter(Number.isFinite);
    return valid.length
        ? valid.reduce(function(total, value) { return total + value; }, 0) / valid.length
        : null;
}

// ---- calculateScannerSMA() ----

function calculateScannerSMA(bars, period) {
    if (!Array.isArray(bars) || bars.length < period) return null;
    return average(bars.slice(-period).map(function(bar) { return Number(bar.close); }));
}

// ---- calculateScannerRSI() ----

function calculateScannerRSI(bars, period) {
    if (!Array.isArray(bars) || bars.length <= period) return null;

    let gains = 0;
    let losses = 0;
    const sample = bars.slice(-(period + 1));

    for (let index = 1; index < sample.length; index++) {
        const difference = Number(sample[index].close) - Number(sample[index - 1].close);
        if (difference >= 0) gains += difference;
        else losses += Math.abs(difference);
    }

    const averageGain = gains / period;
    const averageLoss = losses / period;
    if (averageLoss === 0) return 100;
    return 100 - (100 / (1 + averageGain / averageLoss));
}

// ---- calculateScannerATR() ----

function calculateScannerATR(bars, period) {
    if (!Array.isArray(bars) || bars.length <= period) return null;
    const sample = bars.slice(-(period + 1));
    const ranges = [];

    for (let index = 1; index < sample.length; index++) {
        const current = sample[index];
        const previous = sample[index - 1];
        ranges.push(Math.max(
            Number(current.high) - Number(current.low),
            Math.abs(Number(current.high) - Number(previous.close)),
            Math.abs(Number(current.low) - Number(previous.close))
        ));
    }

    return average(ranges);
}

// ---- percentChange() ----

function percentChange(current, previous) {
    return Number.isFinite(current) && Number.isFinite(previous) && previous !== 0
        ? ((current - previous) / previous) * 100
        : null;
}

// ---- clamp() ----

function clamp(value, minimum, maximum) {
    return Math.max(minimum, Math.min(maximum, value));
}

// ---- scoreRange() ----

function scoreRange(value, low, idealLow, idealHigh, high) {
    if (!Number.isFinite(value)) return 0;
    if (value <= low || value >= high) return 0;
    if (value >= idealLow && value <= idealHigh) return 1;
    if (value < idealLow) return (value - low) / (idealLow - low);
    return (high - value) / (high - idealHigh);
}

// ---- createTradePlan() ----

function createTradePlan(latest, atr, direction) {
    const price = Number(latest.close);
    const safeAtr = Number.isFinite(atr) && atr > 0 ? atr : price * 0.02;
    const isLong = direction === "Long";
    const entry = isLong
        ? Math.max(price, Number(latest.high) + safeAtr * 0.05)
        : Math.min(price, Number(latest.low) - safeAtr * 0.05);
    const stop = isLong ? entry - safeAtr * 1.15 : entry + safeAtr * 1.15;
    const target = isLong ? entry + safeAtr * 2.3 : entry - safeAtr * 2.3;

    return {
        entry: Number(entry.toFixed(2)),
        stop: Number(Math.max(0.01, stop).toFixed(2)),
        target: Number(Math.max(0.01, target).toFixed(2)),
        riskReward: 2.0,
        holdingPeriod: "1-5 trading days"
    };
}

// ---- analyzeScannerBars() ----

function analyzeScannerBars(ticker, bars, marketMode, newsSummary) {
    if (!Array.isArray(bars) || bars.length < 55) return null;

    const latest = bars[bars.length - 1];
    const previous = bars[bars.length - 2];
    const close = Number(latest.close);
    const previousClose = Number(previous.close);
    const sma20 = calculateScannerSMA(bars, 20);
    const sma50 = calculateScannerSMA(bars, 50);
    const sma200 = calculateScannerSMA(bars, 200);
    const rsi = calculateScannerRSI(bars, 14);
    const atr = calculateScannerATR(bars, 14);
    const averageVolume20 = average(
        bars.slice(-21, -1).map(function(bar) { return Number(bar.volume); })
    );
    const relativeVolume = Number.isFinite(averageVolume20) && averageVolume20 > 0
        ? Number(latest.volume) / averageVolume20
        : null;
    const change1d = percentChange(close, previousClose);
    const change5d = bars.length > 5
        ? percentChange(close, Number(bars[bars.length - 6].close))
        : null;
    const change20d = bars.length > 20
        ? percentChange(close, Number(bars[bars.length - 21].close))
        : null;
    const gap = percentChange(Number(latest.open), previousClose);
    const fromOpen = percentChange(close, Number(latest.open));
    const atrPercent = Number.isFinite(atr) && close > 0 ? (atr / close) * 100 : null;
    const dollarVolume = Number(latest.volume) * close;

    let longScore = 0;
    let shortScore = 0;
    const longReasons = [];
    const shortReasons = [];

    // Trend: 25 points.
    if (Number.isFinite(sma20)) {
        if (close > sma20) { longScore += 10; longReasons.push("Price is above SMA20"); }
        else { shortScore += 10; shortReasons.push("Price is below SMA20"); }
    }
    if (Number.isFinite(sma50)) {
        if (close > sma50) { longScore += 8; longReasons.push("Price is above SMA50"); }
        else { shortScore += 8; shortReasons.push("Price is below SMA50"); }
    }
    if (Number.isFinite(sma200)) {
        if (close > sma200) { longScore += 7; longReasons.push("Long-term trend is positive"); }
        else { shortScore += 7; shortReasons.push("Long-term trend is negative"); }
    }

    // Momentum: 25 points.
    if (Number.isFinite(change1d)) {
        longScore += clamp(change1d / 5, 0, 1) * 10;
        shortScore += clamp(-change1d / 5, 0, 1) * 10;
    }
    if (Number.isFinite(change5d)) {
        longScore += clamp(change5d / 10, 0, 1) * 9;
        shortScore += clamp(-change5d / 10, 0, 1) * 9;
    }
    if (Number.isFinite(change20d)) {
        longScore += clamp(change20d / 18, 0, 1) * 6;
        shortScore += clamp(-change20d / 18, 0, 1) * 6;
    }
    if (Number.isFinite(change1d) && change1d > 1) longReasons.push(`Daily momentum is +${change1d.toFixed(2)}%`);
    if (Number.isFinite(change1d) && change1d < -1) shortReasons.push(`Daily momentum is ${change1d.toFixed(2)}%`);

    // Volume and liquidity: 20 points.
    if (Number.isFinite(relativeVolume)) {
        const volumePoints = clamp((relativeVolume - 0.7) / 1.8, 0, 1) * 14;
        longScore += volumePoints;
        shortScore += volumePoints;
        if (relativeVolume >= 1.25) {
            longReasons.push(`Relative volume is ${relativeVolume.toFixed(2)}x`);
            shortReasons.push(`Relative volume is ${relativeVolume.toFixed(2)}x`);
        }
    }
    const liquidityPoints = clamp((Math.log10(Math.max(dollarVolume, 1)) - 7) / 2.5, 0, 1) * 6;
    longScore += liquidityPoints;
    shortScore += liquidityPoints;

    // RSI quality: 10 points, with different ideal ranges for longs and shorts.
    longScore += scoreRange(rsi, 35, 52, 68, 82) * 10;
    shortScore += scoreRange(rsi, 18, 32, 48, 65) * 10;
    if (Number.isFinite(rsi) && rsi >= 52 && rsi <= 68) longReasons.push(`Constructive RSI at ${rsi.toFixed(1)}`);
    if (Number.isFinite(rsi) && rsi >= 32 && rsi <= 48) shortReasons.push(`Bearish RSI at ${rsi.toFixed(1)}`);

    // Tradable volatility: 10 points. Too little movement or extreme volatility scores lower.
    const volatilityQuality = scoreRange(atrPercent, 0.5, 1.5, 5.0, 10.0);
    longScore += volatilityQuality * 10;
    shortScore += volatilityQuality * 10;

    // Gap/open confirmation: 5 points.
    if (Number.isFinite(fromOpen)) {
        longScore += clamp(fromOpen / 3, 0, 1) * 3;
        shortScore += clamp(-fromOpen / 3, 0, 1) * 3;
    }
    if (Number.isFinite(gap)) {
        longScore += clamp(gap / 4, 0, 1) * 2;
        shortScore += clamp(-gap / 4, 0, 1) * 2;
    }

    // Recent news: 10 points, positive for longs and negative for shorts.
    const newsAvailable = Boolean(newsSummary && newsSummary.available);
    if (newsAvailable) {
        if (newsSummary.sentiment === "positive") {
            longScore += 10;
            longReasons.push("Recent positive company catalyst");
        } else if (newsSummary.sentiment === "negative") {
            shortScore += 10;
            shortReasons.push("Recent negative company catalyst");
        } else {
            longScore += 4;
            shortScore += 4;
        }
    }

    longScore = clamp(longScore, 0, 100);
    shortScore = clamp(shortScore, 0, 100);

    let direction = longScore >= shortScore ? "Long" : "Short";
    let score = Math.max(longScore, shortScore);
    let reasons = direction === "Long" ? longReasons : shortReasons;

    // Avoid forcing a directional call when neither side has a clear edge.
    if (score < 55 || Math.abs(longScore - shortScore) < 6) {
        direction = "Watch";
        score = Math.max(longScore, shortScore);
        reasons = longScore >= shortScore ? longReasons : shortReasons;
    }

    const qualityLabel =
        score >= 82 ? (direction === "Short" ? "Strong Short" : "Strong Long") :
        score >= 70 ? direction :
        score >= 55 ? "Watch" : "No Trade";

    const coverageFields = [sma20, sma50, sma200, rsi, atr, relativeVolume, change1d, change5d, change20d, gap, fromOpen];
    const dataCoverage = Math.round(
        (coverageFields.filter(Number.isFinite).length / coverageFields.length) * 100
    );
    const planDirection = direction === "Short" ? "Short" : "Long";
    const tradePlan = createTradePlan(latest, atr, planDirection);

    return {
        ticker: ticker,
        company: ticker,
        sector: "",
        price: close,
        changePercent: change1d,
        change5d: change5d,
        change20d: change20d,
        relativeVolume: relativeVolume,
        rsi: rsi,
        atrPercent: atrPercent,
        dollarVolume: dollarVolume,
        score: Number(score.toFixed(1)),
        longScore: Number(longScore.toFixed(1)),
        shortScore: Number(shortScore.toFixed(1)),
        dataCoverage: dataCoverage,
        direction: direction,
        setup: qualityLabel,
        reasons: reasons.slice(0, 5),
        confirmation:
            marketMode.mode === "live"
                ? "Wait for price and volume confirmation before entering."
                : "Recheck the setup after the next regular session opens.",
        entry: tradePlan.entry,
        stop: tradePlan.stop,
        target: tradePlan.target,
        riskReward: tradePlan.riskReward,
        holdingPeriod: tradePlan.holdingPeriod,
        news: newsSummary && newsSummary.headlines ? newsSummary.headlines : []
    };
}



const SCANNER_STYLE_PRESETS = {
    conservative: { label: "Conservative Investor", risk: 2 },
    swing: { label: "Swing Trader", risk: 5 },
    day: { label: "Day Trader", risk: 6 },
    momentum: { label: "Momentum Trader", risk: 8 },
    aggressive: { label: "Aggressive", risk: 10 },
    short: { label: "Short Seller", risk: 7 }
};

// ---- getScannerProfile() ----

function getScannerProfile(riskInput, styleInput) {
    const style = Object.prototype.hasOwnProperty.call(SCANNER_STYLE_PRESETS, styleInput)
        ? styleInput : "day";
    const preset = SCANNER_STYLE_PRESETS[style];
    const risk = clamp(Number(riskInput) || preset.risk, 1, 10);
    const aggressiveFactor = (risk - 1) / 9;
    const conservativeFactor = 1 - aggressiveFactor;

    const conservativeWeights = { "3m": .04, "5m": .06, "15m": .09, "30m": .10, "1h": .14, "4h": .18, "1d": .22, "1w": .17 };
    const aggressiveWeights = { "3m": .16, "5m": .17, "15m": .17, "30m": .14, "1h": .12, "4h": .09, "1d": .09, "1w": .06 };
    const weights = {};
    Object.keys(conservativeWeights).forEach(function(timeframe) {
        weights[timeframe] = conservativeWeights[timeframe] * conservativeFactor + aggressiveWeights[timeframe] * aggressiveFactor;
    });

    if (style === "swing") { weights["4h"] += .04; weights["1d"] += .04; }
    if (style === "momentum" || style === "aggressive") { weights["3m"] += .03; weights["5m"] += .03; weights["15m"] += .03; }
    if (style === "conservative") { weights["1d"] += .04; weights["1w"] += .04; }
    if (style === "short") { weights["30m"] += .02; weights["1h"] += .03; weights["4h"] += .03; }

    const total = Object.values(weights).reduce(function(sum, value) { return sum + value; }, 0);
    Object.keys(weights).forEach(function(key) { weights[key] /= total; });

    return {
        risk: risk,
        style: style,
        styleLabel: preset.label,
        weights: weights,
        minimumScore: 64 - aggressiveFactor * 10,
        minimumDirectionalCount: risk <= 3 ? 5 : risk >= 8 ? 3 : 4,
        minimumDifference: 10 - aggressiveFactor * 5,
        volatilityTarget: 1.2 + aggressiveFactor * 5.8,
        stopAtr: 0.85 + aggressiveFactor * 0.9,
        targetAtr: 1.6 + aggressiveFactor * 2.5,
        holdingPeriod: risk >= 8 ? "Minutes to 2 trading days" : risk <= 3 ? "2-15 trading days" : "Intraday to 5 trading days"
    };
}

const SCANNER_TIMEFRAMES = [
    { timeframe: "3m", weight: 0.08, label: "3 Minute" },
    { timeframe: "5m", weight: 0.10, label: "5 Minute" },
    { timeframe: "15m", weight: 0.14, label: "15 Minute" },
    { timeframe: "30m", weight: 0.13, label: "30 Minute" },
    { timeframe: "1h", weight: 0.15, label: "1 Hour" },
    { timeframe: "4h", weight: 0.15, label: "4 Hour" },
    { timeframe: "1d", weight: 0.15, label: "1 Day" },
    { timeframe: "1w", weight: 0.10, label: "1 Week" }
];

// ---- calculateEMAFromCloses() ----

function calculateEMAFromCloses(values, period) {
    const valid = (values || []).map(Number).filter(Number.isFinite);
    if (valid.length < period) return null;

    const multiplier = 2 / (period + 1);
    let ema = valid.slice(0, period).reduce(function(total, value) {
        return total + value;
    }, 0) / period;

    for (let index = period; index < valid.length; index++) {
        ema = (valid[index] - ema) * multiplier + ema;
    }

    return ema;
}

// ---- analyzeTimeframeSignal() ----

function analyzeTimeframeSignal(bars, timeframe) {
    if (!Array.isArray(bars) || bars.length < 22) {
        return {
            timeframe: timeframe,
            available: false,
            bias: "Unavailable",
            longScore: 0,
            shortScore: 0,
            strength: 0,
            reason: "Not enough candles returned"
        };
    }

    const latest = bars[bars.length - 1];
    const previous = bars[bars.length - 2];
    const close = Number(latest.close);
    const previousClose = Number(previous.close);
    const closes = bars.map(function(bar) { return Number(bar.close); });
    const ema9 = calculateEMAFromCloses(closes, 9);
    const ema21 = calculateEMAFromCloses(closes, 21);
    const sma20 = calculateScannerSMA(bars, 20);
    const sma50 = calculateScannerSMA(bars, 50);
    const rsi = calculateScannerRSI(bars, 14);
    const atr = calculateScannerATR(bars, 14);
    const atrPercent = Number.isFinite(atr) && close > 0 ? (atr / close) * 100 : null;
    const momentum1 = percentChange(close, previousClose);
    const momentum5 = bars.length > 5
        ? percentChange(close, Number(bars[bars.length - 6].close))
        : null;
    const averageVolume = average(
        bars.slice(-21, -1).map(function(bar) { return Number(bar.volume); })
    );
    const relativeVolume = Number.isFinite(averageVolume) && averageVolume > 0
        ? Number(latest.volume) / averageVolume
        : null;

    let longScore = 0;
    let shortScore = 0;
    const longReasons = [];
    const shortReasons = [];

    if (Number.isFinite(ema9)) {
        if (close > ema9) { longScore += 14; longReasons.push("above EMA9"); }
        else { shortScore += 14; shortReasons.push("below EMA9"); }
    }

    if (Number.isFinite(ema21)) {
        if (close > ema21) { longScore += 16; longReasons.push("above EMA21"); }
        else { shortScore += 16; shortReasons.push("below EMA21"); }
    }

    if (Number.isFinite(ema9) && Number.isFinite(ema21)) {
        if (ema9 > ema21) { longScore += 12; longReasons.push("EMA9 above EMA21"); }
        else { shortScore += 12; shortReasons.push("EMA9 below EMA21"); }
    }

    if (Number.isFinite(sma20)) {
        if (close > sma20) longScore += 10;
        else shortScore += 10;
    }

    if (Number.isFinite(sma50)) {
        if (close > sma50) longScore += 8;
        else shortScore += 8;
    }

    if (Number.isFinite(momentum1)) {
        longScore += clamp(momentum1 / 2.5, 0, 1) * 12;
        shortScore += clamp(-momentum1 / 2.5, 0, 1) * 12;
    }

    if (Number.isFinite(momentum5)) {
        longScore += clamp(momentum5 / 5, 0, 1) * 10;
        shortScore += clamp(-momentum5 / 5, 0, 1) * 10;
    }

    longScore += scoreRange(rsi, 35, 50, 68, 82) * 8;
    shortScore += scoreRange(rsi, 18, 32, 50, 65) * 8;

    if (Number.isFinite(relativeVolume)) {
        const points = clamp((relativeVolume - 0.75) / 1.5, 0, 1) * 6;
        longScore += points;
        shortScore += points;
    }

    const volatilityPoints = scoreRange(atrPercent, 0.05, 0.25, 4.5, 10) * 4;
    longScore += volatilityPoints;
    shortScore += volatilityPoints;

    longScore = clamp(longScore, 0, 100);
    shortScore = clamp(shortScore, 0, 100);

    const difference = longScore - shortScore;
    let bias = "Neutral";
    let strength = Math.max(longScore, shortScore);
    let reasons = difference >= 0 ? longReasons : shortReasons;

    if (difference >= 8 && longScore >= 52) bias = "Bullish";
    else if (difference <= -8 && shortScore >= 52) bias = "Bearish";

    return {
        timeframe: timeframe,
        available: true,
        bias: bias,
        longScore: Number(longScore.toFixed(1)),
        shortScore: Number(shortScore.toFixed(1)),
        strength: Number(strength.toFixed(1)),
        close: close,
        rsi: Number.isFinite(rsi) ? Number(rsi.toFixed(1)) : null,
        relativeVolume: Number.isFinite(relativeVolume)
            ? Number(relativeVolume.toFixed(2))
            : null,
        reason: reasons.slice(0, 3).join(", ") || "Mixed signals"
    };
}

// ---- combineMultiTimeframeAnalysis() ----

function combineMultiTimeframeAnalysis(ticker, timeframeBars, dailyAnalysis, marketMode, newsSummary, macroContext, profile, learningBias) {
    const timeframeSignals = SCANNER_TIMEFRAMES.map(function(configuration) {
        return analyzeTimeframeSignal(
            timeframeBars[configuration.timeframe] || [],
            configuration.timeframe
        );
    });

    let weightedLong = 0;
    let weightedShort = 0;
    let availableWeight = 0;

    timeframeSignals.forEach(function(signal, index) {
        const weight = profile.weights[signal.timeframe] || SCANNER_TIMEFRAMES[index].weight;
        if (!signal.available) return;
        weightedLong += signal.longScore * weight;
        weightedShort += signal.shortScore * weight;
        availableWeight += weight;
    });

    if (availableWeight > 0) {
        weightedLong /= availableWeight;
        weightedShort /= availableWeight;
    }

    if (newsSummary && newsSummary.available) {
        if (newsSummary.sentiment === "positive") weightedLong += 5;
        if (newsSummary.sentiment === "negative") weightedShort += 5;
    }

    const atrPercent = dailyAnalysis && Number(dailyAnalysis.atrPercent);
    if (Number.isFinite(atrPercent)) {
        const distance = Math.abs(atrPercent - profile.volatilityTarget);
        const volatilityFit = clamp(1 - distance / Math.max(profile.volatilityTarget, 1), 0, 1);
        const volatilityBonus = volatilityFit * (4 + profile.risk * 0.7);
        weightedLong += volatilityBonus;
        weightedShort += volatilityBonus;
    }

    weightedLong += Number(learningBias && learningBias.long) || 0;
    weightedShort += Number(learningBias && learningBias.short) || 0;
    if (profile.style === "short") weightedShort += 4;

    const macroImpact = macroImpactForTicker(ticker, macroContext);
    if (macroImpact.score > 0) weightedLong += macroImpact.score;
    if (macroImpact.score < 0) weightedShort += Math.abs(macroImpact.score);

    weightedLong = clamp(weightedLong, 0, 100);
    weightedShort = clamp(weightedShort, 0, 100);

    const bullishCount = timeframeSignals.filter(function(signal) {
        return signal.available && signal.bias === "Bullish";
    }).length;
    const bearishCount = timeframeSignals.filter(function(signal) {
        return signal.available && signal.bias === "Bearish";
    }).length;
    const availableCount = timeframeSignals.filter(function(signal) {
        return signal.available;
    }).length;

    let direction = weightedLong >= weightedShort ? "Long" : "Short";
    let score = Math.max(weightedLong, weightedShort);
    const directionalCount = direction === "Long" ? bullishCount : bearishCount;
    const oppositeCount = direction === "Long" ? bearishCount : bullishCount;

    // Reward genuine agreement and penalize conflicting charts.
    const agreementRatio = availableCount > 0 ? directionalCount / availableCount : 0;
    score += agreementRatio * 12;
    score -= oppositeCount * 2.5;
    score = clamp(score, 0, 100);

    if (
        availableCount < 5 ||
        score < profile.minimumScore ||
        Math.abs(weightedLong - weightedShort) < profile.minimumDifference ||
        directionalCount < profile.minimumDirectionalCount
    ) {
        direction = "Watch";
    }

    const setup =
        direction === "Long" && score >= 82 ? "Strong Long" :
        direction === "Short" && score >= 82 ? "Strong Short" :
        direction === "Long" ? "Long" :
        direction === "Short" ? "Short" :
        score >= 55 ? "Watch" : "No Trade";

    const directionalSignals = timeframeSignals.filter(function(signal) {
        return signal.available && (
            (direction === "Long" && signal.bias === "Bullish") ||
            (direction === "Short" && signal.bias === "Bearish")
        );
    });

    const reasons = directionalSignals.slice(0, 4).map(function(signal) {
        return `${signal.timeframe} ${signal.bias.toLowerCase()}: ${signal.reason}`;
    });

    if (newsSummary && newsSummary.available) {
        reasons.push(`Company news sentiment is ${newsSummary.sentiment}`);
    }
    if (macroImpact && macroImpact.headlines.length) {
        reasons.push(`Macro/political impact is ${macroImpact.sentiment}`);
    }

    const dailyBars = timeframeBars["1d"] || [];
    const latestDaily = dailyBars[dailyBars.length - 1];
    const dailyAtr = calculateScannerATR(dailyBars, 14);
    const planDirection = direction === "Short" ? "Short" : "Long";
    let tradePlan = latestDaily
        ? createTradePlan(latestDaily, dailyAtr, planDirection)
        : { entry: null, stop: null, target: null, riskReward: null, holdingPeriod: profile.holdingPeriod };
    if (latestDaily && Number.isFinite(dailyAtr) && dailyAtr > 0) {
        const entry = Number(tradePlan.entry);
        const isLong = planDirection === "Long";
        const stop = isLong ? entry - dailyAtr * profile.stopAtr : entry + dailyAtr * profile.stopAtr;
        const target = isLong ? entry + dailyAtr * profile.targetAtr : entry - dailyAtr * profile.targetAtr;
        tradePlan = {
            entry: Number(entry.toFixed(2)),
            stop: Number(Math.max(.01, stop).toFixed(2)),
            target: Number(Math.max(.01, target).toFixed(2)),
            riskReward: Number((profile.targetAtr / profile.stopAtr).toFixed(1)),
            holdingPeriod: profile.holdingPeriod
        };
    }

    return Object.assign({}, dailyAnalysis || {}, {
        ticker: ticker,
        riskLevel: profile.risk,
        tradingStyle: profile.style,
        tradingStyleLabel: profile.styleLabel,
        score: Number(score.toFixed(1)),
        longScore: Number(weightedLong.toFixed(1)),
        shortScore: Number(weightedShort.toFixed(1)),
        direction: direction,
        setup: setup,
        reasons: reasons.slice(0, 5),
        timeframeAgreement: {
            bullish: bullishCount,
            bearish: bearishCount,
            neutral: Math.max(0, availableCount - bullishCount - bearishCount),
            available: availableCount,
            total: SCANNER_TIMEFRAMES.length,
            directionalAgreement: directionalCount,
            agreementPercent: availableCount
                ? Math.round((directionalCount / availableCount) * 100)
                : 0
        },
        timeframeSignals: timeframeSignals,
        dataCoverage: Math.round((availableCount / SCANNER_TIMEFRAMES.length) * 100),
        confirmation:
            direction === "Watch"
                ? "Timeframes are mixed. Wait for stronger alignment before entering."
                : `Confirm the ${direction.toLowerCase()} setup on the 3m or 5m chart before entry.`,
        entry: tradePlan.entry,
        stop: tradePlan.stop,
        target: tradePlan.target,
        riskReward: tradePlan.riskReward,
        holdingPeriod: tradePlan.holdingPeriod,
        news: newsSummary && newsSummary.headlines ? newsSummary.headlines : [],
        macroImpact: macroImpact,
        timeAlert: createTradeTimeAlert(marketMode, profile, direction)
    });
}

// ---- mapWithConcurrency() ----

async function mapWithConcurrency(items, concurrency, worker) {
    const results = new Array(items.length);
    let nextIndex = 0;

    // ---- runWorker() ----

    async function runWorker() {
        while (nextIndex < items.length) {
            const index = nextIndex++;
            try {
                results[index] = await worker(items[index], index);
            } catch (error) {
                console.error("Scanner symbol failed:", items[index], error.message || error);
                results[index] = null;
            }
        }
    }

    await Promise.all(
        Array.from({ length: Math.min(concurrency, items.length) }, runWorker)
    );
    return results;
}

app.get("/market-scan", async function(req, res) {
    const marketMode = getEasternMarketMode(new Date());
    const profile = getScannerProfile(req.query.risk, req.query.style);
    const learningBias = {
        long: clamp(Number(req.query.learnLong) || 0, -5, 5),
        short: clamp(Number(req.query.learnShort) || 0, -5, 5)
    };
    const liquidityFilters = getScannerLiquidityFilters(req.query);

    try {
        const macroContext = await fetchMacroMarketContext();
        const metadataResults = await Promise.all([
            fetchYahooQuoteMetadata(SCANNER_UNIVERSE),
            fetchFinvizQuoteMetadata()
        ]);
        const quoteMetadata = mergeQuoteMetadata(metadataResults[0], metadataResults[1]);
        console.log("Scanner metadata rows:", quoteMetadata.size);

        // Stage 1: use daily data and liquidity rules to narrow the curated universe.
        const preliminary = await mapWithConcurrency(
            SCANNER_UNIVERSE,
            6,
            async function(ticker) {
                const dailyBars = await fetchYahooChartData(ticker, "1d");
                const baseAnalysis = analyzeScannerBars(
                    ticker,
                    dailyBars,
                    marketMode,
                    { available: false, headlines: [] }
                );
                const analysis = enrichScannerLiquidity(
                    baseAnalysis,
                    quoteMetadata.get(ticker),
                    dailyBars,
                    liquidityFilters
                );
                return {
                    ticker: ticker,
                    dailyBars: dailyBars,
                    metadata: quoteMetadata.get(ticker) || null,
                    analysis: analysis
                };
            }
        );

        const semifinalists = preliminary
            .filter(function(item) {
                return item && item.analysis && item.analysis.liquidityPass;
            })
            .sort(function(a, b) { return b.analysis.score - a.analysis.score; })
            .slice(0, 18);

        // Stage 2: evaluate each semifinalist across all requested timeframes.
        const detailed = await mapWithConcurrency(
            semifinalists,
            3,
            async function(item) {
                const timeframeBars = { "1d": item.dailyBars };
                const extraTimeframes = SCANNER_TIMEFRAMES
                    .map(function(configuration) { return configuration.timeframe; })
                    .filter(function(timeframe) { return timeframe !== "1d"; });

                const barsResults = await mapWithConcurrency(
                    extraTimeframes,
                    3,
                    async function(timeframe) {
                        return fetchYahooChartData(item.ticker, timeframe);
                    }
                );

                extraTimeframes.forEach(function(timeframe, index) {
                    timeframeBars[timeframe] = barsResults[index] || [];
                });

                const newsSummary = await fetchScannerNews(item.ticker);
                const combined = combineMultiTimeframeAnalysis(
                    item.ticker,
                    timeframeBars,
                    item.analysis,
                    marketMode,
                    newsSummary,
                    macroContext,
                    profile,
                    learningBias
                );
                return Object.assign({}, combined, {
                    company: item.analysis.company || item.ticker,
                    marketCap: item.analysis.marketCap,
                    marketCapFormatted: item.analysis.marketCapFormatted,
                    marketCapCategory: item.analysis.marketCapCategory,
                    currentVolume: item.analysis.currentVolume,
                    averageVolume: item.analysis.averageVolume,
                    relativeVolume: item.analysis.relativeVolume,
                    requiredRelativeVolume: item.analysis.requiredRelativeVolume,
                    minimumCurrentVolume: item.analysis.minimumCurrentVolume,
                    marketCapEnabled: item.analysis.marketCapEnabled,
                    volumePass: item.analysis.volumePass,
                    relativeVolumePass: item.analysis.relativeVolumePass,
                    liquidityPass: item.analysis.liquidityPass
                });
            }
        );

        const rankings = detailed
            .filter(Boolean)
            .sort(function(a, b) {
                if (b.score !== a.score) return b.score - a.score;
                if (b.timeframeAgreement.agreementPercent !== a.timeframeAgreement.agreementPercent) {
                    return b.timeframeAgreement.agreementPercent - a.timeframeAgreement.agreementPercent;
                }
                return b.dataCoverage - a.dataCoverage;
            })
            .slice(0, 10)
            .map(function(stock, index) {
                stock.rank = index + 1;
                return stock;
            });

        const averageCoverage = rankings.length
            ? rankings.reduce(function(total, stock) {
                return total + stock.dataCoverage;
            }, 0) / rankings.length
            : 0;

        res.set("Cache-Control", "no-store");
        res.json({
            mode: marketMode.mode,
            modeLabel: marketMode.label,
            marketOpen: marketMode.marketOpen,
            generatedAt: new Date().toISOString(),
            generatedAtLabel: new Intl.DateTimeFormat("en-US", {
                timeZone: "America/New_York",
                weekday: "short",
                month: "short",
                day: "numeric",
                hour: "numeric",
                minute: "2-digit",
                timeZoneName: "short"
            }).format(new Date()),
            candidateCount: preliminary.filter(function(item) { return item && item.analysis && item.analysis.liquidityPass; }).length,
            liquidityFilters: liquidityFilters,
            riskLevel: profile.risk,
            tradingStyle: profile.style,
            tradingStyleLabel: profile.styleLabel,
            learningBias: learningBias,
            macroContext: {
                available: macroContext.available,
                sentiment: macroContext.sentiment,
                sources: macroContext.sources,
                headlines: macroContext.headlines.slice(0, 8)
            },
            semifinalistCount: semifinalists.length,
            averageCoverage: Number(averageCoverage.toFixed(1)),
            rankings: rankings,
            methodology: {
                scoreRange: "0-100",
                topResults: 10,
                coverageAdjusted: false,
                newsWindowHours: 48,
                timeframes: SCANNER_TIMEFRAMES.map(function(item) { return Object.assign({}, item, { weight: profile.weights[item.timeframe] }); }),
                factors: [
                    "multi-timeframe trend alignment", "momentum",
                    "relative volume", "liquidity", "RSI", "ATR volatility",
                    "gap/open confirmation", "company news",
                    "Federal Reserve and economic releases", "presidential and policy news"
                ],
                disclaimer:
                    "These are model-generated trade candidates, not guaranteed outcomes or personalized investment advice. Confirm the setup and use risk controls."
            }
        });
    } catch (error) {
        console.error("Market scanner error:", error);
        res.status(500).json({
            rankings: [],
            error: error.message || "Unable to calculate market rankings."
        });
    }
});


app.post("/analyze-url", async function(req, res) {
    const url = req.body.url;

    if (!url) {
        res.json({
            text: "",
            error: "No URL provided."
        });
        return;
    }

    try {
        const response = await fetch(url, {
            headers: {
                "User-Agent": "Mozilla/5.0"
            }
        });

        const html = await response.text();

        const cleanedText = html
            .replace(/<script[\s\S]*?<\/script>/gi, "")
            .replace(/<style[\s\S]*?<\/style>/gi, "")
            .replace(/<[^>]+>/g, " ")
            .replace(/\s+/g, " ")
            .trim()
            .slice(0, 5000);

        res.json({
            text: cleanedText
        });

    } catch (error) {
        console.error(error);
        res.json({
            text: "",
            error: "Unable to read article URL."
        });
    }
});
const PORT = Number(process.env.PORT) || 3000;

app.listen(PORT, function() {
    console.log(`TraderAgent server running on http://localhost:${PORT}`);
});